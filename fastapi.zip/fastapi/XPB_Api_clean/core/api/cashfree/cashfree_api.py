import json

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from core.database.connection import get_db
from core.jwt.auth_bearer import JWTBearer
from core.jwt import auth_handler
from core.utils import cashfree_service
from core.api.users.crud import get_user_by_email


router = APIRouter()


@router.post("/cashfree-create-order", dependencies=[Depends(JWTBearer())], status_code=200, tags=["CASH-FREE"], )
async def cashfree_order_create_api(token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = get_user_by_email(db, payload['sub'])
    
    if not user:
        raise HTTPException(
            status_code=404,
            detail={
                "status" : "Error",
                "status_code" : 404,
                "data" : None,
                "error" : {
                    "status_code":404,
                    "status":'Error', 
                    "message" : "User not found."
                }
            }
        )
         
    order_detail = {
        "order_id": "xoxoday_voucher5",
        "order_amount": 1,
        "order_currency": "INR",
        "customer_details": {
            "customer_id": "walterwyM2Gs",
            "customer_name": "Walter White",
            "customer_email": "walter.white@example.com",
            "customer_phone": "8474090589"
        },
        "order_meta": {
            "notify_url": "",
            "return_url": "",
            "payment_methods": ""
        },
        "order_expiry_time": "2023-02-18T04:32:37.770Z",
        "order_note": "xpayback test order",
        "order_tags": {
            "name": "Walter White",
            "nick": "Heisenberg",
            "company": "AMC"
        }
    }
    response = await cashfree_service.cashfree_create_order(order_details=order_detail)
    return response.json()


@router.post("/cashfree-payment-success")
async def cashfree_webhook(request: Request):
    body = await request.json()
    print("Received Cashfree webhook:")
    print(json.dumps(body, indent=2))
    return {"message": "Webhook received"}