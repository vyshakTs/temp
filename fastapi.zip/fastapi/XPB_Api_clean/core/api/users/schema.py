from typing import Optional, Text

from pydantic import BaseModel, EmailStr, Field


class UsersBase(BaseModel):
    full_name: str = Field(..., max_length=100, description="Full name")
    email: EmailStr = Field(..., description="user email")
    password: str = Field(..., min_length=5, max_length=200, description="Password")
    phone_number: str = Field(..., min_length=5, max_length=20, description="Phone number")
    
    class Config:
        orm_mode = True
        schema_extra = {
            "example": {
                "full_name": "Test Test",
                "email" : "test@example.com",
                "password" : "Test@123",
                "phone_number" : "+911234567890",
            },
        }

        
class UserRoles(BaseModel):
    role: str = Field(..., min_length=1, max_length=20, description="User role")
    description: str = Field(..., min_length=5, max_length=500, description="User role description")
    
    class Config:
        orm_mode = True
        schema_extra = {
            "example": {
                "role": "admin",
                "description": "admin"
            },
        }   


class UserCreate(UsersBase):
    country_code: Optional[str] | None = Field(default = None, description="user country code")
    referred_by: Optional[str] | None = Field(default = None, description="referred user code")
    role_id: int = Field(default = None, description="user type { 1 : super admin, 2 : admin, 3 : channel partner, 4 : merchant, 5 : consumer, 6 : staff }")
    
    class Config:
        orm_mode = True
        schema_extra = {
            "example": {
                "country_code": "+91",
                "referred_by": "abcdef",
                "role_id": "5",
                "full_name": "Test Test",
                "email" : "test@example.com",
                "password" : "Test@123",
                "phone_number" : "+911234567890",
            },
        }     


class Users(BaseModel):
    full_name : Optional[str] | None = Field(default = None, description="registered phone number")
    email : Optional[EmailStr] | None = Field(default = None, description="email")
    password : Optional[str] | None = Field(default = None, description="password")
    phone_number : Optional[str] | None = Field(default = None, description="phone number")

    class Config:
        schema_extra = {
            "example": {
                "full_name": "Test Test",
                "email": "test@example.com",
                "password": "Test@123",
                "phone_number": "+911234567890"
            },
        }     


class LoginSchema_email(BaseModel):

   email : Optional[EmailStr] | None = Field(default = None, description="registered email")

   class Config:
        schema_extra = {
            "example": {
                "email": "test@example.com"
            },
        } 


class PhoneNumberLoginSchema(BaseModel):

    phone_number : str = Field(default = None, description="registered phone number")
    channel: Optional[str] | None = Field(default = None, description="sms or call")

    class Config:
        schema_extra = {
            "example": {
                "phone_number": "+911234567890",
                "channel": "sms"
            },
        } 


class Otp(BaseModel):
    otp : str  = Field(default = None, description="OTP send to phone number ")
    key : Optional[str] | None = Field(default = None, description="key from api only needed for msg91")
    phone_number : str = Field(default = None, description="registered phone number")

    class Config:
        schema_extra = {
            "example": {
                "otp": "12345",
                "key": "qweertyuiopasdfghjkl",
                "phone_number": "+911234567890"
            },
        } 


class UserOut(BaseModel):
    full_name: str = Field(..., max_length=100, description="Full name")
    email: EmailStr = Field(..., description="user email")
    phone_number: str = Field(..., min_length=5, max_length=20, description="Phone number")

    class Config:
        schema_extra = {
            "example": {
                "full_name": "Test Test",
                "email": "test@example.com",
                "phone_number": "+911234567890"
            },
        } 


class Change_pin(BaseModel):
    old_pin : str = Field(..., max_length = 200, description = "Existing pin")
    new_pin : str = Field(..., max_length = 200, description = "New pin")
    reenter_pin :str = Field(..., max_length = 200, description = "Reenter pin")

    class Config:
        schema_extra = {
            "example": {
                "old_pin": "1234",
                "new_pin": "0000",
                "reenter_pin": "0000"
            },
        } 


class Change_password(BaseModel):
    old_password: str = Field(..., max_length=200, description="Existing Password")
    new_password: str = Field(..., max_length=200, description="New Password")
    reenter_password: str = Field(..., max_length=200, description="Reenter Password")

    class Config:
        schema_extra = {
            "example": {
                "old_password": "Test@123",
                "new_password": "Abcd@1234",
                "reenter_password": "Abcd@1234"
            },
        }      


class Add_Pin(BaseModel):
    pin : str = Field(default = None, description="pin number")
    reenter_pin : str = Field(default = None, description="confirm pin number")

    class Config:
        schema_extra = {
            "example": {
                "pin": "1234",
                "reenter_pin": "1234"
            },
        }  


class GenerateOtp(BaseModel):
    phone_number: str = Field(default = None, description="phone number")
    channel: Optional[str] | None = Field(default = None, description="sms or call")

    class Config:
        schema_extra = {
            "example": {
                "phone_number": "+911234567890",
                "channel": "sms"
            },
        }    


class VerifyOtp(BaseModel):
    phone_number: str = Field(default = None, description="registered phone number")
    otp: str= Field(default = None, description="otp send into phone number")

    class Config:
        schema_extra = {
            "example": {
                "phone_number": "+911234567890",
                "otp": "12345"
            },
        }

    

class LoginSchemaEmailPass(BaseModel):
    email : str = Field(default = None, description="login email")
    password : str = Field(default = None, description="user password")

    class Config:
        schema_extra = {
            "example": {
                "email": "test@example.com",
                "password": "Test@123"
            },
        }

class reset_password(BaseModel):
    token : str = Field(default = None, description="API key")
    password : str = Field(default = None, description="new password")

    class Config:
        schema_extra = {
            "example": {
                "token": "qwertyuiopasdfghjkl",
                "password": "Test@123"
            },
        }

#### register 
register_response ={

        409: {
            "description": "conflicts",
            "content": {
                "application/json": {
                    "examples": {
                        "email exist": {
                            "summary": "Email already registered",
                            "value": {
                            "detail" : {
                                "status": "Error",
                                "status_code": 409,
                                "data": None,
                                "error": {
                                "status_code": 409,
                                "status": "Error",
                                "message": "Email already registered"
                            }
                        }
                    }
                },

                        "phone number exist" :{
                            "summary": "phone number already registered",
                            "value": {
                            "detail" : {
                                "status": "Error",
                                "status_code": 409,
                                "data": None,
                                "error": {
                                    "status_code": 409,
                                    "status": "Error",
                                    "message": "Phone number already registered"
                                }
                            }
                        } 
                    }
                }
            }
        }
    },

        201: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "details" : {
                            "summary" : "User registered Successfully",
                            "value" : {
                            "detail" : {
                            "status": "Success",
                            "status_code": 201,
                            "data": {
                                "status_code": 201,
                                "status": "Success",
                                "message": "User registered Successfully",
                                "access_token": "qwertyuiopasdfghjkl", 
                                "token_type": "bearer",
                                "refresh_token": "lkjhgfdsapoiuytrewq",
                                "id" : 1,
                                "full_name":"Test Test",
                                "phone_number": "+911234567890",
                                "email" : "test@example.com",
                                "role": "5"
                            },
                            "error": None
                        }
                    },
                },
                        "details with new role":{
                            "summary" : "User registered Successfully as new user type",
                            "value" : {
                            "detail" : {
                            "status": "Success",
                            "status_code": 201,
                            "data": {
                                "status_code": 201,
                                "status": "Success",
                                "message": "User registered Successfully",
                                "access_token": "qwertyuiopasdfghjkl", 
                                "token_type": "bearer",
                                "refresh_token": "lkjhgfdsapoiuytrewq",
                                "id" : 1,
                                "full_name":"Test Test",
                                "phone_number": "+911234567890",
                                "email" : "test@example.com",
                                "role": "4"
                                },
                            "error": None
                            }
                        }
                    }
                }
            }
        },    
    },


        400: {
            "description": "phone number validation error",
            "content": {
                "application/json": {
                    "examples": {
                        "details": {
                            "summary": "Enter a valid phone number.",
                            "value": {
                            "detail" : {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message": "Enter a valid phone number."
                                    }
                                }
                            }
                        },

                        "not valid":{
                            "summary": "password validation error",
                            "value": {
                        "detail" : {
                            "status": "Error",
                            "status_code": 400,
                            "data": None,
                        "error": {
                            "status_code": 400,
                            "status": "Error",
                            "message": """Password must be at least 8 characters long, contains atleast one lower case character, one 
                            upper case character, one digit and one special case character."""
                                }
                            }     
                        }
                    }
                }
            }
        }
    },

        500: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "details": {
                            "summary": "Some error occurred while insert",
                            "value": {
                        "detail" : {
                            "status": "Error",
                            "status_code": 500,
                            "data": None,
                            "error": {
                                "status_code": 500,
                                "status": "Error",
                                "message": "Some error occurred"
                                }
                            },
                        }
                    },

                    " user type error details":{
                        "summary": "user type error",
                            "value": {
                        "detail" : {
                        
                    "status": "Error",
                    "status_code": 500,
                    "data": None,
                    "error": {
                        "status_code": 500,
                        "status": "Error",
                        "message": "Only Consumer or Merchant can register"
                                }
                            },
                        }
                    }
                }
            }
        },
    }
}
        
#### email login

user_email_login_response = {

        404: {
            "description": "Error",
            "content": {
                "application/x-www-form-urlencoded": {
                    "examples":{
                        "not_found": {
                            "summary": "Email not found",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message": "Email not found!"
                        }
                    }
                }
            } ,
                        "user_role": {
                            "summary": "user role not found!",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message": "Entered user role not found!"
                                    }
                                }             
                            }
                        }
                    }
                }
            }
        },

        401: {
            "description": "Error",
            "content": {
                "application/x-www-form-urlencoded": {
                    "examples": {
                        "blocked": {
                            "summary": "Blocked user",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 401,
                                "data": None,
                                "error": {
                                    "status_code": 401,
                                    "status": "Error",
                                    "message": "User is blocked!"
                                    }
                                }
                            }
                        },
                        "login validation": {
                            "summary": "Invalid credentials",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 401,
                                "data": None,
                                "error": {
                                    "status_code": 401,
                                    "status": "Error",
                                    "message": "Login failed! Invalid credentials"
                                }
                            }
                        }
                    }
                }
            }
        }
    },


        200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "detail" : {
                            "summary" : "User registered Successfully",
                            "value" : {
                                "detail" : {
                                    "status": "Success",
                                    "status_code": 200,
                                    "data": {
                                        "status_code": 200,
                                        "status": "Success",
                                        "message": "User registered Successfully",
                                        "access_token": "qwertyuiopasdfghjkl",
                                        "token_type": "bearer",
                                        "refresh_token": "lkjhgfdsapoiuytrewq",
                                        "id" : 1,
                                        "full_name": "Test Test",
                                        "email": "test@example.com",
                                        "phone_number": "+911234567890"
                                    },
                                    "error": None
                                }
                            }
                        }
                    }
                }
            }
        }

}

user_email_login_without_form_response = {


         404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples":{
                        "not_found": {
                            "summary": "Email not found",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message": "Email not found!"
                        }
                    }
                }
            } ,
                        "user_role": {
                            "summary": "user role not found!",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message": "Entered user role not found!"
                                    }
                                }             
                            }
                        }
                    }
                }
            }
    },

        401: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "blocked": {
                            "summary": "Blocked user",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 401,
                                "data": None,
                                "error": {
                                    "status_code": 401,
                                    "status": "Error",
                                    "message": "User is blocked!"
                                    }
                                }
                            }
                        },
                        "login validation": {
                            "summary": "Invalid credentials",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 401,
                                "data": None,
                                "error": {
                                    "status_code": 401,
                                    "status": "Error",
                                    "message": "Login failed! Invalid credentials"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },


        200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "detail" : {
                            "summary" : "User registered Successfully",
                            "value" : {
                                "detail" : {
                                    "status": "Success",
                                    "status_code": 200,
                                    "data": {
                                        "status_code": 200,
                                        "status": "Success",
                                        "message": "User registered Successfully",
                                        "access_token": "qwertyuiopasdfghjkl",
                                        "token_type": "bearer",
                                        "refresh_token": "lkjhgfdsapoiuytrewq",
                                        "id" : 1,
                                        "full_name": "Test Test",
                                        "email": "test@example.com",
                                        "phone_number": "+911234567890"
                                    },
                                    "error": None
                                }
                            }
                        }
                    }
                }
            }
        }

}


user_phone_login_response = {

        404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples":{
                        "not_found": {
                            "summary": "phone_number not found!",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message": "phone_number not found!"
                        }
                    }
                }
            } ,
                        "user_role": {
                            "summary": "user role not found!",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message": "Entered user role not found!"
                                }
                            }             
                        }
                    }
                }
            }
        }
    },

        401: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "blocked": {
                            "summary": "Blocked user",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 401,
                                "data": None,
                                "error": {
                                    "status_code": 401,
                                    "status": "Error",
                                    "message": "User is blocked!"
                                    }
                                }
                            }
                        },
                    }
                }
            }
        },


         200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "detail" : {
                            "summary" : "User registered Successfully",
                            "value" : {
                                "detail" : {
                                    "status": "Success",
                                    "status_code": 200,
                                    "data": {
                                        "status_code": 200,
                                        "status": "Success",
                                        "message": "OTP send",
                                        "phone_number": "+911234567890",
                                    },
                                    "error": None
                            }
                        }
                    }
                }
            }
        }
    },

        409: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "login validation": {
                            "summary": "otp issue",
                            "value": {
                        "detail" : {
		            	 "status": "Error",
		                "status_code": 409,
		                "data": None,
		                "error": {
		                    "status_code": 409,
		                    "status": "Error",
		                    "message": "Could not send otp to +911234567890"
                                }
                            },
                        }
                    }
                }
            }
        },
    }

}


user_phone_login_verify_otp_response = {

        200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "detail" : {
                            "summary" : "User registered Successfully",
                            "value" : {
                                "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "OTP Verified Successfully",
                                    "access_token": "qwertyuiopasdfghjkl",
                                    "refresh_token": "lkjhgfdsapoiuytrewq",
                                    "id": 1,
                                    "full_name": "Test Test",
                                    "email": "test@example.com",
                                    "phone_number": "+911234567890",
                                },
                            "error": None
                                }
                            }
                        }
                    }
                }

            }
        },

        
        401: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "login validation": {
                            "summary": "otp issue",
                            "value": {
                        "detail" : {
		            	 "status": "Error",
                "status_code": 401,
                "data": None,
                "error": {
                    "status_code": 401,
                    "status": "Error",
                    "message": "OTP is not valid"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

}


user_phone_login_verify_otp_token_response = {

    200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "detail" : {
                            "summary" : "User login Successfully",
                            "value" : {
                                "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "User login Successfully",
                                    "id":1,
                                    "full_name": "Test Test",
                                    "email": "test@example.com",
                                    "phone_number": "+911234567890",
                                },
                                "error": None
                                }
                            }
                        }
                    }
                }
            }
        },

        404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "login validation": {
                            "summary": "No user found",
                            "value": {
                        "detail" : {
		            	 "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "No user found"
                                }
                            }
                        }
                    }
                }
            }
        }
    }

}

refresh_token_response = {

            201: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "detail" : {
                            "summary" : "refresh token",
                            "value" : {"detail": {
            "status": "Success",
            "status_code": 201,
                "data": {
                "status_code": 201,
                "status": "Success",
                "message": "refresh token",
                "token" : "qwertyuiopasdfghjkl"
                },
            "error": None
                            }
                        }
                    }
                }
            }
        }
    },

        404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "not found": {
                            "summary": "No user found",
                            "value": {
                        "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "No user found"
                                }
                            }
                        }
                    }
                }
            }
        }
}

user_forgot_password_response = {

      200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "details" : {
                            "summary" : "mail send successfully",
                            "value" : {
                            	"detail": {
                                    "status": "Success",
                                    "status_code": 200,
                                    "data": {
                                        "status_code": 200,
                                        "status": "Success",
                                        "message": "mail send successfully",
                                        "status":"Sucess",
                                        "email": "test@example.com",
                                        "key": "qwertyuiopasdfghjkl",

                                    },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    },


        400: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "details": {
                            "summary": "Token not updated",
                            "value": {
                            "detail" : {
                        "status": "Error",
                    "status_code": 400,
                    "data": None,
                    "error": {
                        "status_code": 400,
                        "status": "Error",
                        "message": "Token not updated"
                                }
                            },
                        }
                    }
                }
            }
        },
    },


        404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "details": {
                            "summary": "Email not registered",
                            "value": {
                            "detail" : {
                        "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "Email not registered"
                                }
                            },
                        }
                    }
                }
            }
        }
    }

}


user_reset_password_response = {

        400: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "password validaton": {
                            "summary": "password validation error",
                            "value": {
                            "detail" : {
                        "status": "Error",
                        "status_code": 400,
                        "data": None,
                        "error": {
                            "status_code": 400,
                            "status": "Error",
                            "message": """Password must be at least 8 characters long, contains atleast one lower case character, one 
                            upper case character, one digit and one special case character."""
                        }
                    }
                }
            },

                        "Password not updated": {
                            "summary": "Password not updated",
                            "value": {
                            "detail" : {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message": "Password not updated"
                                }
                            },
                    }
            },

                        "Token expired": {
                            "summary": "Token expired",
                            "value": {
                            "detail" : {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message": "Token expired"
                                    }
                                },

                            }
                    }
                }
            }
        }
    },
       

        201: {
                    "description": "Success",
                    "content": {
                        "application/json": {
                            "examples": {
                                "details" : {
                                    "summary" : "Password reset successfully",
                                    "value" : {
                                    "detail": {
                                        "status": "Success",
                                        "status": "Success",
                                        "status_code": 201,
                                        "data": {
                                            "status_code": 201,
                                            "status": "Success",
                                            "message": "Password reset successfully"
                                            },
                            "error": None
                                },
                            }
                        }
                    }
                }, 
            }
        },

        404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "details": {
                            "summary": "Invalid user",
                            "value": {
                            "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message": "Invalid user"
                                    }
                                },
                            }
                        }
                    }
                }
            },
        }
}


user_change_pin_response = {

        404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "details": {
                            "summary": "Invalid user",
                            "value": {
                            "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message": "Invalid user"
                                }
                            }
                        }
                },

                        "Pin not added": {
                        "summary": "Pin not added",
                        "value": {
                            "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message": "Pin not added"
                                }
                            },
                        }
                  }
                }
            }
        }
    },


        201: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "details" : {
                            "summary" : "Pin changed",
                            "value" : {
                            	"detail": {
                                    "status": "Success",
                                    "status_code": 201,
                                    "data": {
                                        "status_code": 201,
                                        "status": "Success",
                                        "message": "Pin changed"
                                    },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    },

        400: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "details": {
                            "summary": "Pin not changed",
                            "value": {
                            "detail" : {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message": "Pin not changed"
                                    }
                                }
                            }
                        },
            
        
                        "wrong pin": {
                            "summary": "wrong pin",
                            "value": {
                                "detail" : {
                                    "status": "Error",
                                    "status_code": 400,
                                    "data": None,
                                    "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message": "Wrong pin"
                                        }
                                    },
                                }
                            },

                        "validation pin": {
                        "summary": "validation pin",
                            "value": {
                            "detail" : {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message": "Pin number must be 4 character and numeric"
                                    }
                                }
                            }
                        }
                    }
            
                }
            }
        },           

        409: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "same pin": {
                            "summary": "same pin",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 409,
                                "data": None,
                                "error": {
                                    "status_code": 409,
                                    "status": "Error",
                                    "message": "New pin and Reenter pin must be same"
                                }
                            }
                        }
                    }
                }
            }
        }
    }

}

user_change_password_response = {


        400: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "password validation": {
                            "summary": "password validation",
                            "value": {
                            "detail" : {
                       "status": "Error",
                        "status_code": 400,
                        "data": None,
                        "error": {
                            "status_code": 400,
                            "status": "Error",
                            "message": """Password must be at least 8 characters long, contains atleast one lower case character, one 
                                                        upper case character, one digit and one special case character."""
                            }
                        }
                    }
                },

                        "Password not changed": {
                            "summary": "Password not changed",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message": "Password not changed"
                                    }
                                },
                            }
                        },

                        "wrong password": {
                            "summary": "wrong password",
                            "value": {
                            "detail" : {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message": "Wrong password"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },



         201: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "details" : {
                            "summary" : "Password changed",
                            "value" : {
                            	"detail": {
                                "status": "Success",
                                "status_code": 201,
                                "data": {
                                    "status_code": 201,
                                    "status": "Success",
                                    "message": "Password changed"
                                    },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    },


        409: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "password validation": {
                            "summary": "same password",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 409,
                                "data": None,
                                "error": {
                                    "status_code": 409,
                                    "status": "Error",
                                    "message": "New password and Reenter password must be same"
                                    }
                            }
                        }
                    }
                }
            }
        }
    },

        404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "not found": {
                            "summary": "Invalid User",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message": "Invalid User"
                                }
                            }
                        }
                    }
                }
            }
        }

    }
}

user_logout_response = {

         200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "details" : {
                            "summary" : "logout",
                            "value" : {
                            	"detail": {
                                    "status": "Success",
                                    "status_code": 200,
                                    "data": {
                                        "status_code": 200,
                                        "status": "Success",
                                        "message": "Successfully logged out",
                                    },
                                    "error": None
                                },
                            }
                        }
                    }
                },
            }
        },

        404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "not found": {
                            "summary": "Invalid User",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code" : 404,
                                "data": None,
                                "error" : {
                                    "status_code" : 404,
                                    "status":"Error",
                                    "message" : "Invalid User",
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
}


generate_otp_response = {


    400: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "exist": {
                            "summary": "exist",
                            "value": {
                                "detail" : {
                                    "status": "Error",
                                    "status_code" : 400,
                                    "data": None,
                                    "error" : {
                                        "status_code" : 400,
                                        "status":"Error",
                                        "message" : "Phone number already registered.",
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },


         200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "details" : {
                            "summary" : "Password changed",
                            "value" : {
                                "detail": {
                                    "status": "Success",
                                    "status_code": 200,
                                    "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "OTP send to the number +911234567890",
                                },
                                "error": None
                            }
                        }
                    }
                }
            }
        }

    },


        502: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "otp failed": {
                            "summary": "OTP failed",
                            "value": {
                                "detail" : {
                                    "status": "Error",
                                    "status_code" : 502,
                                    "data": None,
                                    "error" : {
                                        "status_code" : 502,
                                        "status":"Error",
                                        "message" : "OTP generation failed.",
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

}


verify_otp_response = {

        408: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "otp timeout": {
                            "summary": "OTP timeout",
                            "value": {
                                "detail" : {
                                    "status": "Error",
                                    "status_code" : 408,
                                    "data": None,
                                    "error" : {
                                        "status_code" : 408,
                                        "status":"Error",
                                        "message" : "OTP verification timed out.",
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },


        200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "details" : {
                            "summary" : "OTP verified successfully",
                            "value" : {
                            	"detail": {
                                    "status": "Success",
                                    "status_code": 200,
                                    "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "OTP verified successfully",
                                    "user": {
                                        "id" : 1,
                                        "full_name" : "Test Test",
                                        "email" : "test@example.com",
                                        "phone_number" : "+911234567890",
                                        "referral_code" : "abcdef",
                                        "referred_by" : "whoreferred",
                                        "blocked" : False,
                                        "deleted" : False,
                                        "created_at" : "2023-02-08 14:32:57.523255",
                                        "updated_at" : "2023-02-08 14:32:57.523281"
                                        }
                                },
                                "error": None
                    }
                }
            },

                        "otp without" : {
                            "summary" : "OTP verified successfully without",
                            "value" : {
                            	"detail": {
                                    "status": "Success",
                                    "status_code": 200,
                                    "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "OTP verified successfully",
                                    "user": {
                                        "id" : 1,
                                        "full_name" : "Test Test",
                                        "email" : "test@example.com",
                                        "phone_number" : "+911234567890",
                                        "referral_code" : "abcdef",
                                        "referred_by" : "whoreferred",
                                        "blocked" : False,
                                        "deleted" : False,
                                        "created_at" : "2023-02-08 14:32:57.523255",
                                        "updated_at" : "2023-02-08 14:32:57.523281"
                                        },
                                "error": None
                                }
                            }
                        }
                    }
                }
            }
        }
    },
        

        404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "wrong otp": {
                            "summary": "Wrong OTP Code",
                            "value": {
                                "detail" : {
                                    "status": "Error",
                                    "status_code" : 404,
                                    "data": None,
                                    "error" : {
                                        "status_code" : 404,
                                        "status":"Error",
                                        "message" : "OTP verification timed out."
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
}


refer_user_response = {

        200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "details" : {
                            "summary" : "referral code",
                            "value" : {
                            	"detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "fetched referral code Successfully",
                                    "referral_code": "abcdef",
                                    },
                                "error": None
                                }
                            }
                        }
                    }
                }
            }
        }
}


recent_referrals_responses = {

          200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "details" : {
                            "summary" : "recent referral",
                            "value" : {
                            	"detail": {
                                    "status": "Success",
                                    "status_code": 200,
                                    "data": {
                                        "status_code": 200,
                                        "status": "Success",
                                        "message": "fetched referred users Successfully",
                                        "referred_users": {
                                            "full_name" : "Test Test",
                                            "id" : 1,
                                            "profile_image" : "Image",
                                            "created_at" : "2023-02-08 14:32:57.523255"
                                        },
                                    },
                                "error": None
                            }
                        }
                    }
                }
            }  
        }          
    }
}


add_pin_responses = {

         200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "details" : {
                            "summary" : "Pin added Successfully",
                            "value" : {
                            	"detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "Pin added Successfully",
                                },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    },


        409: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {

                        "error": {
                            "summary": "Error while adding pin",
                            "value": {
                                "detail" : {
                                    "status": "Error",
                                "status_code" : 409,
                                "data": None,
                                "error" : {
                                    "status_code" : 409,
                                    "status":"Error",
                                    "message" : "Error while adding pin"
                                    }
                            	}
                            }
                        },


                        "pin conflict": {
                            "summary": "same pin",
                            "value": {
                                "detail" : {
                                     "status": "Error",
                            "status_code" : 409,
                            "data": None,
                            "error" : {
                                "status_code" : 409,
                                "status":"Error",
                                "message" : "Two pin must be same",
                                }
                            }
                        }
                    },

                        "exist": {
                            "summary": "exist",
                            "value": {
                                "detail" : {
                                     "status": "Error",
                            "status_code" : 409,
                            "data": None,
                            "error" : {
                                "status_code" : 409,
                                "status":"Error",
                                "message" : "Already pin exists",
                                }
                            }
                        }
                    } 
                }
            }
        }
    },


         411: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "details": {
                            "summary": "Length issue",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code" : 411,
                                "data": None,
                                "error" : {
                                    "status_code" : 411,
                                    "status":"Error",
                                    "message" : "Length of pin must be equal to 4 and numeric",
                                }
                            }
                        }
                    }
                }
            }
        }
    },


         404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "not found": {
                            "summary": "No user found",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code" : 404,
                                "data": None,
                                "error" : {
                                    "status_code" : 404,
                                    "status":"Error",
                                    "message" : "No user found",
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
}


file_upload_repsonses = {

         404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "not found": {
                            "summary": "no user",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code" : 404,
                                "data": None,
                                "error" : {
                                    "status_code" : 404,
                                    "status":"Error",
                                    "message" : "Invalid User",
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },


        500: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "details": {
                            "summary": "File upload failed",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code" : 500,
                                "data": None,
                                "error" : {
                                    "status_code" : 500,
                                    "status":"Error",
                                    "message" : "File upload failed",
                                }
                            }
                        }
                    }
                }
            }
        }
    },

          200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "details" : {
                            "summary" : "file uploaded",
                            "value" : {
                            	"detail": {
                                    "status": "Success",
                                    "status_code": 200,
                                    "data": {
                                        "status_code": 200,
                                        "status": "Success",
                                        "message": "File uploaded Successfully",
                                        "file_id": "qwerty1234"
                                },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    }


}



file_download_responses ={



        404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "not found": {
                            "summary": "no user",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code" : 404,
                                "data": None,
                                "error" : {
                                    "status_code" : 404,
                                    "status":"Error",
                                    "message" : "Invalid User",
                                }
                            }
                        }
                    },

                        "details": {
                            "summary": "No file",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code" : 404,
                                "data": None,
                                "error" : {
                                    "status_code" : 404,
                                    "status":"Error",
                                    "message" : "File doesn't exist",
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },


        500: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "details": {
                            "summary": "File download failed",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code" : 500,
                                "data": None,
                                "error" : {
                                    "status_code" : 500,
                                    "status":"Error",
                                    "message" : "File download failed",
                                }
                            }
                        }
                    }
                }
            }
        }
    },

        200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "details" : {
                            "summary" : "file download",
                            "value" : {
                                "file" : "file",
                        "error": None
                        }
                    }
                }
            }
        }
    }


}


file_delete_reponses = {


        404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {

                        "not found": {
                            "summary": "Invalid User",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code" : 404,
                                "data": None,
                                "error" : {
                                    "status_code" : 404,
                                    "status":"Error",
                                    "message" : "Invalid User",
                                }
                            }
                        }
                    },

                        "no file": {
                            "summary": "File doesn't exist",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code" : 404,
                                "data": None,
                                "error" : {
                                    "status_code" : 404,
                                    "status":"Error",
                                    "message" : "File doesn't exist",
                                }
                            }
                        }
                    }
                }
            }
        }
    },


         500: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "details": {
                            "summary": "File deletion failed",
                            "value": {
                                "detail" : {
                                "status": "Error",
                                "status_code" : 500,
                                "data": None,
                                "error" : {
                                    "status_code" : 500,
                                    "status":"Error",
                                    "message" : "File deletion failed",
                                }
                            }
                        }
                    }
                }
            }
        }
    },

         200: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "details" : {
                            "summary" : "deleted",
                            "value" : {
                            	"detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "File deleted Successfully",
                                },
                                "error": None
                            }
                        }
                    }
                }
            }       
        }
    }

}

















