from pydantic import BaseModel, Field
from datetime import date
from core.models.mixin import GenderType

from core.api.merchant.schema import (
    MerchantInfo, 
    MerchantInfoUpdate, 
    BusinessInfo, 
    BusinessInfoUpdate, 
    MerchantTaxinformation, 
    MerchantUpdateTaxinformation, 
    BankDetails ,
    BankUpdateDetails
    )

class CreateMerchantProfile(MerchantInfo):
    users_id : int | None = Field(default = None, description="id in users")
    sales_person_id : int | None = Field(default=None, description="id in sale person ")

    class Config:
        schema_extra = {
            "example": {
                "users_id": 45,
                "sales_person_id" : 1,
                "merchant_account_number": "123456789",
                "authorized_person": 1,
                "dob": "1995-01-01",
                "gender": 1,
                "profile_image": "url",
            },
        }

class UpdateMerchantProfile(MerchantInfoUpdate):
    full_name : str | None = Field(default=None, description="full name") 
    merchant_id : int | None = Field(default=None, description="id in merchant") 

    class Config:
        schema_extra = {
            "example": {
                "full_name" : "test",
                "merchant_id": 40,
                "merchant_account_number": "123456789",
                "authorized_person": 1,
                "dob": "1995-01-01",
                "gender": 1,
                "profile_image": "url",
                },
        }


class CreateBusinessInfo(BusinessInfo):
    merchant_id : int = Field(default =None, description="id in merchant")

    class Config:
        schema_extra = {
            "example": {
                "merchant_id": 40,
                "registered_business_name": "NAME",
                "registered_business_number": "1234qwerty",
                "website": "url",
                "business_description": "Sports item is Availabe",
                "business_category": "Sport Shop",
                "dba" : "Trade Name",
                "address" : "NAME @",
                "operating_address" : "NAME @",
                "postal_code" : "12345",
                "operating_postal_code" : "12345" 
                 },
        }

class SalesPerson(BaseModel):
    sales_person_id : str | None = Field(default = None, description="id in merchant")

    class Config:
        schema_extra = {
            "example": {
                "sales_person_id": 40            
                },
        }

class UpdateBusinessInfo(BusinessInfoUpdate):
    merchant_id : int | None = Field(default=None, description="id in merchant")

    class Config:
        schema_extra = {
            "example": {
                "merchant_id": 40,
                "registered_business_name": "NAME",
                "registered_business_number": "1234qwerty",
                "website": "url",
                "business_description": "Sports item is Availabe",
                "business_category": "Sport Shop",
                "dba" : "Trade Name",
                "address" : "NAME @",
                "operating_address" : "NAME @",
                "postal_code" : "12345",
                "operating_postal_code" : "12345"           
                  },
        }

class CreateMerchantTaxInformation(MerchantTaxinformation):
    merchant_id : int = Field(default = None, description="id in merchant")

    class Config:
        schema_extra = {
            "example": {
                "merchant_id": 40,
                "name_on_pan": "NAME",
                "pan_number": "1234qwerty",
                "gstin_doc": "url",
                "pan_doc": "url",
                "tan_doc": "url",
                "id_proof" : "1234qwerty",
                "id_proof_type" : 1,
                "id_proof_doc" : "url",
                "address_proof" : "1234qwerty",
                "address_proof_type" : 1,
                "address_proof_doc" : "url"            
                },
        }

class UpdateTaxInformation(MerchantUpdateTaxinformation):
    merchant_id : int | None = Field(default=None, description="id in merchant")

    class Config:
        schema_extra = {
            "example": {
                "merchant_id": 40,
                "name_on_pan": "NAME",
                "pan_number": "1234qwerty",
                "gstin_doc": "url",
                "pan_doc": "url",
                "tan_doc": "url",
                "id_proof" : "1234qwerty",
                "id_proof_type" : 1,
                "id_proof_doc" : "url",
                "address_proof" : "1234qwerty",
                "address_proof_type" : 1,
                "address_proof_doc" : "url"            
                },
        }

class CreateBankDetails(BankDetails):
    merchant_id : int = Field(default = None, description="id in merchant")

    class Config:
        schema_extra = {
            "example": {
                "merchant_id": 40,
                "current_account_name": "NAME",
                "account_number": "123456789",
                "ifsc_number": "XX22XX",
                "branch_name": "Place",
                "bank_name": "NAME"            
                },
        }

class UpdateBankDetails(BankUpdateDetails):
    merchant_id : int | None = Field(default=None, description="id in merchant")

    class Config:
        schema_extra = {
            "example": {
                "merchant_id": 40,
                "current_account_name": "NAME",
                "account_number": "123456789",
                "ifsc_number": "XX22XX",
                "branch_name": "Place",
                "bank_name": "NAME"            
                },
        }

class MerchantId(BaseModel):
    merchant_id : int = Field(default=None, description="id in merchant")

    
    class Config:
        schema_extra = {
            "example": {
                "merchant_id": 40            
                },
        }


create_merchant_profile_responses = {

    404 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "User not exist",
                        "value" : {
                            "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message": "User not exists."
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    409 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant already exists.",
                        "value" : {
                            "detail" : {
                                "status": "Error",
                                "status_code": 409,
                                "data": None,
                                "error": {
                                    "status_code": 409,
                                    "status": "Error",
                                    "message": "Merchant already exists.",
                                    "merchant_id" : 1
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant added successfully",
                        "value" : {
                            "detail" : {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message" : "Merchant added successfully",
                                    "merchant_id" : 1
                                },
                            "error": None
                            }
                        }
                    }               
                }
            }
        }
    },

    400 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant not added",
                        "value" : {
                            "detail" : {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message" : "Merchant not added"
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

display_merchant_profile_response = {

    404 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Sales person id not given",
                        "value" : {
                            "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Sales person id not given"
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant profile",
                        "value" : {
                            "detail" : {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "Merchant profile",
                                    "merchant_profile" : [
                                        {
                                        "users_id": 1,
                                        "full_name": "test",
                                        "email": "test@gmail.com",
                                        "phone_number": "+919087654321",
                                        "id": 1,
                                        "merchant_account_number": "123456789",
                                        "merchant_name": None,
                                        "authorized_person": "1",
                                        "kyc_doc_type": None,
                                        "kyc_doc": None,
                                        "channel_partner_id": None,
                                        "dob": "1995-01-01",
                                        "gender": 1,
                                        "profile_image": "url"
                                        }
                                    ]
                                },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    }
}

update_merchant_profile_response = {

    404 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "not_registered" : {
                        "summary" : "Merchant not registered",
                        "value" : {
                            "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Merchant not registered"
                                }
                            }
                        }
                    },
                    "detail" : {
                        "summary" : "Merchant id must be enter",
                        "value" : {
                            "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Merchant id must be enter"
                                }
                            }
                        }
                    },
                    "no_data" : {
                        "summary" : "No data to update",
                        "value" : {
                            "detail" : {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "No data to update"
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Profile created Successfully",
                        "value" : {
                            "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "Profile created Successfully",
                                    "merchant_id" : 1
                                },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    },

    400 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Not updated",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message" : "Not updated"
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


create_merchant_business_response = {

    404 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant not exist",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Merchant not exist"
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    409 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant business info already exist",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 409,
                                "data": None,
                                "error": {
                                    "status_code": 409,
                                    "status": "Error",
                                    "message" : "Merchant business info already exist",
                                    "merchant_id" : 1
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant business info created Successfully",
                        "value" : {
                            "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "Merchant business info created Successfully",
                                    "merchant_id" : 1
                                },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    },

    400 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant business info not created",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message" : "Merchant business info not created"
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

display_merchant_business_response = {

    404 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Sales person id not given",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Sales person id not given"
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Sales person id not given",
                        "value" : {
                            "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "Merchant business profile",
                                    "merchant_business_profile" : [
                                        {
                                        "id": 1,
                                        "merchant_id": 1,
                                        "registered_business_name": "NAME",
                                        "registered_business_number": "1234qwerty",
                                        "website": "url",
                                        "business_description": "All items are Availabe",
                                        "business_category": 1,
                                        "address": "NAME @",
                                        "postal_code": "12345"
                                        }
                                    ]
                                },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    }
}

update_merchant_business_response = {

    404 :  {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "merchant_profile" : {
                        "summary" : "Merchant profile not exist",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Merchant profile not exist"
                                }
                            }
                        }
                    },
                    "merchant_business" : {
                        "summary" : "Merchant business info not exist",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Merchant business info not exist"
                                }
                            }
                        }
                    },
                    "no_data" : {
                        "summary" : "No data to update",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "No data to update"
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Successfully updated merchant business profile",
                        "value" : {
                            "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "Successfully updated merchant business profile",
                                    "merchant_id" : 1
                                },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    },

    400 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant business profile not updated",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message" : "Merchant business profile not updated"
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


create_merchant_tax_info_responses = {

    404 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant not exist",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Merchant not exist"
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    409 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant tax information already exist",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 409,
                                "data": None,
                                "error": {
                                    "status_code": 409,
                                    "status": "Error",
                                    "message" : "Merchant tax information already exist",
                                    "merchant_id" : 1
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant_Tax_Info added successfully",
                        "value" : {
                            "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message" : "Merchant_Tax_Info added successfully",
                                    "merchant_id" : 1
                                },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    },
    400 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant tax information not added",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message" : "Merchant tax information not added"
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

display_merchant_tax_info_responses = {
    404 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Sales person id not given",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Sales person id not given"
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant tax information",
                        "value" : {
                            "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "Merchant tax information",
                                    "merchant_tax_info" : [
                                        {
                                        "id": 1,
                                        "merchant_id": 1,
                                        "name_on_pan": "NAME",
                                        "pan_number": "1234qwerty",
                                        "pan_doc": "url",
                                        "gstin_doc": "url",
                                        "tan_doc": "url",
                                        "id_proof": "1234qwerty",
                                        "id_proof_type": 1,
                                        "id_proof_doc": "url",
                                        "address_proof": "1234qwerty",
                                        "address_proof_type": 1,
                                        "address_proof_doc": "url"
                                        }
                                    ]
                                },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    }
}


update_merchant_tax_info_responses = {

    404 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "merchant_not_exist" : {
                        "summary" : "Merchant not exist",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Merchant not exist"
                                }
                            }
                        }
                    },
                    "merchant_tax_not_exist" : {
                        "summary" :"Merchant tax information not exist",
                        "value" : {
                            "detail": {
                               "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Merchant tax information not exist"
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant tax info updated successfully",
                        "value" : {
                            "detail": {
                                "detail": {
                                    "status": "Success",
                                    "status_code": 200,
                                    "data": {
                                        "status_code": 200,
                                        "status": "Success",
                                        "message" : "Merchant tax info updated successfully",
                                        "merchant_id" : 1
                                    },
                                    "error": None
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    400 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant tax info not updated",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message" : "Merchant tax info not updated"
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

create_merchant_bank_details_responses = {

    404 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant not exist",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Merchant not exist"
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    409 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Bank details already exist",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 409,
                                "data": None,
                                "error": {
                                    "status_code": 409,
                                    "status": "Error",
                                    "message" : "Bank details already exist",
                                    "merchant_id" : 1
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Bank details created Successfully",
                        "value" : {
                            "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "Bank details created Successfully",
                                    "merchant_id" : 1
                                },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    },

    400 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "bank details not created",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message" : "bank details not created"
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

display_merchant_bank_detail_response = {

    404 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Sales person id not given",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Sales person id not given"
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Merchant bank detail",
                        "value" : {
                            "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "Merchant bank detail",
                                    "merchant_bank_detail" : [
                                        {
                                        "id": 6,
                                        "merchant_id": 21,
                                        "current_account_name": "NAME",
                                        "account_number": "123456789",
                                        "ifsc_number": "XX22XX",
                                        "branch_name": "Place",
                                        "bank_name": "NAME"
                                        }
                                    ]
                                },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    }
}

update_merchant_bank_detail_response = {

    404 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "merchant_mot_exist" : {
                        "summary" : "Merchant not exist",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Merchant not exist"
                                }
                            }
                        }
                    },
                    "bank_detail_not_exist" : {
                        "summary" : "Bank details not exist",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "Bank details not exist"
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Bank details Successfully updated",
                        "value" : {
                            "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                "status_code": 200,
                                "status": "Success",
                                "message": "Bank details Successfully updated",
                                "merchant_id" : 1
                                },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    },

    400 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Bank details not updated",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message" : "Bank details not updated"
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

file_upload_response = {

    500 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "File upload failed",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 500,
                                "data": None,
                                "error": {
                                    "status_code": 500,
                                    "status": "Error",
                                    "message" : "File upload failed"
                                }
                            }
                        }
                    }
                }
            }
        }
    },
    
    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "File uploaded Successfully",
                        "value" : {
                            "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "File uploaded Successfully",
                                    "file_id": '1as23d'
                                },
                            "error": None
                            }
                        }
                    }
                }
            }
        }
    }
}


file_download_response = {

    404 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "File doesn't exist",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "File doesn't exist"
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    500 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "File download failed",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 500,
                                "data": None,
                                "error": {
                                    "status_code": 500,
                                    "status": "Error",
                                    "message" : "File download failed"
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "File download Successfully",
                        "value" : {
                            "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "File download Successfully"
                                },
                            "error": None
                            }
                        }
                    }
                }
            }
        }
    }
}


file_delete_response = {

    404 : {
       "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "File doesn't exist",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "File doesn't exist"
                                }
                            }
                        }
                    }
                }
            }
        } 
    },

    500 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "File download failed",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 500,
                                "data": None,
                                "error": {
                                    "status_code": 500,
                                    "status": "Error",
                                    "message" : "File download failed"
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "File download Successfully",
                        "value" : {
                            "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                        "status_code": 200,
                                        "status": "Success",
                                        "message": "File deleted Successfully",
                                    },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    }
}

display_merchant_detail_response = {

    404 : {
        "description" : "Error",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "There is no merchant id",
                        "value" : {
                            "detail": {
                                "status": "Error",
                                "status_code": 404,
                                "data": None,
                                "error": {
                                    "status_code": 404,
                                    "status": "Error",
                                    "message" : "There is no merchant id"
                                }
                            }
                        }
                    }
                }
            }
        } 
    },

    200 : {
        "description" : "Success",
        "content" : {
            "application/json" : {
                "examples" : {
                    "detail" : {
                        "summary" : "Display merchant details",
                        "value" : {
                            "detail": {
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "Display merchant details",
                                    'merchant' :  {
                                        "users_id": 1,
                                        "full_name": "test",
                                        "email": "test@gmail.com",
                                        "phone_number": "+919087654321",
                                        "id": 1,
                                        "merchant_account_number": "123456789",
                                        "merchant_name": None,
                                        "authorized_person": "1",
                                        "kyc_doc_type": None,
                                        "kyc_doc": None,
                                        "channel_partner_id": None,
                                        "dob": "1995-01-01",
                                        "gender": 1,
                                        "profile_image": "url"
                                        },
                                    'business' : {
                                        "created_at": "2023-02-08T10:04:50.212808",
                                        "merchant_id": 21,
                                        "registered_business_number": "1234qwerty",
                                        "business_description": "Sports item is Availabe",
                                        "dba": "Trade Name",
                                        "operating_address": "NAME @",
                                        "operating_postal_code": "12345",
                                        "id": 6,
                                        "updated_at": "2023-02-08T10:04:50.212907",
                                        "registered_business_name": "NAME",
                                        "website": "url",
                                        "business_category": 2,
                                        "address": "NAME @",
                                        "postal_code": "12345"
                                        },
                                    'tax' : {
                                        "merchant_id": 1,
                                        "created_at": "2023-02-08T10:04:49.780584",
                                        "name_on_pan": "NAME",
                                        "pan_doc": "url",
                                        "tan_doc": "url",
                                        "id_proof_type": 1,
                                        "address_proof": "1234qwerty",
                                        "address_proof_doc": "url",
                                        "updated_at": "2023-02-08T10:04:49.780695",
                                        "id": 14,
                                        "pan_number": "1234qwerty",
                                        "gstin_doc": "url",
                                        "id_proof": "1234qwerty",
                                        "id_proof_doc": "url",
                                        "address_proof_type": 1
                                        },
                                    'bank' : {
                                        "created_at": "2023-02-08T10:04:50.212808",
                                        "merchant_id": 1,
                                        "account_number": "123456789",
                                        "branch_name": "Place",
                                        "current_account_name": "NAME",
                                        "updated_at": "2023-02-08T10:04:50.212907",
                                        "id": 6,
                                        "ifsc_number": "XX22XX",
                                        "bank_name": "NAME"
                                        }
                                    },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    }
}