from sqlalchemy.orm import Session, load_only

from core.api.sales_person.schema import CreateMerchantProfile, CreateBusinessInfo, CreateMerchantTaxInformation, CreateBankDetails
from core.api.users.crud import get_user_by_email, save_file, check_if_file_exists, retrieve_file, delete_file
from core.api.merchant.crud import check_if_merchant_exists
from core.api.merchant.models import MerchantProfile, MerchantBusinessInfo, MerchantTaxInformation, MerchantBankDetails
from core.api.users.models import Users

def check_if_sales_person_exists(db : Session, email : str):
    return get_user_by_email(db, email)


def check_if_merchant_exists(db : Session, users_id : int):
    return db.query(MerchantProfile).filter(MerchantProfile.users_id == users_id).first()


def check_merchant_exists(db : Session, merchant_id : int):
    return db.query(MerchantProfile).filter(MerchantProfile.id == merchant_id).first()


def create_merchant_profile( db : Session, merchant: CreateMerchantProfile, users_id : int, sales_person_id : int):
    db_user = MerchantProfile(
        users_id = users_id,
        sales_person_id = sales_person_id,
        merchant_account_number = merchant.merchant_account_number,
        authorized_person = merchant.authorized_person,
        dob = merchant.dob,
        gender = merchant.gender,
        profile_image = merchant.profile_image
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def check_if_user_exist(db : Session, users_id : int):
    return db.query(Users).filter(Users.id == users_id).first()


def display_merchant_profile( db : Session, sales_person_id : int):
    profile_data = db.query(MerchantProfile.users_id,Users.full_name,Users.email,Users.phone_number,MerchantProfile.id,MerchantProfile.merchant_account_number,MerchantProfile.merchant_name,
                            MerchantProfile.authorized_person,MerchantProfile.kyc_doc_type,MerchantProfile.kyc_doc,MerchantProfile.channel_partner_id,MerchantProfile.dob,\
                            MerchantProfile.gender,MerchantProfile.profile_image)\
                        .join(MerchantProfile, Users.id==MerchantProfile.users_id, isouter=True).filter(MerchantProfile.sales_person_id == sales_person_id).all()
    return profile_data

def update_merchant_profile(db : Session, profile_data : dict, id : int):
    result = db.query(MerchantProfile).filter(MerchantProfile.id == id).update(profile_data)
    db.commit()
    return result

def check_if_merchant_business_info_exist(db: Session, merchant_id : int):
    return db.query(MerchantBusinessInfo).filter(MerchantBusinessInfo.merchant_id == merchant_id).first()

def create_merchant_business_info(db: Session, merchant: CreateBusinessInfo):
    db_user = MerchantBusinessInfo(
        merchant_id = merchant.merchant_id,
        registered_business_name = merchant.registered_business_name,
        registered_business_number = merchant.registered_business_number,
        website = merchant.website,
        business_description = merchant.business_description,
        business_category = merchant.business_category,
        dba = merchant.dba,
        address = merchant.address,
        operating_address = merchant.operating_address,
        postal_code = merchant.postal_code,
        operating_postal_code = merchant.operating_postal_code
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def get_merchant_id(db : Session, sales_person_id : str):
    return db.query(MerchantProfile.id).filter(MerchantProfile.sales_person_id == sales_person_id).all()


def display_merchant_business_profile_info( db : Session, sales_person : str):
    data = db.query(MerchantBusinessInfo.id,MerchantBusinessInfo.merchant_id,MerchantBusinessInfo.registered_business_name,
                    MerchantBusinessInfo.registered_business_number,MerchantBusinessInfo.website,MerchantBusinessInfo.business_description,MerchantBusinessInfo.business_category,
                    MerchantBusinessInfo.address,MerchantBusinessInfo.postal_code)\
                        .join(MerchantProfile, MerchantBusinessInfo.merchant_id == MerchantProfile.id, isouter=True).filter(MerchantProfile.sales_person_id == sales_person).all()
    return data

def update_merchant_business_info(db : Session, merchant_id : int, updated_data : dict):
    result = db.query(MerchantBusinessInfo).filter(MerchantBusinessInfo.merchant_id == merchant_id).update(updated_data)
    db.commit()
    return result

def get_merchant_taxinfo_by_merchant_id(db : Session, merchant_id : int):
    return db.query(MerchantTaxInformation).filter(MerchantTaxInformation.merchant_id == merchant_id).first()

def add_merchant_taxinformation(db : Session, merchant_tax_info : CreateMerchantTaxInformation):
    db_taxinfo = MerchantTaxInformation(
        merchant_id = merchant_tax_info.merchant_id,
        name_on_pan = merchant_tax_info.name_on_pan,
        pan_number = merchant_tax_info.pan_number,
        pan_doc = merchant_tax_info.pan_doc,
        gstin_doc = merchant_tax_info.gstin_doc,
        tan_doc = merchant_tax_info.tan_doc,
        id_proof = merchant_tax_info.id_proof,
        id_proof_type = merchant_tax_info.id_proof_type,
        id_proof_doc = merchant_tax_info.id_proof_doc,
        address_proof = merchant_tax_info.address_proof,
        address_proof_type = merchant_tax_info.address_proof_type,
        address_proof_doc = merchant_tax_info.address_proof_doc
            )
    db.add(db_taxinfo) 
    db.commit()
    db.refresh(db_taxinfo)
    return db_taxinfo

def display_merchant_tax_information( db : Session, sales_person : str):
    data = db.query(MerchantTaxInformation.id,MerchantTaxInformation.merchant_id,MerchantTaxInformation.name_on_pan,MerchantTaxInformation.pan_number,
                        MerchantTaxInformation.pan_doc , MerchantTaxInformation.gstin_doc , MerchantTaxInformation.tan_doc , MerchantTaxInformation.id_proof,
                        MerchantTaxInformation.id_proof_type , MerchantTaxInformation.id_proof_doc , MerchantTaxInformation.address_proof , MerchantTaxInformation.address_proof_type,
                        MerchantTaxInformation.address_proof_doc)\
                        .join(MerchantProfile, MerchantTaxInformation.merchant_id == MerchantProfile.id, isouter=True).filter(MerchantProfile.sales_person_id == sales_person).all()
    return data

def update_merchant_taxinformation(db : Session, update_data : dict, merchant_id : int):
    result = db.query(MerchantTaxInformation).filter(MerchantTaxInformation.merchant_id == merchant_id).update(update_data)
    db.commit()
    return result

def check_if_bank_details_exist( db: Session ,merchant_id : int):
    return db.query(MerchantBankDetails).filter(MerchantBankDetails.merchant_id == merchant_id).first()

def create_bank_details(db : Session, bank_info : CreateBankDetails):
    db_user = MerchantBankDetails(
        merchant_id = bank_info.merchant_id, 
        current_account_name = bank_info.current_account_name,
        account_number = bank_info.account_number,
        ifsc_number = bank_info.ifsc_number,
        branch_name = bank_info.branch_name,
        bank_name = bank_info.bank_name
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def display_merchant_bank_details( db : Session, sales_person : str):
    data = db.query(MerchantBankDetails.id, MerchantBankDetails.merchant_id, MerchantBankDetails.current_account_name, MerchantBankDetails.account_number,
                    MerchantBankDetails.ifsc_number, MerchantBankDetails.branch_name, MerchantBankDetails.bank_name)\
                    .join(MerchantProfile,MerchantBankDetails.merchant_id == MerchantProfile.id, isouter = True).filter(MerchantProfile.sales_person_id == sales_person).all()
    return data

def update_merchant_bank_information(db : Session, merchant_id : int, update_data : dict):
    result = db.query(MerchantBankDetails).filter(MerchantBankDetails.merchant_id==merchant_id).update(update_data)
    db.commit()
    return result

def save_file_wrapper(mongo_db , collection : str, file_name: str, content : bytes, content_type : str):
    return save_file(mongo_db, collection, file_name, content, content_type)

def check__if_file_exists_wrapper(mongo_db, collection : str, file_id : str):
    return check_if_file_exists(mongo_db, collection, file_id)

def retrieve_file_wrapper(mongo_db, collection : str, file_id : str):
    return retrieve_file(mongo_db, collection, file_id)

def delete_file_wrapper(mongo_db, collection : str, file_id : str):
    return delete_file(mongo_db, collection, file_id)


def display_merchant_user( db : Session, merchant_id : int):
    profile_data = db.query(MerchantProfile.users_id,Users.full_name,Users.email,Users.phone_number,MerchantProfile.id,MerchantProfile.merchant_account_number,MerchantProfile.merchant_name,
                            MerchantProfile.authorized_person,MerchantProfile.kyc_doc_type,MerchantProfile.kyc_doc,MerchantProfile.channel_partner_id,MerchantProfile.dob,\
                            MerchantProfile.gender,MerchantProfile.profile_image)\
                        .join(MerchantProfile, Users.id==MerchantProfile.users_id, isouter=True).filter(MerchantProfile.id == merchant_id).first()
    return profile_data

def update_users_full_name(db : Session,full_name : str, users_id : int):
    return db.query(Users).filter(Users.id == users_id).update({"full_name":full_name})
