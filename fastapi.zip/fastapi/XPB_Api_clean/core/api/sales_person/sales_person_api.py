from fastapi import APIRouter, Depends, HTTPException, Form, UploadFile
from sqlalchemy.orm import Session
from fastapi.responses import Response
from fastapi.security.api_key import APIKey

from core.api.sales_person import crud, schema
from core.jwt import auth_handler
from core.jwt.auth_bearer import JWTBearer
from core.database.connection import get_db, get_mongo_db
from core.api.users.user_api import create_user_api
from core.jwt import auth_api_key
from core.api.users.crud import check_if_file_exists, delete_file
router = APIRouter()


''' Create a new merchant and added to users table'''

@router.post("/create_merchant_profile", status_code = 200, tags = ["Sales Person"],responses = schema.create_merchant_profile_responses)
async def create_merchant_profile(merchant : schema.CreateMerchantProfile,  api_key : APIKey = Depends(auth_api_key.get_api_key),db: Session = Depends(get_db)):
    user = crud.check_if_user_exist(db = db, users_id = merchant.users_id)
    if not user :
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User not exists."
                    }
                }
            )
    merchant_details = crud.check_if_merchant_exists(db = db, users_id = merchant.users_id)
    if merchant_details :
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "Merchant already exists.",
                    "merchant_id" : merchant_details.id
                    }
            }
        )
    create_merchant = crud.create_merchant_profile(db = db, merchant = merchant, users_id = user.id, sales_person_id = merchant.sales_person_id)
    if create_merchant :
        response_msg = {
                "detail": {
                        "status": "Success",
                        "status_code": 200,
                        "data": {
                            "status_code": 200,
                            "status": "Success",
                            "message" : "Merchant added successfully",
                            "merchant_id" : create_merchant.id
                        },
                        "error": None
                    }
                }
        return response_msg
    else:
        raise HTTPException (
            status_code = 400,
            detail = {
                "status": "Error",
                "status_code": 400,
                "data": None,
                "error": {
                    "status_code": 400,
                    "status": "Error",
                    "message" : "Merchant not added"
                }
            }
        )

''' Dispaly Merchant list under a sales person'''

@router.post("/display_merchant_profile",status_code = 200, tags = ["Sales Person"], responses = schema.display_merchant_profile_response)
async def display_merchant_profile(sales_person : schema.SalesPerson, api_key : APIKey = Depends(auth_api_key.get_api_key),db: Session = Depends(get_db)):
    if not sales_person.sales_person_id:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Sales person id not given"
                }
            }
        )
    merchant_details = crud.display_merchant_profile(db = db,sales_person_id = sales_person.sales_person_id)
    response_msg = {
                "detail": {
                    "status": "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message": "Merchant profile",
                        "merchant_profile" : merchant_details
                    },
                    "error": None
                }
            }
    return response_msg



''' Update merchant profile'''

@router.put("/update_merchant_profile",status_code = 200, tags = ["Sales Person"], responses = schema.update_merchant_profile_response)
async def update_merchant_profile(merchant : schema.UpdateMerchantProfile, api_key : APIKey = Depends(auth_api_key.get_api_key),db: Session = Depends(get_db)):
    merchant_details = crud.check_merchant_exists(db = db, merchant_id = merchant.merchant_id)
    if not merchant_details :
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Merchant not registered"
                }
            }
        )
    if merchant.full_name:
        update_full_name = crud.update_users_full_name(db = db, full_name = merchant.full_name, users_id = merchant_details.users_id)
        if update_full_name :
            del merchant.full_name
    profile_data = merchant.dict(exclude_unset=True)
    if not profile_data['merchant_id']:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Merchant id must be enter"
                }
            }
        )
    del profile_data['merchant_id']
    if not profile_data :
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "No data to update"
                }
            }
        )
    update_merchant = crud.update_merchant_profile(db = db, profile_data = profile_data, id = merchant_details.id)
    if update_merchant :
        response_msg = {
                "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Merchant profie successfully updated",
                    "merchant_id" : merchant.merchant_id
                },
                "error": None
            }
        }
        return response_msg
    else :
        raise HTTPException (
            status_code = 400,
            detail = {
                "status": "Error",
                "status_code": 400,
                "data": None,
                "error": {
                    "status_code": 400,
                    "status": "Error",
                    "message" : "Not updated"
                }
            }
        )


@router.post("/create_merchant_business", status_code=200, tags=["Sales Person"], responses = schema.create_merchant_business_response)
async def create_merchant_business_info(profile_data : schema.CreateBusinessInfo, api_key : APIKey = Depends(auth_api_key.get_api_key), db: Session = Depends(get_db)):
    merchant = crud.check_merchant_exists(db = db, merchant_id = profile_data.merchant_id) 
    if not merchant:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Merchant not exist"
                }
            }
        )                           
    merchant_profile = crud.check_if_merchant_business_info_exist(db = db, merchant_id = profile_data.merchant_id)
    if merchant_profile :
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message" : "Merchant business info already exist",
                    "merchant_id" : profile_data.merchant_id
                }
            }
        )          
    consumer_profile = crud.create_merchant_business_info(db= db, merchant = profile_data)
    if consumer_profile:
        response_msg = {
                    "detail": {
                            "status": "Success",
                            "status_code": 200,
                            "data": {
                                "status_code": 200,
                                "status": "Success",
                                "message": "Merchant business info created Successfully",
                                "merchant_id" : profile_data.merchant_id
                            },
                            "error": None
                        }
                }
        return response_msg
    else:
        raise HTTPException (
            status_code = 400,
            detail = {
                "status": "Error",
                "status_code": 400,
                "data": None,
                "error": {
                    "status_code": 400,
                    "status": "Error",
                    "message" : "Merchant business info not created"
                }
            }
        )        
    

@router.post("/display_merchant_business_profile",status_code = 200, tags = ["Sales Person"], responses = schema.display_merchant_business_response)
async def display_merchant_business_profile(sales_person : schema.SalesPerson, api_key : APIKey = Depends(auth_api_key.get_api_key), db: Session = Depends(get_db)):
    if not sales_person.sales_person_id:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Sales person id not given"
                }
            }
        )     
    business_profile = crud.display_merchant_business_profile_info( db = db, sales_person = sales_person.__dict__['sales_person_id'])
    response_msg = {
                "detail": {
                    "status": "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message": "Merchant business profile",
                        "merchant_business_profile" : business_profile
                    },
                    "error": None
                }
            }
    return response_msg


@router.put("/update_merchant_business_profile",status_code = 200, tags = ["Sales Person"], responses = schema.update_merchant_profile_response)
async def update_meerchant_profile(profile_data : schema.UpdateBusinessInfo, api_key : APIKey = Depends(auth_api_key.get_api_key), db: Session = Depends(get_db)):
    merchant = crud.check_merchant_exists(db = db, merchant_id = profile_data.merchant_id) 
    if not merchant:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Merchant profile not exist"
                }
            }
        )                               
    merchant_profile = crud.check_if_merchant_business_info_exist(db = db, merchant_id = profile_data.merchant_id)
    if not merchant_profile :
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Merchant business info not exist"
                }
            }
        )   
    update_profile_data = profile_data.dict(exclude_unset=True)
    if not profile_data :
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "No data to update"
                }
            }
        )   
    merchant_business = crud.update_merchant_business_info(db= db, merchant_id = profile_data.merchant_id, updated_data = update_profile_data)
    if merchant_business:
        response_msg = {
                "detail": {
                    "status": "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message": "Successfully updated merchant business profile",
                        "merchant_id" : profile_data.merchant_id
                    },
                    "error": None
                }
            }
        return response_msg
    else:
        raise HTTPException (
            status_code = 400,
            detail = {
                "status": "Error",
                "status_code": 400,
                "data": None,
                "error": {
                    "status_code": 400,
                    "status": "Error",
                    "message" : "Merchant business profile not updated"
                }
            }
        )   


@router.post("/create_merchant_tax_info",status_code = 200, tags = ["Sales Person"], responses = schema.create_merchant_tax_info_responses)
async def create_merchant_tax_info(tax_info : schema.CreateMerchantTaxInformation, api_key : APIKey = Depends(auth_api_key.get_api_key), db : Session = Depends(get_db)):
    merchant = crud.check_merchant_exists(db = db, merchant_id = tax_info.merchant_id) 
    if not merchant:   
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Merchant not exist"
                }
            }
        )                           
    merchant_tax_info = crud.get_merchant_taxinfo_by_merchant_id(db=db, merchant_id = tax_info.merchant_id)
    if merchant_tax_info :
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message" : "Merchant tax information already exist",
                    "merchant_id" : tax_info.merchant_id
                }
            }
        )    
    add_merchant_taxinfo = crud.add_merchant_taxinformation(db = db, merchant_tax_info = tax_info)
    if add_merchant_taxinfo:
        response_msg = {
                "detail": {
                    "status": "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message" : "Merchant_Tax_Info added successfully",
                        "merchant_id" : tax_info.merchant_id
                    },
                    "error": None
                }
            }
        return response_msg
    else :
        raise HTTPException (
            status_code = 400,
            detail = {
                "status": "Error",
                "status_code": 400,
                "data": None,
                "error": {
                    "status_code": 400,
                    "status": "Error",
                    "message" : "Merchant tax information not added"
                }
            }
        )    


@router.post("/display_merchant_tax_info", status_code = 200, tags = ["Sales Person"], responses = schema.display_merchant_tax_info_responses)
async def display_merchant_tax_info(sales_person : schema.SalesPerson, api_key : APIKey = Depends(auth_api_key.get_api_key), db: Session = Depends(get_db)):
    if not sales_person.sales_person_id:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Sales person id not given"
                }
            }
        )    
    business_profile = crud.display_merchant_tax_information( db = db, sales_person = sales_person.__dict__['sales_person_id'])
    response_msg = {
                "detail": {
                    "status": "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message": "Merchant tax information",
                        "merchant_tax_info" : business_profile
                    },
                    "error": None
                }
            }
    return response_msg


@router.put("/update_merchant_tax_info", status_code = 200, tags = ["Sales Person"], responses = schema.update_merchant_tax_info_responses)
def update_merchant_tax_information(tax_info : schema.UpdateTaxInformation,  api_key : APIKey = Depends(auth_api_key.get_api_key), db : Session=Depends(get_db)):
    merchant = crud.check_merchant_exists(db = db, merchant_id = tax_info.merchant_id) 
    if not merchant:  
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Merchant profile not exist"
                }
            }
        )                            
    merchant_tax_info = crud.get_merchant_taxinfo_by_merchant_id(db=db, merchant_id = tax_info.merchant_id)
    if not merchant_tax_info :
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Merchant tax information not exist"
                }
            }
        )       
    update_profile_data = tax_info.dict(exclude_unset=True)
    update_merchant_taxinfo = crud.update_merchant_taxinformation(db = db, update_data=update_profile_data, merchant_id = update_profile_data['merchant_id'])
    if update_merchant_taxinfo:
        response_msg = {
                    "detail": {
                    "status": "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message" : "Merchant tax info updated successfully",
                        "merchant_id" : tax_info.merchant_id
                    },
                "error": None
            }
        }
        return response_msg
    else :
        raise HTTPException (
            status_code = 400,
            detail = {
                "status": "Error",
                "status_code": 400,
                "data": None,
                "error": {
                    "status_code": 400,
                    "status": "Error",
                    "message" : "Merchant tax info not updated"
                }
            }
        )      


@router.post("/create_merchant_bank_details", status_code = 200, tags = ["Sales Person"], responses = schema.create_merchant_bank_details_responses)
async def create_merchant_bank_details(bank_info : schema.CreateBankDetails, api_key : APIKey = Depends(auth_api_key.get_api_key), db : Session = Depends(get_db)):
    merchant = crud.check_merchant_exists(db = db, merchant_id = bank_info.merchant_id) 
    if not merchant: 
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Merchant not exist"
                }
            }
        )                              
    bank_details = crud.check_if_bank_details_exist(db = db, merchant_id = merchant.__dict__['id'])
    if bank_details:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message" : "Bank details already exist",
                    "merchant_id" : bank_info.merchant_id
                }
            }
        )     
    bank_details = crud.create_bank_details(db = db, bank_info = bank_info)
    if bank_details :
        response_msg = {
                    "detail": {
                        "status": "Success",
                        "status_code": 200,
                        "data": {
                            "status_code": 200,
                            "status": "Success",
                            "message": "Bank details created Successfully",
                            "merchant_id" : bank_info.merchant_id
                        },
                        "error": None
                    }
        }
        return response_msg
    else:
        raise HTTPException (
            status_code = 400,
            detail = {
                "status": "Error",
                "status_code": 400,
                "data": None,
                "error": {
                    "status_code": 400,
                    "status": "Error",
                    "message" : "bank details not created"
                }
            }
        )     
        


@router.post("/display_merchant_bank_details", status_code = 200, tags = ["Sales Person"], responses = schema.display_merchant_bank_detail_response)
async def display_merchant_bank_details(sales_person : schema.SalesPerson, api_key : APIKey = Depends(auth_api_key.get_api_key), db: Session = Depends(get_db)):
    if not sales_person.sales_person_id:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Sales person id not given"
                }
            }
        )     
    bank_detail = crud.display_merchant_bank_details( db = db, sales_person = sales_person.__dict__['sales_person_id'])
    response_msg = {
                "detail": {
                    "status": "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message": "Merchant bank detail",
                        "merchant_bank_detail" : bank_detail
                    },
                    "error": None
                }
            }
    return response_msg


@router.put("/update_merchant_bank_details", status_code = 200, tags = ["Sales Person"], responses = schema.update_merchant_bank_detail_response)
def update_bankinfo(bank_info : schema.UpdateBankDetails, api_key : APIKey = Depends(auth_api_key.get_api_key), db : Session=Depends(get_db)):
    merchant = crud.check_merchant_exists(db = db, merchant_id = bank_info.merchant_id) 
    if not merchant:   
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Merchant not exist"
                }
            }
        )                          
    bank_details = crud.check_if_bank_details_exist(db = db, merchant_id = merchant.__dict__['id'])
    if not bank_details:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "Bank details not exist"
                }
            }
        )       
    update_data = bank_info.dict(exclude_unset=True)
    bank_details = crud.update_merchant_bank_information(db = db, merchant_id = bank_info.merchant_id, update_data = update_data)
    if bank_details :
        response_msg = {
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                "status_code": 200,
                "status": "Success",
                "message": "Bank details Successfully updated",
                "merchant_id" : bank_info.merchant_id
                },
                "error": None
            }
        }
        return response_msg
    else:
        raise HTTPException (
            status_code = 400,
            detail = {
                "status": "Error",
                "status_code": 400,
                "data": None,
                "error": {
                    "status_code": 400,
                    "status": "Error",
                    "message" : "Bank details not updated"
                }
            }
        )       


@router.post("/sales_person/file_upload/", tags=["Sales Person"], responses = schema.file_upload_response)
async def file_upload(file_upload : UploadFile, file_collection : str = Form(), source_id : int = Form(),merchant_id : int = Form()\
                        , api_key : APIKey = Depends(auth_api_key.get_api_key), mongo_db = Depends(get_mongo_db),db : Session=Depends(get_db)):
    merchant_profile = crud.check_merchant_exists(db=db, merchant_id=merchant_id)
    if not merchant_profile:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "No merchant profile"
                }
            }
        )
    if file_collection not in ('mpkycd','mtpand','mtgstd','mttand','mtidpd','mtadpd'):
        raise HTTPException (
            status_code = 400,
            detail = {
                "status": "Error",
                "status_code": 400,
                "data": None,
                "error": {
                    "status_code": 400,
                    "status": "Error",
                    "message" : "Only merchants docs can upload"
                }
            }
        )
    file_name = file_collection + "_" + str(source_id)
    file_content = await file_upload.read()
    if len(file_content) <= 0:
        raise HTTPException (
            status_code = 400,
            detail = {
                "status": "Error",
                "status_code" : 400,
                "data": None,
                "error" : {
                    "status_code" : 400,
                    "status":"Error",
                    "message" : "No file",
                }
            }
        )
    elif len(file_content) >= 6000000:
        raise HTTPException (
            status_code = 413,
            detail = {
                "status": "Error",
                "status_code" : 413,
                "data": None,
                "error" : {
                    "status_code" : 413,
                    "status":"Error",
                    "message" : "Image size must be less than 6 mb",
                }
            }
        )
    content_type = file_upload.content_type

    coloumn = ''
    if file_collection == 'mtpand':
        coloumn = 'pan_doc'
    elif file_collection == 'mtgstd':
        coloumn = 'gstin_doc'
    elif file_collection == 'mttand':
        coloumn = 'tan_doc'
    elif file_collection == 'mtidpd':
        coloumn = 'id_proof_doc'
    elif file_collection == 'mtadpd':
        coloumn = 'address_proof_doc'
        
    if file_collection in ('mtpand','mtgstd','mttand','mtidpd','mtadpd'):
        
        check_tax_info = crud.get_merchant_taxinfo_by_merchant_id(db=db, merchant_id=merchant_id)
        if not check_tax_info:
            raise HTTPException (
                status_code = 404,
                detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message" : "No merchant tax info"
                    }
                }
            )
        result = crud.save_file_wrapper(mongo_db, file_collection, file_name, file_content, content_type)
        if not result:
            raise HTTPException (
                status_code = 500,
                detail = {
                    "status": "Error",
                    "status_code": 500,
                    "data": None,
                    "error": {
                        "status_code": 500,
                        "status": "Error",
                        "message" : "File upload failed"
                    }
                }
            )
        update_data = {f"{coloumn}":str(result)}
        update_doc = crud.update_merchant_taxinformation(db=db, update_data=update_data, merchant_id=merchant_id)
        if update_doc > 0:
            print("success")
        else:
            print("updation failed")
        return {
            "detail": {
                    "status": "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message": "File uploaded Successfully",
                        "file_id": str(result)  
                    },
                "error": None
            }
        }

    elif file_collection =='mpkycd':
        result = crud.save_file_wrapper(mongo_db, file_collection, file_name, file_content, content_type)
        if not result:
            raise HTTPException (
                status_code = 500,
                detail = {
                    "status": "Error",
                    "status_code": 500,
                    "data": None,
                    "error": {
                        "status_code": 500,
                        "status": "Error",
                        "message" : "File upload failed"
                    }
                }
            )
        update_data = {"kyc_doc" : str(result)}
        update_doc = crud.update_merchant_profile(db=db, profile_data=update_data, id=merchant_id)
        if update_doc > 0:
            print("success")
        else:
            print("updation failed")

        return {
            "detail": {
                    "status": "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message": "File uploaded Successfully",
                        "file_id": str(result)  
                    },
                "error": None
            }
        }


@router.get("/sales_person/file_download/{file_collection}/{file_id}", tags=["Sales Person"], responses = schema.file_download_response)
async def file_download(file_collection : str , file_id : str \
                        , api_key : APIKey = Depends(auth_api_key.get_api_key), mongo_db = Depends(get_mongo_db)):  
    exists = crud.check__if_file_exists_wrapper(mongo_db, file_collection, file_id)
    if not exists:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "File doesn't exist"
                }
            }
        )       
    result = crud.retrieve_file_wrapper(mongo_db, file_collection, file_id)
    if not result:
        raise HTTPException (
            status_code = 500,
            detail = {
                "status": "Error",
                "status_code": 500,
                "data": None,
                "error": {
                    "status_code": 500,
                    "status": "Error",
                    "message" : "File download failed"
                }
            }
        )       
    return Response(status_code=200, content=result)

@router.delete("/sales_person/file_delete/{file_collection}", tags=["Sales Person"], responses = schema.file_delete_response)
async def file_delete(file_collection : str, merchant_id : schema.MerchantId,\
                        api_key : APIKey = Depends(auth_api_key.get_api_key), mongo_db = Depends(get_mongo_db), db : Session=Depends(get_db)):

    merchant_profile = crud.check_merchant_exists(db=db, merchant_id=merchant_id.merchant_id)
    merchant_tax_info = crud.get_merchant_taxinfo_by_merchant_id(db=db, merchant_id=merchant_id.merchant_id)
    
    file_id= ''
    if file_collection =='mpkycd':
        if merchant_profile.kyc_doc is None:
            raise HTTPException (
                status_code = 404,
                detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message" : "No file exist"
                    }
                }
            )
        file_id = merchant_profile.kyc_doc
    elif file_collection == 'mtpand':
        if merchant_tax_info.pan_doc is None:
            raise HTTPException (
                status_code = 404,
                detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message" : "No file exist"
                    }
                }
            )
        file_id = merchant_tax_info.pan_doc
    elif file_collection == 'mtgstd':
        if merchant_tax_info.gstin_doc is None:
            raise HTTPException (
                status_code = 404,
                detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message" : "No file exist"
                    }
                }
            )
        file_id = merchant_tax_info.gstin_doc
    elif file_collection == 'mttand':
        if merchant_tax_info.tan_doc is None:
            raise HTTPException (
                status_code = 404,
                detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message" : "No file exist"
                    }
                }
            )
        file_id = merchant_tax_info.tan_doc
    elif file_collection == 'mtidpd':
        if merchant_tax_info.id_proof_doc is None:
            raise HTTPException (
                status_code = 404,
                detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message" : "No file exist"
                    }
                }
            )
        file_id = merchant_tax_info.id_proof_doc
    elif file_collection == 'mtadpd':
        if merchant_tax_info.address_proof_doc is None:
            raise HTTPException (
                status_code = 404,
                detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message" : "No file exist"
                    }
                }
            )
        file_id = merchant_tax_info.address_proof_doc

    exists = crud.check__if_file_exists_wrapper(mongo_db, file_collection, file_id)
    
    if not merchant_profile:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "No merchant profile"
                }
            }
        )
    if not exists:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "File doesn't exist"
                }
            }
        )      
    result = crud.delete_file_wrapper(mongo_db, file_collection, file_id)
    if not result:
        raise HTTPException (
            status_code = 500,
            detail = {
                "status": "Error",
                "status_code": 500,
                "data": None,
                "error": {
                    "status_code": 500,
                    "status": "Error",
                    "message" : "File deletion failed"
                }
            }
        )
    coloumn = ''
    if file_collection == 'mtpand':
        coloumn = 'pan_doc'
    elif file_collection == 'mtgstd':
        coloumn = 'gstin_doc'
    elif file_collection == 'mttand':
        coloumn = 'tan_doc'
    elif file_collection == 'mtidpd':
        coloumn = 'id_proof_doc'
    elif file_collection == 'mtadpd':
        coloumn = 'address_proof_doc'
    print("coloumn",coloumn)

    if file_collection in ('mtpand','mtgstd','mttand','mtidpd','mtadpd'):
        check_tax_info = crud.get_merchant_taxinfo_by_merchant_id(db=db, merchant_id=merchant_id.merchant_id)
        if not check_tax_info:
            raise HTTPException (
                status_code = 404,
                detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message" : "No merchant tax info"
                    }
                }
            )
        update_data = {f"{coloumn}": None}
        update_doc = crud.update_merchant_taxinformation(db=db, update_data=update_data, merchant_id=merchant_id.merchant_id)
        if update_doc > 0:
            print("success")
        else:
            print("updation failed")
    elif file_collection =='mpkycd':
        update_data = {"kyc_doc" : None}
        update_doc = crud.update_merchant_profile(db=db, profile_data=update_data, id=merchant_id.merchant_id)
        if update_doc > 0:
            print("success")
        else:
            print("updation failed")     
    return {
        "detail": {
            "status": "Success",
            "status_code": 200,
            "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "File deleted Successfully",
                },
            "error": None
        }
    } 


@router.post("/display_merchant_details", tags=["Sales Person"], responses = schema.display_merchant_detail_response)
async def display_merchant_details(merchant_id : schema.MerchantId,api_key : APIKey = Depends(auth_api_key.get_api_key),db : Session = Depends(get_db)):
    merchant_profile = crud.display_merchant_user(db = db, merchant_id = merchant_id.merchant_id)
    if not merchant_profile :
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message" : "There is no merchant id"
                }
            }
        ) 
    merchant_business = crud.check_if_merchant_business_info_exist(db = db, merchant_id = merchant_id.merchant_id)
    merchant_taxinfo = crud.get_merchant_taxinfo_by_merchant_id(db = db, merchant_id = merchant_id.merchant_id)
    merchant_bank_details = crud.check_if_bank_details_exist(db = db, merchant_id = merchant_id.merchant_id)
    if merchant_profile or  merchant_business or merchant_taxinfo or merchant_bank_details:
        return {
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Display merchant details",
                    'merchant' : merchant_profile,
                    'business' : merchant_business,
                    'tax' : merchant_taxinfo,
                    'bank' : merchant_bank_details
            },
            "error": None
        }
    }
        
@router.delete("/image_delete/{file_collection}",  tags=["Sales Person"])
async def file_delete(file_collection : str, merchant_id : schema.MerchantId,api_key : APIKey = Depends(auth_api_key.get_api_key), db : Session=Depends(get_db), mongo_db = Depends(get_mongo_db)):
    merchant_profile = crud.check_merchant_exists(db = db, merchant_id= merchant_id.merchant_id)
    
    if file_collection not in ('mpi'):
        raise HTTPException (
            status_code = 400,
            detail = {
                "status": "Error",
                "status_code" : 400,
                "data": None,
                "error" : {
                    "status_code" : 400,
                    "status":"Error",
                    "message" : "only merchants image can delete",
                }
            },
        )

    if not merchant_profile:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code" : 404,
                "data": None,
                "error" : {
                    "status_code" : 404,
                    "status":"Error",
                    "message" : "Invalid Merchant profile",
                }
            },
        )
    file_id = merchant_profile.profile_image
    exists = check_if_file_exists(mongo_db, file_collection, file_id)
    if not exists:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code" : 404,
                "data": None,
                "error" : {
                    "status_code" : 404,
                    "status":"Error",
                    "message" : "File doesn't exist",
                }
            },
        )
    result = delete_file(mongo_db, file_collection, file_id)

    if not result:
        raise HTTPException (
            status_code = 500,
            detail = {
                "status": "Error",
                "status_code" : 500,
                "data": None,
                "error" : {
                    "status_code" : 500,
                    "status":"Error",
                    "message" : "File deletion failed",
                }
            },
        )
    update_data = {"profile_image" : None}
    update_profile = crud.update_merchant_profile(db=db, profile_data=update_data , id=merchant_id.merchant_id)

    if not update_profile:
        raise HTTPException (
            status_code = 400,
            detail = {
                "status": "Error",
                "status_code" : 400,
                "data": None,
                "error" : {
                    "status_code" : 400,
                    "status":"Error",
                    "message" : "File updation in profile failed and image deleted",
                }
            }
        )
    return {
        "detail": {
            "status": "Success",
            "status_code": 200,
            "data": {
                "status_code": 200,
                "status": "Success",
                "message": "File deleted Successfully",
            },
            "error": None
        }
    }