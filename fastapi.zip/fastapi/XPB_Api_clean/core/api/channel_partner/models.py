from sqlalchemy import Column, Date, Enum, ForeignKey, Integer, String

from core.database.connection import Base
from core.models.mixin import GenderType, TimeStamp


class ChannelPartner(Base, TimeStamp):

    __tablename__ = "channel_partner"
    id = Column(Integer, primary_key=True, index=True)
    users_id = Column(Integer, ForeignKey("users.id"))
    full_name = Column(String(100), nullable=False)
    gender = Column(Enum(GenderType))
    dob = Column(Date, nullable=False)
    alt_name = Column(String(100), nullable=True)
    address1 = Column(String(100), nullable=False)
    address2 = Column(String(100), nullable=True)
    city = Column(String(20), nullable=False)
    district = Column(String(20), nullable=False)
    state = Column(String(20), nullable=False)
    country = Column(String(20), nullable=False)
    locality = Column(String(20), nullable=True)
    postal_code = Column(String(20), nullable=False)
    pan_card_doc = Column(String(100), nullable=True)
    aadhaar_card_doc = Column(String(100), nullable=True)
