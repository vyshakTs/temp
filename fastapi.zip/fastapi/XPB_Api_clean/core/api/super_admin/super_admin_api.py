#import requests
from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session

from core.api.users import schema
from core.api.users.crud import (create_user, get_user_by_email,
                                 get_user_by_phonenumber,
                                 validate_phone_number)
from core.database.connection import get_db
from core.utils import password
from core.utils.password import validate_password

router = APIRouter()

@router.post("/create-superadmin", tags=["Super Admin",])
async def add_super_admin_api(user: schema.UserCreate, db: Session = Depends(get_db)):
    if user.role_id ==1:  
        db_user: Any = get_user_by_email(db, email=user.email)
        if db_user:
            raise HTTPException(
                status_code=200,
                detail={
                    "status_code":200, 
                    "Status": "Error", 
                    "message": "Email already registered"
                }
                )

        reg_phone: Any = get_user_by_phonenumber(db, phone_number=user.phone_number)

        if reg_phone:
            raise HTTPException(
                status_code=200,
                detail={
                    "status_code":200, 
                    "Status": "Error", 
                    "message": "Phone number already registered",
                }
            )
            
        if reg_phone is None:
        
            if not validate_phone_number(user.phone_number, user.country_code):
                raise HTTPException(
                    status_code=400,
                    detail={
                        "status_code":400, 
                        "Status": "Error", 
                        "message": "Enter a valid phone number."
                    }
                )
            elif not validate_password(user.password):
                raise HTTPException(
                    status_code=400,
                    detail={
                        "status_code":400, 
                        "Status": "Error", 
                        "message": """Password must be at least 8 characters long, contains atleast one lower case character, one 
                            upper case character, one digit and one special case character."""
                    }
                )
            created_user, role = create_user(db, user)
            response = {
                "status_code": 201,
                "Status": "Success",
                "Message": "User registred Successfully",
                "id" : created_user.id,
                "username": created_user.full_name,
                "phonenumber": created_user.phone_number,
                "role": role.role_id,
            }
            return response
        else:
            raise HTTPException(
                status_code=500,
                detail={
                    "status_code":500, 
                    "Status": "Error", 
                    "message": "some error occurred"
                }
            )
    else:
        raise HTTPException(
            status_code=500,
            detail={
            "status_code":500, 
            "Status": "Error", 
            "message": "Only For Super Admin registration."
            }
        )


# @router.post("/super-admin/remove-admin")
# async def remove_admin_api():
#     pass


# @router.post("/super-admin/ban-users")
# async def ban_user_api():
#     pass

