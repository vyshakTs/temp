from pydantic import BaseModel, Field 

class AddCountry(BaseModel):
    name : str = Field(default = None, description="country name")
    flag : str | None = Field(default = None, description="country flag")
    country_code : str = Field(default = None, description="country code")
    currency_symbol : str | None = Field(default = None, description="country currency symbol")


    class Config:
        schema_extra = {
            "example": {
                "name" : "India",
                "flag" : "FLAG",
                "country_code" : "+91",
                "currency_symbol" : "₹"
                },
        }

class UpdateCountry(BaseModel):
    name : str | None = Field(default = None, description="country name")
    flag : str | None = Field(default = None, description="country flag")
    country_code : str | None = Field(default = None, description="country code")
    currency_symbol : str | None = Field(default = None, description="country currency symbol")
    id : int = Field(default = None, description="Id in country table")


    class Config:
        schema_extra = {
            "example": {
                "name" : "India",
                "flag" : "FLAG",
                "country_code" : "+91",
                "currency_symbol" : "₹",
                "id" :  1
                },
        }


class AddBusinessCategory(BaseModel):
    category : str = Field(default = None, description="Business category")


    class Config:
        schema_extra = {
            "example": {
                "category" : "Automotive",
                },
        }

class UpdateBusinessCategory(BaseModel):
    category : str | None = Field(default = None, description="Business category")
    id : int = Field(default = None, description="Id in Business category Table")


    class Config:
        schema_extra = {
            "example": {
                "category" : "Automotive",
                "id" : 1
                },
        }

class AddIdProofs(BaseModel):
    id_type : str = Field(default = None, description="Id proof")


    class Config:
        schema_extra = {
            "example": {
                "id_type" : "PASSPORT",
                },
        }

class UpdateIdProofs(BaseModel):
    id_type : str | None = Field(default = None, description="Id proof")
    id : int = Field(default = None, description="Id in id proof table")


    class Config:
        schema_extra = {
            "example": {
                "id_type" : "PASSPORT",
                "id" : 1
                },
        }

class AddMerchantCountryIdProofs(BaseModel):
    id_proof_id : str = Field(default = None, description="id_proofs id")
    country_id : str = Field(default = None, description="countries id")

    class Config:
        schema_extra = {
            "example": {
                "id_proof_id" : 1,
                "country_id" : 1
                },
        }

class UpdateMerchantCountryIdProofs(BaseModel):
    country_id : str | None = Field(default = None, description="countries id")
    id_proof_id : str | None = Field(default = None, description="id_proofs id")
    id : int = Field(default = None, description="merchants_country_id_proofs id")

    class Config:
        schema_extra = {
            "example": {
                "country_id" : 1,
                "id_proof_id" : 1,
                "id" :1
                },
        }



class AddSocialMedia(BaseModel):
    name : str = Field(default = None, description="social media name")
    column_name : str = Field(default = None, description="followed")


    class Config:
        schema_extra = {
            "example": {
                "name" : "Facebook",
                "column_name" : "facebook_followed"
                }
        }

class UpdateSocialMedia(BaseModel):
    name : str = Field(default = None, description="social media name")
    column_name : str = Field(default = None, description="followed")
    id : int = Field(default = None, description="social_medias id")


    class Config:
        schema_extra = {
            "example": {
                "name" : "Facebook",
                "column_name" : "facebook_followed",
                "id" : 1
                }
        }

class UserId(BaseModel):
    user_id : int = Field(default = None, description="Users id")

    class Config:
        schema_extra = {
            "example": {
                "user_id" : 1
                }
        }
