from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from core.api.admin import crud
from core.database.connection import get_db
from core.jwt.auth_bearer import JWTBearer
from core.jwt import auth_handler
from core.api.admin import schema


router = APIRouter()

@router.put('/block-consumer-or-merchant', dependencies=[Depends(JWTBearer())], status_code=200, tags=["Admin"])
async def block_consumer_or_merchant(user_id : schema.UserId, token = Depends(JWTBearer()), db: Session = Depends(get_db)):
    email = auth_handler.decode_token(token=token)
    userdata = crud.get_user_email(db=db, email=email['sub'])
    check_admin = crud.check_admin_user_role(db=db, users_id= userdata.id)
    user_data = crud.check_if_user_exists(db = db, user_id = user_id.user_id)
    if not check_admin:
        raise HTTPException(
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "admin not found"
                }
            }
    )
    if not user_data:
        raise HTTPException(
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "user not found"
                }
            }
    )
    if user_data.blocked == True:
        return {
            "detail": {
            "status": "Success",
            "status_code": 200,
            "data": {
                "status_code": 200,
                "status": "Success",
                "message": "User is already blocked."
                },
            "error": None
            }
        }
    else:
        update_result = crud.block_user(db = db, user_id = user_id.user_id)
        if update_result:
            return {
                "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "User has been blocked."
                    },
                "error": None
            }
            }
        else:
            raise HTTPException(
                    status_code = 500,
                    detail = {
                        "status": "Error",
                        "status_code": 500,
                        "data": None,
                        "error": {
                            "status_code": 500,
                            "status": "Error",
                            "message": "Update not completed"
                        }
                    }
            )

@router.post("/add-country", tags=["Admin"])
async def add_country(country : schema.AddCountry, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    email = auth_handler.decode_token(token=token)
    userdata = crud.get_user_email(db=db, email=email['sub'])
    country_data_name = crud.get_country_data_name(db=db, name =country.name, country_code = country.country_code)
    check_admin = crud.check_admin_user_role(db=db, users_id=userdata.id)

    if not check_admin:
        raise HTTPException(
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "admin not found"
                }
            }
    )
    if not userdata:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User does not exist"
                }
            }
        )
    if country_data_name:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "country details exist"
                }
            }
        )

    add_country = crud.add_country(db=db,country =country)
    if add_country:
        return{
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Country details added Successfully"
                },
                "error": None
                } 
        }
    else:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "some error occurred"
                }
            }
        )

@router.put("/update-country", tags=["Admin"])
async def update_country(country : schema.UpdateCountry, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    email = auth_handler.decode_token(token=token)
    userdata = crud.get_user_email(db=db, email=email['sub'])
    country_data_name = crud.get_country_data_name(db=db, name =country.name, country_code= country.country_code)
    country_data_id =crud.get_country_data_id(db=db, id = country.id)
    check_admin = crud.check_admin_user_role(db=db, users_id=userdata.id)

    if not check_admin:
        raise HTTPException(
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "admin not found"
                }
            }
    )
    if not userdata:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User does not exist"
                }
            }
        )
    if country_data_name:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "country details exist"
                }
            }
        )
    if not country_data_id:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "id not exist"
                }
            }
        )
    country_data = country.dict(exclude_unset=True)
    updated_country = crud.update_country(db=db,update_data=country_data, country_id=country.id)
    if updated_country:
        return{
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Country details updated Successfully"
                },
                "error": None
                } 
        }
    else:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "some error occurred"
                }
            }
        )


@router.post("/add-busniess-category", tags=["Admin"])
async def add_business_category(business_category : schema.AddBusinessCategory, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    email = auth_handler.decode_token(token=token)
    userdata = crud.get_user_email(db=db, email=email['sub'])
    business_category_data_category = crud.get_category_data_category(db=db, category =business_category.category)
    check_admin = crud.check_admin_user_role(db=db, users_id=userdata.id)

    if not check_admin:
        raise HTTPException(
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "admin not found"
                }
            }
    )

    if not userdata:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User does not exist"
                }
            }
        )
    if business_category_data_category:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "category details exist"
                }
            }
        )

    add_category = crud.add_busniess_category(db=db, busniess_category=business_category)
    if add_category:
        return{
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "business category details added Successfully"
                },
                "error": None
                } 
        }
    else:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "some error occurred"
                }
            }
        )

@router.put("/update-busniess-category", tags=["Admin"])
async def update_business_category(business_category : schema.UpdateBusinessCategory, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    email = auth_handler.decode_token(token=token)
    userdata = crud.get_user_email(db=db, email=email['sub'])
    business_category_data_category = crud.get_category_data_category(db=db, category =business_category.category)
    business_category_data_category_id =crud.get_category_data_id(db=db, id= business_category.id)
    check_admin = crud.check_admin_user_role(db=db, users_id=userdata.id)

    if not check_admin:
        raise HTTPException(
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "admin not found"
                }
            }
    )
    if not userdata:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User does not exist"
                }
            }
        )
    if business_category_data_category:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "category details exist"
                }
            }
        )
    if not business_category_data_category_id:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "id not exist"
                }
            }
        )
    category_data = business_category.dict(exclude_unset=True)
    updated_category = crud.update_busniess_category(db=db, update_data=category_data, category_id=business_category.id)
    if updated_category:
        return{
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Business category details updated Successfully"
                },
                "error": None
                } 
        }
    else:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "some error occurred"
                }
            }
        )


@router.post("/add-id-proofs", tags=["Admin"])
async def add_id_proof(id_proof : schema.AddIdProofs, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    email = auth_handler.decode_token(token=token)
    userdata = crud.get_user_email(db=db, email=email['sub'])
    id_proof_data_id_type = crud.get_id_proof_data_id_type(db=db, id_type=id_proof.id_type)
    check_admin = crud.check_admin_user_role(db=db, users_id=userdata.id)

    if not check_admin:
        raise HTTPException(
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "admin not found"
                }
            }
    )
    if not userdata:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User does not exist"
                }
            }
        )
    if id_proof_data_id_type:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "id details exist"
                }
            }
        )

    add_id_proofs = crud.add_id_proofs(db=db, id_proof=id_proof)
    if add_id_proofs:
        return{
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "id proof details added Successfully"
                },
                "error": None
                } 
        }
    else:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "some error occurred"
                }
            }
        )


@router.put("/update-id-proofs", tags=["Admin"])
async def update_id_proof(id_proof : schema.UpdateIdProofs, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    email = auth_handler.decode_token(token=token)
    userdata = crud.get_user_email(db=db, email=email['sub'])
    id_proof_data_id_type = crud.get_id_proof_data_id_type(db=db, id_type=id_proof.id_type)
    id_proof_data_id = crud.get_id_proof_data_id(db=db, id= id_proof.id )
    check_admin = crud.check_admin_user_role(db=db, users_id=userdata.id)

    if not check_admin:
        raise HTTPException(
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "admin not found"
                }
            }
    )
    if not userdata:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User does not exist"
                }
            }
        )
    if id_proof_data_id_type:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "id details exist"
                }
            }
        )
    if not id_proof_data_id:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "id not exist"
                }
            }
        )
    id_proof_data = id_proof.dict(exclude_unset=True)
    updated_id_proofs = crud.update_id_proofs(db=db, update_data=id_proof_data, id_proof_id=id_proof.id)
    if updated_id_proofs:
        return{
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Id proof details updated Successfully"
                },
                "error": None
                } 
        }
    else:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "some error occurred"
                }
            }
        )
    
@router.post("/add-merchant-id-proofs", tags=["Admin"])
def add_merchant_id_proof(id_proof : schema.AddMerchantCountryIdProofs, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    email = auth_handler.decode_token(token=token)
    userdata = crud.get_user_email(db=db, email=email['sub'])
    id_proof_data = crud.get_id_proof_data_id(db=db, id= id_proof.id_proof_id)
    country_data = crud.get_country_data_id(db=db, id=id_proof.country_id)
    merchant_id_proofs = crud.get_merchant_country_id_proofs(db=db, countrys_id = id_proof.country_id, id_proofs_id= id_proof.id_proof_id)
    check_admin = crud.check_admin_user_role(db=db, users_id=userdata.id)

    if not check_admin:
        raise HTTPException(
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "admin not found"
                }
            }
    )
    if not userdata:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User does not exist"
                }
            }
        )

    if not id_proof_data:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "No id details exist in id_proofs"
                }
            }
        )

    if not country_data:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "No Country details exist in country"
                }
            }
        )
    if merchant_id_proofs:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "Merchants Country details exist in merchants country"
                }
            }
        )
    

    add_id_proofs = crud.add_merchants_id_proof(db=db, id_proof=id_proof)
    if add_id_proofs:
        return{
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "merchants id proof details added Successfully"
                },
                "error": None
                } 
        }
    else:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "some error occurred"
                }
            }
        )

@router.put("/update-merchant-id-proofs", tags=["Admin"])
def update_merchant_id_proof(id_proof : schema.UpdateMerchantCountryIdProofs, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    email = auth_handler.decode_token(token=token)
    userdata = crud.get_user_email(db=db, email=email['sub'])
    id_proof_data = crud.get_id_proof_data_id(db=db, id= id_proof.id_proof_id)
    country_data = crud.get_country_data_id(db=db, id=id_proof.country_id)
    id_merchants_id_proofs = crud.get_merchant_country_id_proofs_id(db=db, id = id_proof.id)
    check_admin = crud.check_admin_user_role(db=db, users_id=userdata.id)

    if not check_admin:
        raise HTTPException(
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "admin not found"
                }
            }
    )
    if not userdata:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User does not exist"
                }
            }
        )

    if not id_proof_data:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "No id details exist in id_proofs"
                }
            }
        )

    if not country_data:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "No Country details exist in country"
                }
            }
        )
    
    if not id_merchants_id_proofs:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "No id exist in merchants country id proofs"
                }
            }
        )
    
    merchant_id_proof_data = id_proof.dict(exclude_unset=True)
    updated_id_proofs = crud.update_merchants_id_proofs(db=db, update_data=merchant_id_proof_data, id=id_proof.id)

    if updated_id_proofs:
        return{
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "merchants id proof details updated Successfully"
                },
                "error": None
                } 
        }
    else:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "some error occurred"
                }
            }
        )

##############need add and update apis for followed social media using migration
@router.post("/add-social-media", tags=["Admin"])
async def add_social_media(social_media : schema.AddSocialMedia, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    email = auth_handler.decode_token(token=token)
    userdata = crud.get_user_email(db=db, email=email['sub'])
    social_media_data_media_type = crud.get_social_media_type(db=db, social_media=social_media)
    check_admin = crud.check_admin_user_role(db=db, users_id=userdata.id)

    if not check_admin:
        raise HTTPException(
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "admin not found"
                }
            }
    )
    if not userdata:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User does not exist"
                }
            }
        )
    if social_media_data_media_type:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "social media details exist"
                }
            }
        )

    add_social_media = crud.add_social_media(db=db, social_media=social_media)
    if add_social_media:
        return{
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "social media details added Successfully"
                },
                "error": None
                } 
        }
    else:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "some error occurred"
                }
            }
        )

##############need add and update apis for followed social media using migration
@router.put("/update-social-media", tags=["Admin"])
async def update_social_media(social_media : schema.UpdateSocialMedia, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    email = auth_handler.decode_token(token=token)
    userdata = crud.get_user_email(db=db, email=email['sub'])
    social_media_data_media_type = crud.get_social_media_type(db=db, social_media=social_media)
    id_social_media = crud.get_social_media_type_id(db=db, id= social_media.id)
    check_admin = crud.check_admin_user_role(db=db, users_id=userdata.id)

    if not check_admin:
        raise HTTPException(
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "admin not found"
                }
            }
    )
    if not userdata:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User does not exist"
                }
            }
        )
    if social_media_data_media_type:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "social media details exist"
                }
            }
        )
    if not id_social_media:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "id not exist"
                }
            }
        )
    social_media_data = social_media.dict(exclude_unset=True)
    updated_social_media = crud.update_social_media(db=db, update_data=social_media_data, id_social_media=social_media.id)
    if updated_social_media:
        return{
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "social media details updated Successfully"
                },
                "error": None
                } 
        }
    else:
        raise HTTPException (
            status_code = 409,
            detail = {
                "status": "Error",
                "status_code": 409,
                "data": None,
                "error": {
                    "status_code": 409,
                    "status": "Error",
                    "message": "some error occurred"
                }
            }
        )

@router.get("/pagination-users-list", tags=["Admin"])
def list_users(skip : int = 0, limit: int = 10, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    email = auth_handler.decode_token(token=token)
    userdata = crud.get_user_email(db=db, email=email['sub'])
    check_admin = crud.check_admin_user_role(db=db, users_id=userdata.id)

    if not check_admin:
        raise HTTPException(
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "admin not found"
                }
            }
    )
    if not userdata:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User does not exist"
                }
            }
        )
    list_users = crud.list_users(db=db)
    if not list_users:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "some error occured"
                }
            }
        )
    return_list_users = []
    for i in list_users:
        return_list_users.append(i.__dict__)
    return{
        "detail": {
            "status": "Success",
            "status_code": 200,
            "data": {
                "status_code": 200,
                "status": "Success",
                "message": "Users list",
                "users_list" : return_list_users[skip : skip + limit]
            },
            "pagination" :{
                "limit" : limit,
                "skip" : skip,
                "count" : len(return_list_users),
                "data_count" : len(return_list_users[skip : skip + limit])
            },
            "sort" : {
            "sort_by" : "users id asc",
            "error": None
            }
        } 
    }