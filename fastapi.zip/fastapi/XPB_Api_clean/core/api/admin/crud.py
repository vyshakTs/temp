from sqlalchemy.orm import Session, load_only
from sqlalchemy import or_, and_, desc, asc
from core.api.users.models import Users,UserRoles
from core.api.users.crud import get_user_by_id, get_user_by_email
from core.api.admin import schema
from core.models.models import Country, IDProofs
from core.api.merchant import models
from core.api.consumer.models import SocialMedia, FollowedSocialMedia


def check_if_user_exists(db : Session, user_id : str):
    return get_user_by_id(db, user_id)

def block_user(db : Session, user_id : str):
    try:
        result = db.query(Users).filter(Users.id == user_id).update({"blocked": True})
        db.commit()
    except:
        result = False
    if not result:
        return False
    return True

def add_country(db: Session, country : schema.AddCountry):
    db_country = Country(
        name = country.name,
        flag = country.flag,
        country_code = country.country_code,
        currency_symbol = country.currency_symbol
    )
    db.add(db_country)
    db.commit()
    db.refresh(db_country)
    return db_country

def update_country(db : Session, update_data : dict, country_id :int):
    result = db.query(Country).filter(Country.id==country_id).update(update_data)
    db.commit()
    #db.refresh(result) 
    return result

def get_country_data_name(db : Session, name :str, country_code = str):
    return db.query(Country).filter(or_(Country.name == name, Country.country_code == country_code)).first()

def get_country_data_id(db : Session, id :str):
    return db.query(Country).filter(Country.id == id).first()

def get_user_email(db: Session, email:str):
    return get_user_by_email(db=db, email=email)

def add_busniess_category(db: Session, busniess_category : schema.AddBusinessCategory):
    db_category = models.BusinessCategory(
        category = busniess_category.category,
    )
    db.add(db_category)
    db.commit()
    db.refresh(db_category)
    return db_category

def update_busniess_category(db : Session, update_data : dict, category_id :int):
    result = db.query(models.BusinessCategory).filter(models.BusinessCategory.id==category_id).update(update_data)
    db.commit()
    #db.refresh(result) 
    return result

def get_category_data_category(db : Session, category :str):
    return db.query(models.BusinessCategory).filter(models.BusinessCategory.category == category).first()

def get_category_data_id(db : Session, id :str):
    return db.query(models.BusinessCategory).filter(models.BusinessCategory.id == id).first()

def add_id_proofs(db: Session, id_proof : schema.AddIdProofs):
    db_id_proofs = IDProofs(
        id_type = id_proof.id_type,
    )
    db.add(db_id_proofs)
    db.commit()
    db.refresh(db_id_proofs)
    return db_id_proofs

def update_id_proofs(db : Session, update_data : dict, id_proof_id :int):
    result = db.query(IDProofs).filter(IDProofs.id==id_proof_id).update(update_data)
    db.commit()
    #db.refresh(result) 
    return result

def get_id_proof_data_id_type(db : Session, id_type :str):
    return db.query(IDProofs).filter(IDProofs.id_type == id_type).first()

def get_id_proof_data_id(db : Session, id :int ):
    return db.query(IDProofs).filter(IDProofs.id == id).first()

def get_merchant_country_id_proofs(db :Session, countrys_id : int, id_proofs_id : int):
    print(countrys_id,id_proofs_id)
    return db.query(models.MerchantsCountryIDProofs).filter(and_(models.MerchantsCountryIDProofs.country_id==countrys_id, models.MerchantsCountryIDProofs.id_proof_id==id_proofs_id)).first()

def add_merchants_id_proof(db :Session, id_proof : schema.AddMerchantCountryIdProofs):
    db_id_proofs =models.MerchantsCountryIDProofs(
        country_id = id_proof.country_id,
        id_proof_id = id_proof.id_proof_id
    )
    db.add(db_id_proofs)
    db.commit()
    db.refresh(db_id_proofs)
    return db_id_proofs

def update_merchants_id_proofs(db : Session, update_data : dict, id :int):
    result = db.query(models.MerchantsCountryIDProofs).filter(models.MerchantsCountryIDProofs.id==id).update(update_data)
    db.commit()
    #db.refresh(result) 
    return result

def get_merchant_country_id_proofs_id(db :Session, id : int):
    return db.query(models.MerchantsCountryIDProofs).filter(models.MerchantsCountryIDProofs.id == id).first()

def get_social_media_type(db : Session, social_media:schema.AddSocialMedia):
    return db.query(SocialMedia).filter(and_(SocialMedia.name == social_media.name, SocialMedia.column_name==social_media.column_name)).first()

def add_social_media(db: Session, social_media : schema.AddSocialMedia):
    db_social_media = SocialMedia(
        name = social_media.name,
        column_name = social_media.column_name
    )
    db.add(db_social_media)
    db.commit()
    db.refresh(db_social_media)
    return db_social_media

def get_social_media_type_id(db : Session, id :int ):
    return db.query(SocialMedia).filter(SocialMedia.id == id).first()

def update_social_media(db : Session, update_data : dict, id_social_media :int):
    result = db.query(SocialMedia).filter(SocialMedia.id==id_social_media).update(update_data)
    db.commit()
    #db.refresh(result) 
    return result

def list_users(db : Session):
    return db.query(Users).options(load_only(
            "id", "full_name", "email", "phone_number", "referral_code", "referred_by", "blocked", 
            "deleted", "created_at", "updated_at","token_expired"
    )).order_by(asc(Users.id)).all()

def check_admin_user_role(db : Session, users_id):
    return db.query(UserRoles).filter(and_(UserRoles.users_id==users_id, UserRoles.role_id==2)).first()