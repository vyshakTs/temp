from typing import Optional
from datetime import date, datetime
from pydantic import BaseModel, Field, EmailStr

class GetVoucher(BaseModel):
    limit: int
    page: int
    country: Optional[str]
    product_name: Optional[str]
    
    class Config:
        schema_extra = {
            "example": {
                "limit" : 10,
                "page": 1,
                "country": "india",
                "product_name": "Cafe Coffee Day",
            },
        }

class GetVoucherDetails(BaseModel):
    limit: int
    page: int
    country: Optional[str]
    product_name: Optional[str]
    product_id: int
    
    class Config:
        schema_extra = {
            "example": {
                "limit" : 10,
                "page": 1,
                "country": "india",
                "product_name": "Cafe Coffee Day",
                "product_id": 228,
            },
        }

get_voucher_response = {
    200: {
        "description": "Success",
        "content": {
            "application/json": {
                "examples": {
                    "Success": {
                        "summary": "Consumer details.",
                        "value": {
                        	"detail" : { 
                        		"status" : "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "Consumer details.",
                                    "vouchers": [
                                        {
                                            "productId": 31057,
                                            "name": "Paytm",
                                            "description": "<p>Paytm is India's largest mobile commerce platform Paytm started by offering mobile recharge and utility billayments and today it offers a full marketplace to consumers on its mobile apps. We have over 100Mn registered users In a short span of time Paytm has scaled to more than 60 Million orders per month.</p>",
                                            "termsAndConditionsInstructions": "<p><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">1.The Money in Gift Sub-Wallet cannot be transferred to Bank Account Nor Peer-Peer transfer can happen.</span></span></p><p><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">2. It can be utilised in Paytm Offline and Online Ecosystem.</span></span></p><p><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">3. Validity is 3 Years.</span></span></p><p><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">4. 1 lakh is the maximum transaction can be done in a month.</span></span></p><p><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">5. Above 10k Customer need to update KYC in Paytm or else the amount will not reflect in wallet.&nbsp;</span></span></p><p><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">6. Please note the mobile no. which is entered while placing order to the same no. the money will be added.</span></span></p><p><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">7. Gift vouchers validity can not be extended once expired.</span></span></p>",
                                            "expiryAndValidity": "<p>36 Months</p>",
                                            "redemptionInstructions": "<p style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\"><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">1. Open <a href=\"https://paytm.com/\">wwwpaytm.com </a></span></span></p><p style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\"><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">2. Amount will be directly transferred to your Paytm account for which you have placed the order as per the denominations available.</span></span></p><p style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\"><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">3. The Money in Gift Sub Wallet cannot be transferred to Bank Account Nor Peer Peer transfer can happen.</span></span></p>",
                                            "categories": "Mobile Recharges",
                                            "lastUpdateDate": "2023-02-03 07:40:13",
                                            "imageUrl": "https://res.cloudinary.com/dyyjph6kx/image/upload/gift_vouchers/image/phprqIvuL_jhmiky.jpg",
                                            "currencyCode": "INR",
                                            "currencyName": "rupees",
                                            "countryName": "India",
                                            "countryCode": "IN",
                                            "countries": [
                                                {
                                                    "code": "IN",
                                                    "name": "India"
                                                }
                                            ],
                                            "valueType": "fixed_denomination",
                                            "maxValue": 0,
                                            "minValue": 0,
                                            "valueDenominations": "10,100,1000,2000,250,4000,500,5000",
                                            "tatInDays": 0,
                                            "usageType": "online",
                                            "deliveryType": "realtime",
                                            "fee": 0,
                                            "discount": 0,
                                            "exchangeRate": None,
                                            "isPhoneNumberMandatory": True
                                        }
                                    ]
                                },
                        		"error": None 
                        	}
                        }
                    }
                }
            }
        }  
    },
    400: {
        "description": "Error",
        "content": {
            "application/json": {
                "examples": {
                    "Invalid filter value code" : {
                        "summary" : "Invalid filter value code.",
                        "value" : {
                            "detail":{
                                "status" : "Error", 
                                "status_code" : 400,
                                "data" : None, 
                                "error" : { 
                                    "status_code":400, 
                                    "status":'Error', 
                                    "message" : "Invalid filter value code. Please send correct filterValueCode",
                                    "errorId": "PLE10031",
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

get_voucher_details_response = {
    200: {
        "description": "Success",
        "content": {
            "application/json": {
                "examples": {
                    "Success": {
                        "summary": "Consumer details.",
                        "value": {
                        	"detail" : { 
                        		"status" : "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "Consumer details.",
                                    "voucher_details": {
                                        "productId": 31057,
                                        "name": "Paytm",
                                        "description": "<p>Paytm is India's largest mobile commerce platform Paytm started by offering mobile recharge and utility billayments and today it offers a full marketplace to consumers on its mobile apps. We have over 100Mn registered users In a short span of time Paytm has scaled to more than 60 Million orders per month.</p>",
                                        "termsAndConditionsInstructions": "<p><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">1.The Money in Gift Sub-Wallet cannot be transferred to Bank Account Nor Peer-Peer transfer can happen.</span></span></p><p><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">2. It can be utilised in Paytm Offline and Online Ecosystem.</span></span></p><p><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">3. Validity is 3 Years.</span></span></p><p><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">4. 1 lakh is the maximum transaction can be done in a month.</span></span></p><p><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">5. Above 10k Customer need to update KYC in Paytm or else the amount will not reflect in wallet.&nbsp;</span></span></p><p><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">6. Please note the mobile no. which is entered while placing order to the same no. the money will be added.</span></span></p><p><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">7. Gift vouchers validity can not be extended once expired.</span></span></p>",
                                        "expiryAndValidity": "<p>36 Months</p>",
                                        "redemptionInstructions": "<p style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\"><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">1. Open <a href=\"https://paytm.com/\">wwwpaytm.com </a></span></span></p><p style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\"><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">2. Amount will be directly transferred to your Paytm account for which you have placed the order as per the denominations available.</span></span></p><p style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\"><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:12px;\">3. The Money in Gift Sub Wallet cannot be transferred to Bank Account Nor Peer Peer transfer can happen.</span></span></p>",
                                        "categories": "Mobile Recharges",
                                        "lastUpdateDate": "2023-02-03 07:40:13",
                                        "imageUrl": "https://res.cloudinary.com/dyyjph6kx/image/upload/gift_vouchers/image/phprqIvuL_jhmiky.jpg",
                                        "currencyCode": "INR",
                                        "currencyName": "rupees",
                                        "countryName": "India",
                                        "countryCode": "IN",
                                        "countries": [
                                            {
                                                "code": "IN",
                                                "name": "India"
                                            }
                                        ],
                                        "valueType": "fixed_denomination",
                                        "maxValue": 0,
                                        "minValue": 0,
                                        "valueDenominations": "10,100,1000,2000,250,4000,500,5000",
                                        "tatInDays": 0,
                                        "usageType": "online",
                                        "deliveryType": "realtime",
                                        "fee": 0,
                                        "discount": 0,
                                        "exchangeRate": None,
                                        "isPhoneNumberMandatory": True
                                    }
                                },
                        		"error": None 
                        	}
                        }
                    }
                }
            }
        }  
    },
    400: {
        "description": "Error",
        "content": {
            "application/json": {
                "examples": {
                    "Invalid filter value code" : {
                        "summary" : "Invalid filter value code.",
                        "value" : {
                            "detail":{
                                "status" : "Error", 
                                "status_code" : 400,
                                "data" : None, 
                                "error" : { 
                                    "status_code":400, 
                                    "status":'Error', 
                                    "message" : "Invalid filter value code. Please send correct filterValueCode",
                                    "errorId": "PLE10031",
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}