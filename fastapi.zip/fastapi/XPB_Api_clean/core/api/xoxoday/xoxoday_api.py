from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from core.api.xoxoday import schema
from core.database.connection import get_db
from core.jwt.auth_bearer import JWTBearer
from core.jwt import auth_handler
from core.utils.xoxoday_service import get_voucher
from core.api.users.crud import get_user_by_email


router = APIRouter()


@router.post('/get-xoxo-voucher', dependencies=[Depends(JWTBearer())], status_code=200, tags=["XOXODAY"], responses=schema.get_voucher_response)
def xoxo_get_vouchers(voucher: schema.GetVoucher, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = get_user_by_email(db, payload['sub'])
    
    if not user:
        raise HTTPException(
            status_code=404,
            detail={
                "status" : "Error",
                "status_code" : 404,
                "data" : None,
                "error" : {
                    "status_code":404,
                    "status":'Error', 
                    "message" : "User not found."
                }
            }
        )
        
    response = get_voucher(voucher_details=voucher)
    print(response.json())
    if response.status_code == 200:
        voucher_data = response.json()['data']['getVouchers']['data']
        response_msg = {
            "detail" : {
                "status" : "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Fetched vouchers Successfully",
                    "vouchers": voucher_data,
                },
                "error": None
            }
        }
        return response_msg
    elif response.status_code == 404:
        voucher_data = response.json()
        raise HTTPException(
            status_code=404,
            detail={
                "status" : "Error",
                "status_code" : 404,
                "data" : None,
                "error" : {
                    "status_code":404,
                    "status":'Error',
                    "message": f"{voucher_data['errorInfo']}/{voucher_data['error']}",
                    "errorId": voucher_data['errorId'],
                }
            }
        )
    elif response.status_code == 400:
        voucher_data = response.json()
        raise HTTPException(
            status_code=400,
            detail={
                "status" : "Error",
                "status_code" : 400,
                "data" : None,
                "error" : {
                    "status_code":400,
                    "status":'Error',
                    "message": f"{voucher_data['errorInfo']}/{voucher_data['error']}",
                    "errorId": voucher_data['errorId'],
                }
            }
        )
    elif response.status_code == 429:
        voucher_data = response.json()
        raise HTTPException(
            status_code=429,
            detail={
                "status" : "Error",
                "status_code" : 429,
                "data" : None,
                "error" : {
                    "status_code":429,
                    "status":'Error',
                    "message": f"{voucher_data['errorInfo']}/{voucher_data['error']}",
                    "errorId": voucher_data['errorId'],
                }
            }
        )


@router.post('/get-xoxo-voucher-details', dependencies=[Depends(JWTBearer())], status_code=200, tags=["XOXODAY"], responses=schema.get_voucher_details_response)
def xoxo_get_vouchers(voucher: schema.GetVoucherDetails, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = get_user_by_email(db, payload['sub'])
    
    if not user:
        raise HTTPException(
            status_code=404,
            detail={
                "status" : "Error",
                "status_code" : 404,
                "data" : None,
                "error" : {
                    "status_code":404,
                    "status":'Error', 
                    "message" : "User not found."
                }
            }
        )
        
    response = get_voucher(voucher_details=voucher)
    if response.status_code == 200:
        voucher_data = response.json()['data']['getVouchers']['data']
        if len(voucher_data) > 1:
            for data in voucher_data:
                if data['productId'] == voucher.product_id:
                    voucher_data = data
                    break
        else:
            voucher_data = voucher_data[0]
        response_msg = {
            "detail" : {
                "status" : "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Fetched voucher details Successfully",
                    "voucher_details": voucher_data,
                },
                "error": None
            }
        }
        return response_msg
    elif response.status_code == 404:
        voucher_data = response.json()
        raise HTTPException(
            status_code=404,
            detail={
                "status" : "Error",
                "status_code" : 404,
                "data" : None,
                "error" : {
                    "status_code":404,
                    "status":'Error',
                    "message": f"{voucher_data['errorInfo']}/{voucher_data['error']}",
                    "errorId": voucher_data['errorId'],
                }
            }
        )
    elif response.status_code == 400:
        voucher_data = response.json()
        raise HTTPException(
            status_code=400,
            detail={
                "status" : "Error",
                "status_code" : 400,
                "data" : None,
                "error" : {
                    "status_code":400,
                    "status":'Error',
                    "message": f"{voucher_data['errorInfo']}/{voucher_data['error']}",
                    "errorId": voucher_data['errorId'],
                }
            }
        )
    elif response.status_code == 429:
        voucher_data = response.json()
        raise HTTPException(
            status_code=429,
            detail={
                "status" : "Error",
                "status_code" : 429,
                "data" : None,
                "error" : {
                    "status_code":429,
                    "status":'Error',
                    "message": f"{voucher_data['errorInfo']}/{voucher_data['error']}",
                    "errorId": voucher_data['errorId'],
                }
            }
        )

