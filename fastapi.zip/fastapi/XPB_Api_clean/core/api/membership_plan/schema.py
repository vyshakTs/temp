from typing import Optional
from pydantic import BaseModel, Field

class MemPlanCreateOrder(BaseModel):
    plan_id : int = Field(description="Membership Plan ID")
    
    class Config:
        orm_mode=True
        schema_extra = {
            "example": {
                "plan_id" : 1
            },
        }

class RzpSaveOrderPayment(BaseModel):
    razorpay_payment_id : str = Field(description="Razorpay Payment ID")
    razorpay_order_id : str = Field(description="Razorpay Order ID")
    razorpay_signature : str = Field(description="Razorpay Order Payment Signature")

class MemPlanConfirmPayment(BaseModel):
    transaction_id : int = Field(description="Membership Plan Transaction ID")

class AddConsumerMembershipPlan(BaseModel):
    transaction_id : int = Field(description="Membership Plan Transaction ID")