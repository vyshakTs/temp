from enum import Enum

class RzpOrderStatus(str, Enum):
    created = "created"
    attempted = "attempted"
    paid = "paid"

class RzpPaymentStatus(str, Enum):
    created = "created"
    authorized = "authorized"
    captured = "captured"
    refunded = "refunded"
    failed = "failed"