import hmac
from decimal import Decimal
from hashlib import sha256

def convert_to_paise(amount : Decimal):
    return amount * Decimal(100)

def generate_order_payment_signature(order_id : str, payment_id : str, secret : str):
    message = order_id + "|" + payment_id
    signature = hmac.new(secret.encode(),msg=message.encode(),digestmod=sha256).hexdigest()
    return signature

def verify_order_payment_signature(generated_signature : str, response_signature : str):
    if generated_signature == response_signature and generated_signature is not None and response_signature is not None:
        return True
    return False

