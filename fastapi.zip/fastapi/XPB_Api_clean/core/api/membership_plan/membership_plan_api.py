import razorpay

from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException
from razorpay import errors
from sqlalchemy.orm import Session

from core.api.membership_plan import crud
from core.api.membership_plan.models import RzpOrderStatus, RzpPaymentStatus
from core.api.membership_plan import schema
from core.api.consumer.crud import (
    check_if_user_exists,
    get_consumer_by_user_id,
    get_consumer_profile,
    get_membership_plan_by_id,
    get_consumer_membership_plans_by_cons_id,
    create_consumer_membership_transaction,
    update_consumer_membership_transaction,
    get_consumer_membership_transaction_min,
    get_consumer_membership_transaction,
    get_membership_plans_list,
    get_consumer_membership_plans_by_status,
    create_consumer_membership_details
)
from config.base import settings
from core.database.connection import get_db
from core.jwt import auth_handler
from core.jwt.auth_bearer import JWTBearer
from core.models.mixin import FSPStatus, MembershipPlanStatus
from core.utils.time import utc_time

router = APIRouter()

@router.post('/rzp-mem-plan-create-order', dependencies=[Depends(JWTBearer())], status_code=200, tags=["Membership Plan"])
async def razorpay_mem_plan_create_order(create_order : schema.MemPlanCreateOrder, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = check_if_user_exists(db, payload['sub'])
    if not user:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "User not found."
                    }
                }
            )
    consumer_profile = get_consumer_profile(db, user.id)
    if not consumer_profile:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "Consumer Profile not found."
                    }
                }
            )
    membership_plan = get_membership_plan_by_id(db, create_order.plan_id)
    if not membership_plan:
        raise HTTPException(
            status_code=400,
            detail={
                "status" : "Error",
                "status_code" : 404,
                "data" : None,
                "error" : {
                    "status_code":404,
                    "status":'Error', 
                    "message" : "No membership plan found."
                }
            }
        )
    consumer_membership_tran = create_consumer_membership_transaction(db, membership_plan, consumer_profile.id)
    if not consumer_membership_tran:
        raise HTTPException(
            status_code=500,
            detail={
                "status" : "Error",
                "status_code" : 500,
                "data" : None,
                "error" : {
                    "status_code":500,
                    "status":'Error', 
                    "message" : "Consumer Membership Transaction not created"
                }
            }
        )
    receipt = "memplan_" + str(consumer_membership_tran.id)
    try:
        client = razorpay.Client(auth=(settings.RAZORPAY_API_KEY, settings.RAZORPAY_API_SECRET))
        order_data = {
            "amount": int(crud.convert_to_paise(membership_plan.amount)),
            "currency": "INR",
            "receipt": receipt,
            "partial_payment":False,
            "notes": {
                "plan_name": membership_plan.plan
            }
        }
        order_response = client.order.create(data = order_data)
        order_details = {
            "order_id" : order_response["id"],
            "order_details" : order_response,
            "order_status" : order_response["status"]
        }
        update_order_id = update_consumer_membership_transaction(db, consumer_membership_tran.id, order_details)
        if not update_order_id:
            raise HTTPException(
            status_code=500,
            detail={
                "status" : "Error",
                "status_code" : 500,
                "data" : None,
                "error" : {
                    "status_code":500,
                    "status":'Error', 
                    "message" : "Razorpay Order ID was not updated to transaction."
                }
            }
        )

        response_msg = {
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": f"Successfully created razorpay order and updated to transaction.",
                    "order_data": order_data,
                    "consumer_membership_transaction_id": consumer_membership_tran.id
                },
                "error": None
            }
        }
        return response_msg
    except errors.BadRequestError:
        order_details = {
            "status" : FSPStatus.FAILED
        }
        update_order_id = update_consumer_membership_transaction(db, consumer_membership_tran.id, order_details)
        raise HTTPException(
            status_code=400,
            detail={
                "status" : "Error",
                "status_code" : 400,
                "data" : None,
                "error" : {
                    "status_code":400,
                    "status":'Error', 
                    "message" : "Razorpay Bad Request. Order Creation Failed."
                }
            }
        )

@router.post('/rzp-call-back-order-payment', status_code=200, tags=["Membership Plan"])
async def razorpay_call_back_order_payment(payment_callback : schema.RzpSaveOrderPayment, db : Session = Depends(get_db)):
    if payment_callback:
        transaction_details = get_consumer_membership_transaction_min(db, payment_callback.razorpay_order_id)
        if transaction_details:
            generated_signature = crud.generate_order_payment_signature(transaction_details.order_id, payment_callback.razorpay_payment_id, settings.RAZORPAY_API_SECRET)    
            verify_signature = crud.verify_order_payment_signature(generated_signature, payment_callback.razorpay_signature)
            if verify_signature:
                updation_details = {
                    "payment_id" : payment_callback.razorpay_payment_id,
                    "order_payment_signature" : payment_callback.razorpay_signature
                }
                update_transaction = update_consumer_membership_transaction(db, transaction_details.id, updation_details)

@router.post('/rzp-mem-plan-confirm-payment', dependencies=[Depends(JWTBearer())], status_code=200, tags=["Membership Plan"])
async def razorpay_mem_plan_confirm_payment(transaction : schema.MemPlanConfirmPayment, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = check_if_user_exists(db, payload['sub'])
    if not user:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "User not found."
                    }
                }
            )
    transaction_details = get_consumer_membership_transaction(db, transaction.transaction_id)
    if not transaction_details:
        raise HTTPException(
            status_code=400,
            detail={
                "status" : "Error",
                "status_code" : 400,
                "data" : None,
                "error" : {
                    "status_code":400,
                    "status":'Error', 
                    "message" : "No transaction found with given id."
                }
            }
        )
    try:
        client = razorpay.Client(auth=(settings.RAZORPAY_API_KEY, settings.RAZORPAY_API_SECRET))
        if transaction_details.order_id:
            order_details = client.order.fetch(transaction_details.order_id)
        else:
            order_details = None
            
        if transaction_details.payment_id:
            payment_details = client.payment.fetch(transaction_details.payment_id)
        else:
            payment_details = None

        if order_details and payment_details:
            updation_details = {
                "order_details" : order_details,
                "order_status" : order_details["status"],
                "payment_details" : payment_details,
                "payment_status" : payment_details["status"]
            }
        elif order_details and not payment_details:
            updation_details = {
                "order_details" : order_details,
                "order_status" : order_details["status"],
            }
        elif not order_details and payment_details:
            updation_details = {
                "payment_details" : payment_details,
                "payment_status" : payment_details["status"]
            }
        else:
            updation_details = None

        update_transaction = update_consumer_membership_transaction(db, transaction_details.id, updation_details)
        if not update_transaction:
            raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "Order and Payment details not found to update."
                    }
                }
            )

        response_msg = {
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": f"Successfully fetched and updated order and payment details.",
                    "order_data": order_details,
                    "payment_data": payment_details
                },
                "error": None
            }
        }
        return response_msg
    except errors.BadRequestError:
        raise HTTPException(
            status_code=400,
            detail={
                "status" : "Error",
                "status_code" : 400,
                "data" : None,
                "error" : {
                    "status_code":400,
                    "status":'Error', 
                    "message" : "Razorpay Bad Request. Confirmation Failed."
                }
            }
        )

@router.get("/get-membership-plans", dependencies=[Depends(JWTBearer())], status_code=200, tags=["Membership Plan"])
def get_membership_plans(token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = check_if_user_exists(db, payload['sub'])
    if not user:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "User not found."
                    }
                }
            )
    membership_plans = get_membership_plans_list(db=db)
    if not membership_plans:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "No Membership plans found."
                    }
                }
            )

    response_msg = {
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": f"Successfully fetched membership plans.",
                    "membership_plans": membership_plans
                },
                "error": None
            }
        }
    return response_msg

@router.get("/get-consumer-membership-history", dependencies=[Depends(JWTBearer())], status_code=200, tags=["Membership Plan"])
def get_consumer_membership_history(token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = check_if_user_exists(db, payload['sub'])
    if not user:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "User not found."
                    }
                }
            )
    consumer_profile = get_consumer_profile(db, user.id)
    if not consumer_profile:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "Consumer Profile not found."
                    }
                }
            )
    membership_plans = get_consumer_membership_plans_by_cons_id(db, consumer_profile.id)
    if not membership_plans:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "No Membership plans found."
                    }
                }
            )

    response_msg = {
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": f"Successfully fetched consumer membership plans.",
                    "membership_plans": membership_plans
                },
                "error": None
            }
        }
    return response_msg



@router.post("/add-membership-plan", dependencies=[Depends(JWTBearer())], status_code=200, tags=["Membership Plan"])
def add_membership_plan(add_consumer_membership_plan : schema.AddConsumerMembershipPlan, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = check_if_user_exists(db, payload['sub'])
    if not user:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "User not found."
                    }
                }
            )
            
    cons_memb_transaction = get_consumer_membership_transaction(db, add_consumer_membership_plan.transaction_id)
    if not cons_memb_transaction:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "Transaction not found."
                    }
                }
            )

    membership_plan = get_membership_plan_by_id(db, cons_memb_transaction.membership_plan_id)
    if not membership_plan:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "Plan not found."
                    }
                }
            )
    
    if cons_memb_transaction.status == FSPStatus.SUCCESS:
        raise HTTPException(
                status_code=400,
                detail={
                    "status" : "Error",
                    "status_code" : 400,
                    "data" : None,
                    "error" : {
                        "status_code":400,
                        "status":'Error', 
                        "message" : "Transaction not valid to proceed."
                    }
                }
            )

    consumer_details = get_consumer_by_user_id(db, user.id)
    if not consumer_details:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "Consumer Profile not found."
                    }
                }
            )
    
    if not (cons_memb_transaction.order_status == RzpOrderStatus.paid and cons_memb_transaction.payment_status == RzpPaymentStatus.captured):
        raise HTTPException(
                status_code=409,
                detail={
                    "status" : "Error",
                    "status_code" : 409,
                    "data" : None,
                    "error" : {
                        "status_code":409,
                        "status":'Error', 
                        "message" : "Transaction Order or Payment Status not Successful."
                    }
                }
            )
    active_consumer_membership_plan = get_consumer_membership_plans_by_status(db, consumer_details.id, 'ACTIVE')

    if not active_consumer_membership_plan:
        plan_status = MembershipPlanStatus.ACTIVE
        start_datetime = utc_time()
        end_datetime = start_datetime + timedelta(days=membership_plan.validity)
    else :
        plan_status = MembershipPlanStatus.UPCOMING
        upcoming_consumer_membership_plans = get_consumer_membership_plans_by_status(db, consumer_details.id, 'UPCOMING')
        if upcoming_consumer_membership_plans:
            final_end_datetime = upcoming_consumer_membership_plans.end_datetime \
                                    if active_consumer_membership_plan.end_datetime < upcoming_consumer_membership_plans.end_datetime \
                                    else active_consumer_membership_plan.end_datetime
        else:
            final_end_datetime = active_consumer_membership_plan.end_datetime

        start_datetime = final_end_datetime + timedelta(seconds=1)
        end_datetime = start_datetime + timedelta(days=membership_plan.validity)

    schedule_details = {
        "plan_status" : plan_status,
        "start_datetime" : str(start_datetime),
        "end_datetime" : str(end_datetime)
    }
    consumer_membership_plan_details = create_consumer_membership_details(db, membership_plan, consumer_details.id, schedule_details)
    if not consumer_membership_plan_details:
        raise HTTPException(
                status_code=500,
                detail={
                    "status" : "Error",
                    "status_code" : 500,
                    "data" : None,
                    "error" : {
                        "status_code":500,
                        "status":'Error', 
                        "message" : "Membership plan not added for consumer."
                    }
                }
            )
    transaction_updation_details = {
        "consumer_membership_detail_id" : consumer_membership_plan_details.id,
        "status" : FSPStatus.SUCCESS, 
        "updated_at" : utc_time()
    }
    transaction_updation = update_consumer_membership_transaction(db, cons_memb_transaction.id, transaction_updation_details)
    if not transaction_updation:
        raise HTTPException(
                status_code=500,
                detail={
                    "status" : "Error",
                    "status_code" : 500,
                    "data" : None,
                    "error" : {
                        "status_code":500,
                        "status":'Error', 
                        "message" : "Membership transaction not completed fully."
                    }
                }
            )
    response_msg = {
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Successfully added Membership plan for consumer.",
                    "membership_plan": consumer_membership_plan_details
                },
                "error": None
            }
        }
    return response_msg
