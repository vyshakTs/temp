from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Response, Form, UploadFile, Query, File
from sqlalchemy.orm import Session

from core.api.merchant import crud
from core.jwt import auth_handler
from core.jwt.auth_bearer import JWTBearer
from core.database.connection import get_db
from core.api.merchant import models, schema
from core.models.models import IDProofs
from core.jwt import auth_api_key
from fastapi.security.api_key import APIKey
from core.api.users.crud import validate_phone_number
from core.database.connection import get_db, get_mongo_db


router = APIRouter()

@router.post("/create-merchant-info",dependencies=[Depends(JWTBearer())], status_code=200, tags=["Merchant"], responses=schema.create_merchant_info_responses)
async def create_merchant_info(merchant : schema.MerchantInfo, token = Depends(JWTBearer()),db: Session = Depends(get_db)):
    token = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db = db, email = token['sub'])
    if user :
        merchant_details = crud.check_if_merchant_exists(db = db, user_id = user.id)
        if merchant_details :
            raise HTTPException (
                    status_code = 200,
                    detail = {
                        "status":"Error",
                        "status_code" : 200,
                        "data" : None,
                        "error" : {
                            "status":"Error",
                            "status_code" : 200,
                            "message" : "Merchant already exist"
                        }
                        }
                )
        else :
            create_merchant = crud.create_merchant_profile(db = db, merchant = merchant, users_id = user.id)
            if create_merchant :
                response_msg = {
                "detail": {
                "status": "Success",
                "status_code": 201,
                    "data": {
                    "status_code": 201,
                    "status": "Success",
                    "message": "Profile created Successfully"
                },
                "error": None
                }
            }
                return response_msg
            else :
                raise HTTPException (
                    status_code = 400,
                    detail = {
                        "status":"Error",
                        "status_code" : 400,
                        "data" : None,
                        "error" : {
                            "status":"Error",
                            "status_code" : 400,
                            "message" : "Merchant not added"
                        }  
                    }
                )
    else :
        raise HTTPException (
                    status_code = 404,
                    detail = {
                        "status":"Error",
                        "status_code" : 404,
                        "data" : None,
                        "error" : {
                            "status":"Error",
                            "status_code" : 404,
                            "message" : "User not exist"
                        }    
                    }
                )

@router.get('/merchant-info', dependencies=[Depends(JWTBearer())], status_code=200, tags=["Merchant"], responses = schema.merchant_info_response)
async def get_merchant_info(token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    merchant = crud.get_profile(db, payload['sub'])
    if not merchant :
        raise HTTPException (
            status_code = 404,
            detail = {
                "status" : "Error",
                "status_code" : 404,
                "data" : None,
                "error" :{
                    "status" : "Error",
                    "status_code" : 404,
                    "message" : "Data not exist"
                    }
                }
             )
    response_msg = {
                "detail" : {
                "status" : "Success",
                "status_code": 201,
                "data" : {
                    "status" : "Success",
                    "status_code" : 201,
                    "message" : "Merchants Profile",
                    "merchant_profile" : merchant
                },
                "error" : None
                }
            }
    return response_msg


@router.put('/update-merchant-info', dependencies=[Depends(JWTBearer())], status_code=200, tags=["Merchant"])
async def update_merchant_info(profile_data : schema.MerchantInfoUpdate, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db, payload['sub'])
    if not user:    
        raise HTTPException (
            status_code = 404,
            detail = {
                "status" : "Error",
                "status_code" : 404,
                "data" : None,
                "error" :{
                    "status" : "Error",
                    "status_code" : 404,
                    "message" : "User  does not exist"
                }
            }
        )                            
    profile = crud.check_if_merchant_exists(db, user.__dict__['id']) 
    if not profile:     
        raise HTTPException (
            status_code = 404,
            detail = {
                "status" : "Error",
                "status_code" : 404,
                "data" : None,
                "error" :{
                    "status" : "Error",
                    "status_code" : 404,
                    "message" : "Merchant profile does not exist"
                }
            }
        )                          
    update_profile_data = profile_data.dict(exclude_unset=True)
    update_result = crud.update_merchant_info(db, user.__dict__['id'], update_profile_data)
    if update_result:
        response_msg = {
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Profile updated Successfully"
    },
                "error": None
  }
  }
        return response_msg
    else:
        raise HTTPException (
            status_code = 400,
            detail = {
                "status": "Error",
                "status_code": 400,
                "data": None,
                "error": {
                    "status_code": 400,
                    "status": "Error",
                    "message": "Merchant profile not updated"
    }
  }
        )


@router.post("/create-merchant-business-info", dependencies=[Depends(JWTBearer())], status_code=200, tags=["Merchant"])
async def create_merchant_business_info(profile_data : schema.BusinessInfo, token = Depends(JWTBearer()), db: Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db, payload['sub'])
    if not user: 
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User does not exist"
                }
            }
        )                               
    merchant = crud.check_if_merchant_exists(db = db, user_id = user.__dict__['id']) 
    if not merchant:   
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "Merchant not exist"
                }
            }
        )                                   
    merchant_profile = crud.check_if_merchant_business_info_exist(db = db, merchant_id = merchant.__dict__['id'])
    if merchant_profile :
        raise HTTPException (
            status_code = 200,
            detail =  {
                "status": "Error",
                "status_code": 200,
                "data": None,
                "error": {
                    "status_code": 200,
                    "status": "Error",
                    "message": "Merchant profile already exist"
                }
            }
        )
    consumer_profile = crud.create_merchant_business_info(db= db, merchant = profile_data, merchant_id = merchant.__dict__['id'])
    if consumer_profile:
        response_msg = {
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Merchant profile created Successfully"
                },
                "error": None
                }
            }
        return response_msg
    else:
        raise HTTPException (
            status_code = 400,
            detail = {
                "detail": {
                    "status": "Error",
                    "status_code": 400,
                    "data": None,
                    "error": {
                        "status_code": 400,
                        "status": "Error",
                        "message": "Merchant profile not created"
                }
            }
                }
        )


@router.get('/merchant-business-info', dependencies=[Depends(JWTBearer())], status_code=200, tags=["Merchant"])
async def get_merchant_business_info(token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db, payload['sub'])
    if not user: 
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                    "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User does not exist"
            }
            }
        )                               
    merchant = crud.check_if_merchant_exists(db = db, user_id = user.__dict__['id']) 
    if not merchant:   
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "Merchant not exist"
                }
            }
        )                                   
    merchant_profile = crud.merchant_business_info(db = db, merchant_id = merchant.__dict__['id'])
    if not merchant_profile :
        raise HTTPException (
            status_code = 200,
            detail = {
                "status": "Error",
                "status_code": 200,
                "data": None,
                "error": {
                    "status_code": 200,
                    "status": "Error",
                    "message": "Merchant profile not exist"
                }
            }
        )
    response_msg = {
        "detail": {
        "status": "Success",
        "status_code": 200,
        "data": {
            "status_code": 200,
            "status": "Success",
            "message": "Merchant profile created Successfully",
            "details" : merchant_profile
            },
        "error": None
        }
    }
    return response_msg

@router.put("/update-merchant-business-info",dependencies=[Depends(JWTBearer())], status_code=200, tags=["Merchant"])
async def update_merchant_business_info(profile_data : schema.BusinessInfoUpdate, token = Depends(JWTBearer()), db: Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db, payload['sub'])
    if not user:    
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User does not exist"
    }
  }
        )                            
    merchant = crud.check_if_merchant_exists(db = db, user_id = user.__dict__['id']) 
    if not merchant:  
        raise HTTPException (
            status_code = 404,
            detail = {
                 "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "Merchant not exists"
                }
            }
        )                              
    merchant_profile = crud.check_if_merchant_business_info_exist(db = db, merchant_id = merchant.__dict__['id'])
    if not merchant_profile :
        raise HTTPException (
            status_code = 404,
            detail = {
               "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "Merchant profile not exists"
                }
            }
        )
    update_profile_data = profile_data.dict(exclude_unset=True)
    consumer_profile = crud.update_merchant_business_info(db= db, merchant_id = merchant_profile.id, updated_data = update_profile_data)
    if consumer_profile:
        response_msg = {
               "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Successfully updated merchant profile"
                },
                "error": None
  }
            }
        return response_msg
    else:
        raise HTTPException (
            status_code = 500,
            detail = {
               "status": "Error",
                "status_code": 500,
                "data": None,
                "error": {
                    "status_code": 500,
                    "status": "Error",
                    "message": "Merchant profle not updated"
                }
            }
        )
    

@router.post("/create-bank-details",dependencies=[Depends(JWTBearer())], status_code=200, tags=["Merchant"])
async def create_bank_details(bank_info : schema.BankDetails, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db, payload['sub'])
    if not user:  
        raise HTTPException (
            status_cide = 404,
            detail = {
                "status_code" : 404,
                "status" : "Error",
                "message" : "User does not exist"
            }
        )                             
    merchant = crud.check_if_merchant_exists(db = db, user_id = user.__dict__['id']) 
    if not merchant:   
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "Merchant not exist"
                }
            }
        )                             
    bank_details = crud.check_if_bank_details_exist(db = db, merchant_id = merchant.__dict__['id'])
    if bank_details:
        raise HTTPException (
            status_code = 200,
            detail = {
                "status": "Error",
                "status_code": 200,
                "data": None,
                "error": {
                    "status_code": 200,
                    "status": "Error",
                    "message": "Bank details already exist"
                }
            }
        )
    bank_details = crud.create_bank_details(db = db, bank_info = bank_info, merchant_id = merchant.__dict__['id'])
    if bank_details :
        response_msg = {
                "status": "Success",
                "status_code": 201,
                "data": {
                    "status_code": 201,
                    "status": "Success",
                    "message": "Bank details created Successfully"
                },
                "error": None
        }
    
        return response_msg
    else:
        raise HTTPException (
            status_code = 400,
            detail = {
                "status": "Error",
                "status_code": 400,
                "data": None,
                "error": {
                    "status_code": 400,
                    "status": "Error",
                    "message": "Bank details not created"
                }
            }
        )

@router.post("/create-merchant-tax-information", dependencies=[Depends(JWTBearer())], tags=["Merchant"])
def create_merchant_tax_information(tax_info : schema.MerchantTaxinformation, token = Depends(JWTBearer()), db : Session=Depends(get_db)):
    token = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db = db, email = token['sub'])

    if user:
        merchant_details = crud.check_if_merchant_exists(db = db, user_id = user.id)
        if merchant_details:
            merchant_tax_info = crud.get_merchant_taxinfo_by_merchant_id(db=db, merchant_id=merchant_details.id)
            if merchant_tax_info:
                raise HTTPException (
                    status_code = 200,
                    detail = {
                        "status": "Error",
                        "status_code": 200,
                        "data": None,
                        "error": {
                            "status_code": 200,
                            "status": "Error",
                            "message": "Merchant taxinfo already exist"
                        }
                    }
                )

            else:
                add_merchant_taxinfo = crud.add_merchant_taxinformation(db = db, merchant_tax_info=tax_info, merchant_id = merchant_details.id)
                if add_merchant_taxinfo:
                    response_msg = {
                                "detail": {
                                "status": "Success",
                                "status_code": 201,
                                "data": {
                                    "status_code": 201,
                                    "status": "Success",
                                    "message": "Merchant_Tax_Info added successfully"
                                    },
                                "error": None
                    }
                        }
                    return response_msg
                else:
                    raise HTTPException (
                        status_code = 400,
                        detail = {
                                "status": "Error",
                                "status_code": 400,
                                "data": None,
                                "error": {
                                    "status_code": 400,
                                    "status": "Error",
                                    "message": "Merchant not added"
                            }
                        }
                    )
        else:
            raise HTTPException (
                status_code = 404,
                detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message": "Merchant doesnot exist"
                    }
                }
            )
    else:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User doesnot exist"
                }
            }
        )
        
@router.get("/get-merchant-tax-information", dependencies=[Depends(JWTBearer())], tags=["Merchant"])
def get_merchant_tax_information(token = Depends(JWTBearer()), db :Session = Depends(get_db)):
    token = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db=db, email=token['sub'])

    if user:
        merchant_details = crud.check_if_merchant_exists(db =db, user_id = user.id)
        if merchant_details:
            merchant_tax_info = crud.get_merchant_taxinfo_by_merchant_id(db = db, merchant_id=merchant_details.id)
            if merchant_tax_info:
                return{
                    "detail": {
                        "status": "Success",
                        "status_code": 201,
                        "data": {
                            "status_code": 201,
                            "status": "Success",
                            "message": "Profile created Successfully",
                            "details" : merchant_tax_info
                            },
                        "error": None
                        }
                    }
            else:
                raise HTTPException(
                    status_code = 404,
                    detail = {
                        "status": "Error",
                        "status_code": 404,
                        "data": None,
                        "error": {
                            "status_code": 404,
                            "status": "Error",
                            "message": "No Tax information added"
                        }
                    }
                )
        else:
            raise HTTPException(
                status_code = 404,
                detail = { 
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message": "No merchant details added"
                    }
                }
            )
    else:
        raise HTTPException(
                status_code = 404,
                detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message": "No User"
                    }
                }
            )

@router.put("/update-merchant-tax-information", dependencies=[Depends(JWTBearer())], tags=["Merchant"])
def create_merchant_tax_information(tax_info : schema.MerchantUpdateTaxinformation, token = Depends(JWTBearer()), db : Session=Depends(get_db)):
    token = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db = db, email = token['sub'])

    if user:
        merchant_details = crud.check_if_merchant_exists(db = db, user_id = user.id)
        if merchant_details:
            merchant_tax_info = crud.get_merchant_taxinfo_by_merchant_id(db=db, merchant_id=merchant_details.id)
            if merchant_tax_info:
                tax_info_data = tax_info.dict(exclude_unset=True)
                update_merchant_taxinfo = crud.update_merchant_taxinformation(db = db, merchant_id=merchant_details.__dict__['id'], update_data=tax_info_data)
                if update_merchant_taxinfo:
                    response_msg = {
                            "detail": {
                            "status": "Success",
                            "status_code": 201,
                            "data": {
                                "status_code": 201,
                                "status": "Success",
                                "message": "Merchant_Tax_Info updated successfully"
                                     },
                            "error": None
                            }
                        }
                    return response_msg
                else:
                    raise HTTPException (
                        status_code = 400,
                        detail = {
                            "status": "Error",
                            "status_code": 400,
                            "data": None,
                            "error": {
                                "status_code": 400,
                                "status": "Error",
                                "message": "Merchant Taxinfo not updated"
                                }
                              }
                    )
            else:
                raise HTTPException (
                    status_code = 404,
                    detail = {
                        "status": "Error",
                        "status_code": 404,
                        "data": None,
                            "error": {
                            "status_code": 404,
                            "status": "Error",
                            "message": "Merchant taxinfo doesnot exist"
                        }
                    }
                )   
        else:
            raise HTTPException (
                status_code = 404,
                detail = {
                     "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message": "Merchant doesnot exist"
                    }
                }
            )
    else:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User doesnot exist"
                     }
            }
        )

@router.get("/get-bankinfo", dependencies=[Depends(JWTBearer())], tags=["Merchant"])
def get_bankinfo(token = Depends(JWTBearer()), db :Session = Depends(get_db)):
    token = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db=db, email=token['sub'])
    if user:
        merchant_details = crud.check_if_merchant_exists(db =db, user_id = user.id)
        if merchant_details:
            merchant_bank_info = crud.get_merchant_bankinfo_by_merchant_id(db = db, merchant_id=merchant_details.id)
            if merchant_bank_info:
                return{            
                        "detail": {
                            "status": "Success",
                            "status_code": 201,
                            "data": {
                                "status_code": 201,
                                "status": "Success",
                                "message": "Profile created Successfully",
                                "details" : merchant_bank_info
                            },
                            "error": None
                        }
                    }
            else:
                raise HTTPException(
                    status_code = 404,
                    detail = {
                        "status": "Error",
                        "status_code": 404,
                        "data": None,
                        "error": {
                            "status_code": 404,
                            "status": "Error",
                            "message": "No Tax bank added"
                        }
                    }
                )
        else:
            raise HTTPException(
                status_code = 404,
                detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message": "No merchant details added"
                    }
                }
            )
    else:
        raise HTTPException(
                status_code = 404,
                detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message": "No User"
                        }
                }
            )

@router.put("/update-bankinfo", dependencies=[Depends(JWTBearer())], tags=["Merchant"])
def update_bankinfo(bank_info : schema.BankUpdateDetails, token = Depends(JWTBearer()), db : Session=Depends(get_db)):
    token = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db=db, email=token['sub'])

    if user:
        merchant_details = crud.check_if_merchant_exists(db =db, user_id = user.id)
        if merchant_details:
            merchant_bank_info = crud.get_merchant_bankinfo_by_merchant_id(db = db, merchant_id=merchant_details.id)
            if merchant_bank_info:
                bank_info_data = bank_info.dict(exclude_unset=True)
                update_merchant_taxinfo = crud.update_merchant_bank_information(db = db, merchant_id=merchant_details.__dict__['id'], update_data=bank_info_data)
                if update_merchant_taxinfo:
                    return{ 
                        "detail": {
                        "status": "Success",
                        "status_code": 201,
                        "data": {
                            "status_code": 201,
                            "status": "Success",
                            "message": "Merchant_Bank_Info updated successfully"
                            },
                        "error": None
                    }
                            }
                               
                else:
                    raise HTTPException(
                        status_code = 400,
                        detail = {
                            "status": "Error",
                            "status_code": 400,
                            "data": None,
                            "error": {
                                "status_code": 400,
                                "status": "Error",
                                "message": "Issue In Update"
                            }
                        }
                    )
            else:
                raise HTTPException(
                    status_code = 404,
                    detail = {
                        "status": "Error",
                        "status_code": 404,
                        "data": None,
                        "error": {
                            "status_code": 404,
                            "status": "Error",
                            "message": "No Bank info"
                        }
                    }
                )
        else:
            raise HTTPException(
                status_code = 404,
                detail = {
                        "status": "Error",
                        "status_code": 404,
                        "data": None,
                        "error": {
                            "status_code": 404,
                            "status": "Error",
                            "message": "No Merchant details"
                        }
                }
            )
    else:
        raise HTTPException(
            status_code = 404,
            detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message": "No User"
                    }
                }
        )

@router.get("/get-countrywise-id-proof-or-address-proof", tags=["Merchant"])
async def get_country_id_proofs(country: int ,db : Session = Depends(get_db)):
    id_proofs = db.query(models.MerchantsCountryIDProofs.id_proof_id,IDProofs.id_type).filter(models.MerchantsCountryIDProofs.country_id == country).join(IDProofs,isouter=True).all()
    if id_proofs:
        return{  
            "detail": {
            "status": "Success",
            "status_code": 201,
            "data": {
                "status_code": 201,
                "status": "Success",
                "message": "Profile created Successfully",
                "id_proofs" : id_proofs
                },
            "error": None
            }
        }
    else:
        raise HTTPException (
            status_code = 404,
            detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message": "No data to display"
                }
            }
        )

@router.get("/merchant-list", status_code = 200, tags=["Merchant"])
async def merchant_list(db : Session = Depends(get_db)):
    merchant = crud.merchant_list(db = db)
    return {
            "detail": {
            "status": "Success",
            "status_code": 201,
            "data": {
                "status_code": 201,
                "status": "Success",
                "message": "Profile created Successfully",
                "details" : merchant
            },
            "error": None
        }
    }

@router.get("/merchant-list-filter", status_code = 200, tags = ["Merchant"])
async def merchant_list_filter(business_category_id : int, db : Session = Depends(get_db)):
    business_category = crud.if_business_category_exist(db = db, category_id = business_category_id)
    if not business_category :
        raise HTTPException (
            status_code = 404,
            deatil = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message": "Business category does not exist"
                    }
            }
        )
    merchant = crud.fetch_merchant_id_from_merchant_business_info(db = db, category_id = business_category_id)
    return {
            "detail": {
            "status": "Success",
            "status_code": 201,
            "data": {
                "status_code": 201,
                "status": "Success",
                "message": "Profile created Successfully",
                "details" : merchant
                },
            "error": None
        }
    }

@router.get("/get-business-category", status_code = 200, tags=["Merchant"])
async def get_business_category(db : Session = Depends(get_db)):
    business_category = crud.get_business_category(db = db)
    if business_category :
            response_msg = {  
                "detail": {
                "status": "Success",
                "status_code": 201,
                "data": {
                    "status_code": 201,
                    "status": "Success",
                    "message": "Merchant_Bank_Info updated successfully",
                    "details": business_category
                },
                "error": None
                }
            }
            return response_msg
    else:
        raise HTTPException (
            status_code = 404,
            detail = {
                    "status": "Error",
                    "status_code": 404,
                    "data": None,
                    "error": {
                        "status_code": 404,
                        "status": "Error",
                        "message": "No data to display"
                    }
                }
        )


@router.post("/create-store", status_code = 200, tags = ["Merchant"])
async def create_store_api(store_details : schema.CreateStore ,db: Session = Depends(get_db)): # api_key : APIKey = Depends(auth_api_key.get_api_key)
    user = crud.check_if_merchant_exists(db = db, user_id = store_details.user_id)
    if not user :
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User not exists."
                    }
                }
            )
    if not validate_phone_number(store_details.store_phone, country_code=None):
        raise HTTPException(
            status_code=400,
            detail={
                "status": "Error",
                "status_code": 400,
                "data": None,
                "error": {
                    "status_code": 400,
                    "status": "Error",
                    "message": "Enter a valid phone number."
                }
            }
        )
    store_details = crud.create_store(store_details=store_details, merchant_id=user.id, db = db)
    response_msg = {  
                "detail": {
                "status": "Success",
                "status_code": 201,
                "data": {
                    "status_code": 201,
                    "status": "Success",
                    "message": "Merchant_Bank_Info updated successfully",
                    "store_details": store_details
                },
                "error": None
                }
            }
    return response_msg

@router.get("/get-all-store", status_code = 200, tags = ["Merchant"])
async def get_store_api(token = Depends(JWTBearer()), db: Session = Depends(get_db)): # api_key : APIKey = Depends(auth_api_key.get_api_key)
    token = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db = db, email = token['sub'])
    if not user :
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User not exists."
                    }
                }
            )
    store_data = crud.get_all_store(db = db)
    response_msg = {  
                "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Fetched all store details",
                    "store_data": store_data
                },
                "error": None
                }
            }
    return response_msg


@router.get("/filter-store", status_code = 200, tags = ["Merchant"])
async def get_store_api(category: Optional[str] = None, sub_category: Optional[str] = None, token = Depends(JWTBearer()), db: Session = Depends(get_db)): # api_key : APIKey = Depends(auth_api_key.get_api_key)
    token = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db = db, email = token['sub'])
    if not user :
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User not exists."
                    }
                }
            )
    store_data = crud.get_store(db = db, category=category, sub_category=sub_category)
    response_msg = {  
                "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Filtered store details",
                    "store_data": store_data
                },
                "error": None
                }
            }
    return response_msg
    

@router.get("/get-store-details", status_code = 200, tags = ["Merchant"])
async def get_store_details_api(store_id:int, token = Depends(JWTBearer()), db: Session = Depends(get_db)): # api_key : APIKey = Depends(auth_api_key.get_api_key)
    token = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db = db, email = token['sub'])
    if not user :
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User not exists."
                    }
                }
            )
    store_data = crud.get_store_details(db = db, store_id=store_id)
    response_msg = {  
                "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Fetched store details",
                    "store_data": store_data
                },
                "error": None
                }
            }
    return response_msg


@router.get("/get-top-store-categories", status_code = 200, tags = ["Merchant"])
async def get_store_details_api(token = Depends(JWTBearer()), db: Session = Depends(get_db)): # api_key : APIKey = Depends(auth_api_key.get_api_key)
    token = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db = db, email = token['sub'])
    if not user :
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code": 404,
                "data": None,
                "error": {
                    "status_code": 404,
                    "status": "Error",
                    "message": "User not exists."
                    }
                }
            )
    top_categories = crud.get_store_categories(db = db)
    response_msg = {  
                "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": "Fetched store details",
                    "top_categories": top_categories
                },
                "error": None
                }
            }
    return response_msg


@router.post("/store-image-upload", dependencies=[Depends(JWTBearer())], tags=["Merchant"])
async def file_upload(source_id: int, file_collection: str, store_image: List[UploadFile] = File(...), token = Depends(JWTBearer()), db : Session=Depends(get_db), mongo_db = Depends(get_mongo_db)):
    payload = auth_handler.decode_token(token)
    current_user = crud.check_if_user_exists(db=db, email=payload['sub'])

    if not current_user:
        raise HTTPException (
            status_code = 404,
            detail = {
                "status": "Error",
                "status_code" : 404,
                "data": None,
                "error" : {
                    "status_code" : 404,
                    "status":"Error",
                    "message" : "Invalid User",
                }
            },
        )
    
    store_image_data = []
    
    for file in store_image:
        file_name = file.filename.split('.')[0] + "_" + file_collection + "_" + str(source_id)
        file_content = await file.read()
        file_types = file.content_type
        file_type_split = str(file_types).split('/')
        if 'image' != file_type_split[0]:
            raise HTTPException (
                status_code = 400,
                detail = {
                    "status": "Error",
                    "status_code" : 400,
                    "data": None,
                    "error" : {
                        "status_code" : 400,
                        "status":"Error",
                        "message" : "only image can upload",
                    }
                }
            )
        if len(file_content) <= 0:
            raise HTTPException (
                status_code = 400,
                detail = {
                    "status": "Error",
                    "status_code" : 400,
                    "data": None,
                    "error" : {
                        "status_code" : 400,
                        "status":"Error",
                        "message" : "No file",
                    }
                }
            )
        elif len(file_content) >= 6000000:
            raise HTTPException (
                status_code = 413,
                detail = {
                    "status": "Error",
                    "status_code" : 413,
                    "data": None,
                    "error" : {
                        "status_code" : 413,
                        "status":"Error",
                        "message" : "Image size must be less than 6 mb",
                    }
                }
            )
        content_type = file.content_type
        result = crud.save_file(mongo_db, file_collection, file_name, file_content, file.content_type)
        if not result:
            raise HTTPException (
                status_code = 500,
                detail = {
                    "status": "Error",
                    "status_code" : 500,
                    "data": None,
                    "error" : {
                        "status_code" : 500,
                        "status":"Error",
                        "message" : "File upload failed",
                    }
                },
            )
        store_image_data.append(store_image_data)
        print(store_image_data)
        print(f'{file_name} uploaded. Size: {len(file_content)}')

    return {
        "detail": {
            "status": "Success",
            "status_code": 200,
            "data": {
                "status_code": 200,
                "status": "Success",
                "message": "File uploaded Successfully",
                "file_data": store_image_data
            },
            "error": None
        }
    }