import gridfs
from sqlalchemy.orm import Session, load_only

from core.api.users.models import Users
from core.api.merchant import models, schema
from core.database.connection import get_db
from core.utils import password, time
from core.api.users.crud import get_user_by_email



def create_merchant_profile(db: Session, merchant: schema.MerchantInfo, users_id):
    db_user = models.MerchantProfile(
        users_id = users_id,
        merchant_account_number = merchant.merchant_account_number,
        authorized_person = merchant.authorized_person,
        dob = merchant.dob,
        gender = merchant.gender,
        profile_image = merchant.profile_image
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


def get_profile(db : Session, user_name : str):
    profile_data = db.query(Users.full_name,Users.email,Users.phone_number,models.MerchantProfile.users_id,models.MerchantProfile.merchant_account_number,models.MerchantProfile.merchant_name,
                            models.MerchantProfile.authorized_person,models.MerchantProfile.kyc_doc_type,models.MerchantProfile.kyc_doc,models.MerchantProfile.channel_partner_id,models.MerchantProfile.dob,\
                            models.MerchantProfile.gender,models.MerchantProfile.profile_image)\
                        .join(models.MerchantProfile, Users.id==models.MerchantProfile.users_id, isouter=True).filter(Users.email==user_name).first()
    return profile_data

def check_if_user_exists(db : Session, email : str):
    return get_user_by_email(db, email)
    
def check_if_merchant_exists(db : Session, user_id : int):
    return db.query(models.MerchantProfile).filter(models.MerchantProfile.users_id == user_id).first()

def update_merchant_info(db : Session, user_id : int, update_data : dict):
    result = db.query(models.MerchantProfile).filter(models.MerchantProfile.users_id==user_id).update(update_data)
    db.commit()
    #db.refresh(result) 
    return result

def check_if_merchant_business_info_exist(db: Session, merchant_id : int):
    return db.query(models.MerchantBusinessInfo).filter(models.MerchantBusinessInfo.merchant_id == merchant_id).first()

def create_merchant_business_info(db: Session, merchant: schema.BusinessInfo, merchant_id : int):
    db_user = models.MerchantBusinessInfo(
        merchant_id = merchant_id,
        registered_business_name = merchant.registered_business_name,
        registered_business_number = merchant.registered_business_number,
        website = merchant.website,
        business_description = merchant.business_description,
        business_category = merchant.business_category,
        dba = merchant.dba,
        address = merchant.address,
        operating_address = merchant.operating_address,
        postal_code = merchant.postal_code,
        operating_postal_code = merchant.operating_postal_code
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def merchant_business_info(db : Session, merchant_id : int):
    return db.query(models.MerchantBusinessInfo).options(load_only("id","merchant_id","registered_business_number","business_description","dba","operating_address",
                                                                   "operating_postal_code","registered_business_name","website","business_category","address","postal_code")
                                                                   ).filter(models.MerchantBusinessInfo.merchant_id == merchant_id).all()

def update_merchant_business_info(db: Session, merchant_id : int, updated_data : dict):
    result = db.query(models.MerchantBusinessInfo).filter(models.MerchantBusinessInfo.id == merchant_id).update(updated_data)
    db.commit()
    return result

def check_if_bank_details_exist( db: Session ,merchant_id : int):
    return db.query(models.MerchantBankDetails).filter(models.MerchantBankDetails.merchant_id == merchant_id).first()

def create_bank_details(db : Session, bank_info : schema.BankDetails, merchant_id : int):
    db_user = models.MerchantBankDetails(
        merchant_id = merchant_id, 
        current_account_name = bank_info.current_account_name,
        account_number = bank_info.account_number,
        ifsc_number = bank_info.ifsc_number,
        branch_name = bank_info.branch_name,
        bank_name = bank_info.bank_name
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def get_merchant_taxinfo_by_merchant_id(db : Session, merchant_id : int):
    return db.query(models.MerchantTaxInformation).filter(models.MerchantTaxInformation.merchant_id == merchant_id).first()

def add_merchant_taxinformation(db : Session, merchant_tax_info : schema.MerchantTaxinformation, merchant_id):
    db_taxinfo = models.MerchantTaxInformation(
        merchant_id = merchant_id,
        name_on_pan = merchant_tax_info.name_on_pan,
        pan_number = merchant_tax_info.pan_number,
        pan_doc = merchant_tax_info.pan_doc,
        gstin_doc = merchant_tax_info.gstin_doc,
        tan_doc = merchant_tax_info.tan_doc,
        id_proof = merchant_tax_info.id_proof,
        id_proof_type = merchant_tax_info.id_proof_type,
        id_proof_doc = merchant_tax_info.id_proof_doc,
        address_proof = merchant_tax_info.address_proof,
        address_proof_type = merchant_tax_info.address_proof_type,
        address_proof_doc = merchant_tax_info.address_proof_doc
            )
    db.add(db_taxinfo) 
    db.commit()
    db.refresh(db_taxinfo)
    return db_taxinfo

def update_merchant_taxinformation(db : Session, merchant_id : int, update_data : dict):
    result = db.query(models.MerchantTaxInformation).filter(models.MerchantTaxInformation.merchant_id==merchant_id).update(update_data)
    db.commit()
    #db.refresh(result) 
    return result

def get_merchant_bankinfo_by_merchant_id(db : Session, merchant_id : int):
    return db.query(models.MerchantBankDetails).filter(models.MerchantBankDetails.merchant_id == merchant_id).first()

def update_merchant_bank_information(db : Session, merchant_id : int, update_data : dict):
    result = db.query(models.MerchantBankDetails).filter(models.MerchantBankDetails.merchant_id==merchant_id).update(update_data)
    db.commit()
    #db.refresh(result) 
    return result

def merchant_list(db = Session):
    profile_data = db.query(Users.full_name,Users.email,Users.phone_number,models.MerchantProfile.users_id,models.MerchantProfile.merchant_account_number,models.MerchantProfile.merchant_name,
                            models.MerchantProfile.authorized_person,models.MerchantProfile.kyc_doc_type,models.MerchantProfile.kyc_doc,models.MerchantProfile.channel_partner_id,models.MerchantProfile.dob,\
                            models.MerchantProfile.gender,models.MerchantProfile.profile_image)\
                        .join(models.MerchantProfile, Users.id==models.MerchantProfile.users_id, isouter=True).order_by(Users.full_name).all()
    return profile_data

def if_business_category_exist(db : Session, category_id : int):
    return db.query(models.BusinessCategory).filter(models.BusinessCategory.id == category_id).first()

def fetch_merchant_id_from_merchant_business_info(db : Session, category_id : int):
    merchant_info =  db.query(models.MerchantBusinessInfo).options(load_only(
        "id", "registered_business_name", "address", "registered_business_number", "website", "business_category"
    )).filter(models.MerchantBusinessInfo.business_category == category_id).all()
    print(merchant_info)
    return merchant_info

def display_merchant_details(db : Session, merchant_id : list):
    return db.query(models.MerchantProfile).filter(models.MerchantProfile.id.in_(merchant_id)).all()

def get_business_category(db = Session):
    return db.query(models.BusinessCategory).options(load_only(
        "id","category")).all()

def create_store(db : Session, store_details: dict, merchant_id: int):
    store_info = models.Store(
        merchant_id = merchant_id,
        store_name = store_details.store_name,
        store_email = store_details.store_email,
        store_phone = store_details.store_phone,
        address1 = store_details.address1,
        location = store_details.location,
        store_images = store_details.store_images,
        license_number = store_details.license_number,
        store_category_id = store_details.store_category,
        store_sub_category_id = store_details.store_sub_category,
        working_time = store_details.working_time
    )
    db.add(store_info) 
    db.commit()
    db.refresh(store_info)
    return store_info

def get_all_store(db : Session):
    return db.query(models.Store).all()

def get_store_details(db : Session, store_id):
    return db.query(models.Store).filter(models.Store.id==store_id).first()

def get_store(db : Session, category: str, sub_category: str):
    category_id = db.query(models.BusinessCategory.id).filter(models.BusinessCategory.category==category).first()
    sub_category_id = db.query(models.StoreSubCategory.id).filter(models.StoreSubCategory.category==sub_category).first()
    if category_id and not sub_category_id: 
        category_id = category_id[0]
        store_data = db.query(models.Store).filter(models.Store.store_category_id==category_id).all()
    elif sub_category_id and not category_id:
        sub_category_id = sub_category_id[0]
        store_data = db.query(models.Store).filter(models.Store.store_sub_category_id==sub_category_id).all()
    elif sub_category_id and category_id:
        store_data = db.query(models.Store).filter(models.Store.store_category_id==category_id, models.Store.store_sub_category_id==sub_category_id).all()
    return store_data

def save_file(mongo_db , collection : str, file_name: str, content : bytes, content_type : str):
    try:
        fs = gridfs.GridFS(mongo_db, collection)
        stored = fs.put(content, filename=file_name, contentType=content_type)
        return stored
    except Exception as e:
        print(e)
        return False

def get_store_categories(db : Session):
    top_categories = db.query(models.StoreSubCategory).filter(models.StoreSubCategory.is_top==True).all()
    return top_categories
