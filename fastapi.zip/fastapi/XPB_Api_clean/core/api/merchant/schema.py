import json
from typing import List

from pydantic import BaseModel, Field, EmailStr, Json
from fastapi import UploadFile
from datetime import date
from core.models.mixin import GenderType

class MerchantInfo(BaseModel):
    merchant_account_number : str = Field(default = None, description = "Merchant Account in Number")
    authorized_person : str = Field(default = None, description = "Authorized person")
    dob : date = Field(default = False, description = "Date Of Birth")
    gender : GenderType | None = Field(default=None, description="Gender 1-FEMALE, 2-MALE, 3-OTHER")
    profile_image : str | None = Field(default=None, description="Profile image url")


    class Config:
        schema_extra = {
            "example": {
                "merchant_account_number": "123456789",
                "authorized_person": 1,
                "dob": "1995-01-01",
                "gender": 1,
                "profile_image": "url",
            },
        }


class MerchantInfoUpdate(BaseModel):
    merchant_account_number : str | None = Field(default=None, description="Merchant Account in Number")
    authorized_person : str | None = Field(default = None, description = "Authorized person")
    dob : date | None = Field(default=None, description="Date of Birth")
    gender : GenderType | None = Field(default=None, description="Gender 1-FEMALE, 2-MALE, 3-OTHER")
    profile_image : str | None = Field(default=None, description="Profile image url")

    class Config:
        schema_extra = {
            "example": {
                "merchant_account_number": "123456789",
                "authorized_person": 1,
                "dob": "1995-01-01",
                "gender": 1,
                "profile_image": "url",
            },
        }

class BusinessInfo(BaseModel):
    registered_business_name : str = Field(default = None, description = "Name of the Business")
    registered_business_number : str | None = Field(default=None, description="Business Account in Number")
    website : str | None = Field(default=None, description="Web site url")
    business_description  : str = Field(default = None, description = "About Busniess")
    business_category : int = Field(default = None, description = "Avialble categories")
    dba : str | None = Field(default=None, description="Business Trade Name")
    address : str = Field(default = None, description = "Business Address")
    operating_address : str | None = Field(default=None, description="Current Address")
    postal_code : str = Field(default = None, description = "Postal Code")
    operating_postal_code : str | None = Field(default=None, description="Current Postal Code")

    class Config:
        schema_extra = {
            "example": {
                "registered_business_name": "NAME",
                "registered_business_number": "1234qwerty",
                "website": "url",
                "business_description": "Sports item is Availabe",
                "business_category": "Sport Shop",
                "dba" : "Trade Name",
                "address" : "NAME @",
                "operating_address" : "NAME @",
                "postal_code" : "12345",
                "operating_postal_code" : "12345" 
            },
        }

class BusinessInfoUpdate(BaseModel):
    registered_business_name : str | None = Field(default = None, description = "Name of the Business")
    registered_business_number : str | None  = Field(default=None, description="Business Account in Number")
    website : str | None = Field(default=None, description="Web site url")
    business_description  : str | None = Field(default = None, description = "About Busniess")
    business_category : int | None = Field(default = None, description = "Avialble categories")
    dba : str | None = Field(default=None, description="Business Trade Name")
    address : str | None = Field(default = None, description = "Business Address")
    operating_address : str | None = Field(default=None, description="Current Address")
    postal_code : str | None = Field(default = None, description = "Postal Code")
    operating_postal_code :str | None = Field(default=None, description="Current Postal Code")

    class Config:
        schema_extra = {
            "example": {
                "registered_business_name": "NAME",
                "registered_business_number": "1234qwerty",
                "website": "url",
                "business_description": "Sports item is Availabe",
                "business_category": 1,
                "dba" : "Trade Name",
                "address" : "NAME @",
                "operating_address" : "NAME @",
                "postal_code" : "12345",
                "operating_postal_code" : "12345" 
            },
        }

class BankDetails(BaseModel):
    current_account_name : str = Field(default = None, description = "Account Name")
    account_number : str = Field(default = None, description = "Account Number")
    ifsc_number : str = Field(default = None, description = "Bank IFSC Code")
    branch_name : str = Field(default = None, description = "Bank Branch")
    bank_name :str = Field(default = None, description = "Bank Name")

    class Config:
        schema_extra = {
            "example": {
                "current_account_name": "NAME",
                "account_number": "123456789",
                "ifsc_number": "XX22XX",
                "branch_name": "Place",
                "bank_name": "NAME"
            },
        }

class MerchantUpdateTaxinformation(BaseModel):
    name_on_pan : str | None = Field(default = None, description = "PAN Holder Name")
    pan_number : str | None = Field(default = None, description = "PAN Card Number")
    gstin_doc : str  | None = Field(default = None, description = "GST document url")
    pan_doc : str  | None = Field(default = None, description = "PAN document url")
    tan_doc : str  | None = Field(default = None, description = "TAN document url")
    id_proof : str  | None = Field(default = None, description = "ID proof Number")
    id_proof_type : int  | None = Field(default = None, description = "Which Id Proof")
    id_proof_doc : str | None = Field(default = None, description = "ID document url")
    address_proof : str | None = Field(default = None, description = "ID proof Number")
    address_proof_type : int | None = Field(default = None, description = "Which Id Proof")
    address_proof_doc : str | None = Field(default = None, description = "ID document url")

    class Config:
        schema_extra = {
            "example": {
                "name_on_pan": "NAME",
                "pan_number": "1234qwerty",
                "gstin_doc": "url",
                "pan_doc": "url",
                "tan_doc": "url",
                "id_proof" : "1234qwerty",
                "id_proof_type" : 1,
                "id_proof_doc" : "url",
                "address_proof" : "1234qwerty",
                "address_proof_type" : 1,
                "address_proof_doc" : "url"
            },
        }

class MerchantTaxinformation(BaseModel):
    name_on_pan : str | None = Field(default = None, description = "PAN Holder Name")
    pan_number : str | None = Field(default = None, description = "PAN Card Number")
    gstin_doc : str  | None = Field(default = None, description = "GST document url")
    pan_doc : str  | None = Field(default = None, description = "PAN document url")
    tan_doc : str  | None = Field(default = None, description = "TAN document url")
    id_proof : str  | None = Field(default = None, description = "ID proof Number")
    id_proof_type : int  | None = Field(default = None, description = "Which Id Proof")
    id_proof_doc : str | None = Field(default = None, description = "ID document url")
    address_proof : str | None = Field(default = None, description = "ID proof Number")
    address_proof_type : int | None = Field(default = None, description = "Which Id Proof")
    address_proof_doc : str | None = Field(default = None, description = "ID document url")

    class Config:
        schema_extra = {
            "example": {
                "name_on_pan": "NAME",
                "pan_number": "1234qwerty",
                "gstin_doc": "url",
                "pan_doc": "url",
                "tan_doc": "url",
                "id_proof" : "1234qwerty",
                "id_proof_type" : 1,
                "id_proof_doc" : "url",
                "address_proof" : "1234qwerty",
                "address_proof_type" : 1,
                "address_proof_doc" : "url"
            },
        }

class BankUpdateDetails(BaseModel):
    current_account_name : str | None = Field(default = None, description = "Account Name")    
    account_number : str | None = Field(default = None, description = "Account Number")
    ifsc_number : str | None = Field(default = None, description = "Bank IFSC Code")
    branch_name : str | None = Field(default = None, description = "Bank Branch")
    bank_name :str | None = Field(default = None, description = "Bank Name")

    class Config:
        schema_extra = {
            "example": {
                "current_account_name": "NAME",
                "account_number": "123456789",
                "ifsc_number": "XX22XX",
                "branch_name": "Place",
                "bank_name": "NAME"
            },
        }
        

store_working_time = {
    "sunday": {
        "opening_time": "9:00",
        "closing_time": "6:30"
    },
    "monday": {
        "opening_time": "9:00",
        "closing_time": "6:30"
    },
    "tuesday": {
        "opening_time": "9:00",
        "closing_time": "6:30"
    },
    "wednesday": {
        "opening_time": "9:00",
        "closing_time": "6:30"
    },
    "thursday": {
        "opening_time": "9:00",
        "closing_time": "6:30"
    },
    "friday": {
        "opening_time": "9:00",
        "closing_time": "6:30"
    },
    "saturday": {
        "opening_time": "9:00",
        "closing_time": "6:30"
    }
}


class CreateStore(BaseModel):
    user_id: int = Field(default = None, description = "User id")   
    store_name: str = Field(default = None, description = "Name of the store")   
    store_email: EmailStr = Field(default = None, description = "Store email address")   
    store_phone: str = Field(default = None, description = "Store phone number.")   
    address1: str = Field(default = None, description = "Store address")   
    location: str = Field(default = None, description = "store location latitude and longitude")   
    store_images: str = Field(default = None, description = "Store images")   
    license_number: int = Field(default = None, description = "Store licence number")   
    store_category: int = Field(default = None, description = "Store category")   
    store_sub_category: int = Field(default = None, description = "Store sub category")   
    working_time: dict = Field(default = store_working_time, description = "working days and time of each day as json")
    
    
create_merchant_info_responses = {
    
        200: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "detail": {
                            "summary": "merchant profile create fails",
                            "value": {
                        "detail" : {
                            "status":"Error",
                            "status_code" : 200,
                            "data" : None,
                            "error" : {
                                "status":"Error",
                                "status_code" : 200,
                                "message" : "Merchant already exist"
                                }
                            }
                        },
                    }
                }
            }
            }
        },

        201: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "detail" : {
                            "summary" : "merchant profile create",
                            "value" : {
                "detail" : {
                    "status": "Success",
                    "status_code": 201,
                        "data": {
                        "status_code": 201,
                        "status": "Success",
                        "message": "Profile created Successfully"
                                },
                    "error": None
                            }
                        }
                    },
                }
                }
            }
        },

        400: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "detail" : {
                            "summary" : "merchant not added",
                            "value" : {
                        "detail" : {
                            "status":"Error",
                            "status_code" : 400,
                            "data" : None,
                            "error" : {
                                "status":"Error",
                                "status_code" : 400,
                                "message" : "Merchant not added"
                                    }  
                                }
                            }
                        }
                    },
                }
            }
        },

        404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "detail" : {
                            "summary" : "User not exist",
                            "value" : {
                        "detail" : {
                            "status":"Error",
                            "status_code" : 404,
                            "data" : None,
                            "error" : {
                                "status":"Error",
                                "status_code" : 404,
                                "message" : "User not exist"
                            }    
                        }
                            }
                        }
                    },
                }
            }
        }
}

merchant_info_response = {

        404: {
            "description": "Error",
            "content": {
                "application/json": {
                    "examples": {
                        "detail": {
                            "summary": "merchant profile display fails",
                            "value": {
                        "detail" : {
                            "status" : "Error",
                "status_code" : 404,
                "data" : None,
                "error" :{
                    "status" : "Error",
                    "status_code" : 404,
                    "message" : "Data not exist"
                    }
                }
                        },
                    }
                 }
                    }
                }
            },
        


        201: {
            "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "detail" : {
                            "summary" : "display merchant profile",
                            "value" : {
                "detail" : {     
                "status" : "Success",
                "status_code": 201,
                "data" : {
                    "status" : "Success",
                    "status_code" : 201,
                    "message" : "Merchants Profile"
                },
                "error" : None
                }
                    },
                }
                }
            }
            }
        },
}