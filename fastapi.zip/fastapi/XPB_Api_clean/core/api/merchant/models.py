from sqlalchemy import JSON, Column, Date, Enum, ForeignKey, Integer, String, UniqueConstraint, Boolean, Float, Text
from sqlalchemy.sql import text

from core.database.connection import Base
from core.models.mixin import GenderType, TimeStamp
from core.api.consumer.models import ConsumerProfile


class BusinessCategory(Base, TimeStamp):

    __tablename__ = "business_category"
    id = Column(Integer, primary_key = True)
    category = Column(String(50), unique = True, nullable = False)

class MerchantProfile(Base, TimeStamp): 

    __tablename__ = "merchant_profile"
    id = Column(Integer, primary_key=True)
    users_id = Column(Integer, ForeignKey("users.id"), unique = True, nullable = False)
    sales_person_id = Column(String(10))
    merchant_account_number = Column(String(50), nullable=True)
    merchant_name = Column(String(50), nullable=True)
    authorized_person = Column(String(50), nullable=True)
    kyc_doc_type = Column(String(50), nullable=True)
    kyc_doc = Column(String(100), nullable=True)
    #kyc_doc_verified = Column(Boolean, default=False)
    channel_partner_id = Column(Integer, nullable=True)
    dob = Column(Date, nullable=False)
    gender = Column(Enum(GenderType), nullable=False)
    profile_image = Column(String(1024), nullable=True)


class MerchantBusinessInfo(Base, TimeStamp):

    __tablename__ = "merchant_business_info"
    id = Column(Integer, primary_key=True)
    merchant_id = Column(Integer, ForeignKey("merchant_profile.id"), unique = True, nullable = False)
    registered_business_name = Column(String(255),nullable = False)
    registered_business_number = Column(String(32),nullable = True)
    website = Column(String(100),nullable = True)
    business_description = Column(String(255),nullable = False)
    business_category = Column(Integer, ForeignKey("business_category.id"),nullable = False)
    dba = Column(String(255),nullable = True)
    address = Column(String(255), nullable=False)
    operating_address = Column(String(255), nullable=True)   
    postal_code = Column(String(20), nullable=False)
    operating_postal_code = Column(String(20), nullable=True)


class MerchantTaxInformation(Base, TimeStamp):

    __tablename__ = "merchant_tax_information"
    id = Column(Integer, primary_key=True)
    merchant_id = Column(Integer, ForeignKey("merchant_profile.id"), nullable=False, unique=True)
    name_on_pan = Column(String(50), nullable=True)
    pan_number = Column(String(20), nullable=True)
    pan_doc = Column(String(1024), nullable=True)
    #pan_doc_verified = Column(Boolean, default=False)
    gstin_doc = Column(String(1024), nullable=True)
    #gstin_doc_verified = Column(Boolean, default=False)
    tan_doc = Column(String(1024), nullable=True)
    #tan_doc_verified = Column(Boolean, default=False)
    id_proof = Column(String(100), nullable=True)
    id_proof_type = Column(Integer, ForeignKey("id_proofs.id"), nullable=True)
    id_proof_doc = Column(String(1024), nullable=True)
    #id_proof_doc_verified = Column(Boolean, default=False)
    address_proof = Column(String(50), nullable=True)
    address_proof_type = Column(Integer, ForeignKey("id_proofs.id"), nullable=True)
    address_proof_doc = Column(String(100), nullable=True)
    #address_proof_doc_verified = Column(Boolean, default=False)


class MerchantBankDetails(Base, TimeStamp):

    __tablename__ = "merchant_bank_details"
    id = Column(Integer, primary_key=True)
    merchant_id = Column(Integer, ForeignKey("merchant_profile.id"), unique = True, nullable = False)
    current_account_name = Column(String(50),nullable = False)
    account_number = Column(String(50),nullable = False)
    ifsc_number = Column(String(20),nullable = False)
    branch_name = Column(String(50),nullable = False)
    bank_name = Column(String(50),nullable = False)


class Store(Base, TimeStamp):

    __tablename__ = "store"
    id = Column(Integer, primary_key=True)
    merchant_id = Column(Integer, ForeignKey("merchant_profile.id"))
    store_name = Column(String(50), nullable=False)
    store_email = Column(String(50), nullable=False)
    store_phone = Column(String(20), nullable=False)
    address1 = Column(String(100), nullable=False)
    latitude = None
    longitude = None
    store_images = Column(String(100), nullable=True)
    license_number = Column(String(20), nullable=False)
    store_category_id = Column(Integer, ForeignKey("business_category.id"))
    store_sub_category_id = Column(Integer, ForeignKey("store_subcategory.id"))
    working_time = Column(JSON)
    

class StoreHoliday(Base):
    __tablename__ = "store_holiday"
    id = Column(Integer, primary_key=True)
    store_id = Column(Integer, ForeignKey("store.id"))
    holiday_date = None
    holiday_date = Column(Date, server_default=text("(now() at time zone 'utc')::date"))
    
    
class StoreRating(Base, TimeStamp):
    __tablename__ = "store_rating"
    id = Column(Integer, primary_key=True)
    store_id = Column(Integer, ForeignKey("store.id"))
    consumer_id = Column(Integer, ForeignKey("consumer_profile.id"))
    rating = Column(Float, nullable=False)
    review = Column(Text)
    

class StoreSubCategory(Base, TimeStamp):
    __tablename__ = "store_subcategory"
    id = Column(Integer, primary_key=True)
    business_category_id = Column(Integer, ForeignKey("business_category.id"))
    category = Column(String(100), nullable=True)
    is_top = Column(Boolean, default=False)


class MerchantsCountryIDProofs(Base, TimeStamp):

    __tablename__ = "merchants_country_id_proofs"
    id = Column(Integer, primary_key = True)
    country_id = Column(Integer, ForeignKey("merchants_country_id_proofs.id"))
    id_proof_id = Column(Integer, ForeignKey("id_proofs.id"))
    UniqueConstraint("country_id","id_proof_id")
