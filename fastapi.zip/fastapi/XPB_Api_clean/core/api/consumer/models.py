from sqlalchemy import (JSON, Boolean, Column, Date, DateTime, Enum,
                        ForeignKey, Integer, String, CheckConstraint, DECIMAL, BigInteger)
from sqlalchemy.dialects.postgresql import JSONB

from core.database.connection import Base
from core.models.mixin import DeviceType, GenderType, TimeStamp, MembershipPlanStatus, FSPStatus, MessageType


class ConsumerProfile(Base, TimeStamp):

    __tablename__ = "consumer_profile"
    id = Column(Integer, primary_key=True)
    users_id = Column(Integer, ForeignKey("users.id"), unique=True)
    dob = Column(Date)
    gender = Column(Enum(GenderType), nullable=False)
    address1 = Column(String(100))
    address2 = Column(String(100))
    city = Column(String(20))
    district = Column(String(20))
    state = Column(String(20))
    country = Column(String(20))
    postal_code = Column(String(20))
    current_location = Column(JSON)
    device_platform = Column(Enum(DeviceType))
    fcm_token = Column(String(1024))
    last_login = Column(DateTime)
    email_verified = Column(Boolean, default=False)
    profile_image = Column(String())
    phone_number_verified = Column(Boolean, default=False)
    device_id = Column(String(1024))

    class Config:
        orm_mode = True


class SocialMedia(Base, TimeStamp):
    __tablename__ = 'social_media'
    id = Column(Integer, primary_key=True)
    name = Column(String(20), nullable=False)
    column_name = Column(String(20), nullable=False)
    

class FollowedSocialMedia(Base, TimeStamp):
    __tablename__ = 'followed_social_media'
    id = Column(Integer, primary_key=True)
    users_id = Column(Integer, ForeignKey("users.id"), unique=True)
    facebook_followed = Column(Boolean, default=False)
    youtube_followed = Column(Boolean, default=False)
    twitter_followed = Column(Boolean, default=False)
    whatsapp_followed = Column(Boolean, default=False)
    linkedin_followed = Column(Boolean, default=False)
    telegram_followed = Column(Boolean, default=False)
    instagram_followed = Column(Boolean, default=False)
    discord_followed = Column(Boolean, default=False)

class Notifications(Base, TimeStamp):
    __tablename__ = 'notifications'
    id = Column(Integer, primary_key=True)
    users_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    message = Column(String, nullable=False)
    message_type = Column(Enum(MessageType))
    url = Column(String)
    read = Column(Boolean, default=False)

class MembershipPlans(Base, TimeStamp):
    __tablename__ = 'membership_plans'
    id = Column(Integer, primary_key=True)
    plan = Column(String(20), nullable=False)
    description = Column(String(255), nullable=True)
    validity = Column(Integer, nullable=False)
    amount = Column(DECIMAL, nullable=False)
    benefits = Column(JSONB, nullable=True)
    enabled = Column(Boolean, default=True)
    __table_args__ = (
        CheckConstraint("validity > 0"),
    )

class ConsumerMembershipDetails(Base, TimeStamp):
    __tablename__ = 'consumer_membership_details'
    id = Column(BigInteger, primary_key=True)
    consumer_id = Column(Integer, ForeignKey("consumer_profile.id"), nullable=False)
    plan_id = Column(Integer, ForeignKey("membership_plans.id"), nullable=False)
    plan_name = Column(String(20), nullable=False)
    plan_validity = Column(Integer, nullable=False)
    plan_amount = Column(DECIMAL, nullable=False)
    start_datetime = Column(DateTime, nullable=False)
    end_datetime = Column(DateTime, nullable=False)
    remaining_duration = Column(Integer, nullable=True)
    status = Column(Enum(MembershipPlanStatus), nullable=False)

class ConsumerMembershipTransaction(Base, TimeStamp):
    __tablename__ = 'consumer_membership_transaction'
    id = Column(BigInteger, primary_key=True)
    consumer_id = Column(Integer, ForeignKey("consumer_profile.id"), nullable=False)
    membership_plan_id = Column(Integer, ForeignKey("membership_plans.id"), nullable=False)
    consumer_membership_detail_id = Column(BigInteger, ForeignKey("consumer_membership_details.id"), nullable=True)
    plan_name = Column(String(20), nullable=False)
    plan_validity = Column(Integer, nullable=False)
    plan_amount = Column(DECIMAL, nullable=False)
    order_id = Column(String(255), nullable=True)
    order_details = Column(JSONB, nullable=True)
    order_status = Column(String(255), nullable=True)
    payment_id = Column(String(255), nullable=True)
    payment_details = Column(JSONB, nullable=True)
    payment_status = Column(String(255), nullable=True)
    order_payment_signature = Column(String(255), nullable=True)
    status = Column(Enum(FSPStatus), nullable=False)    

class CompleteProfile(Base, TimeStamp):
    __tablename__ = 'complete_profile'
    id = Column(Integer, primary_key = True)
    name = Column(String(40), nullable = False)
    reward = Column(DECIMAL, nullable = False)
    column_name = Column(String(50), nullable = False)


class ConsumerCompleteProfile(Base, TimeStamp):
    __tablename__ = 'consumer_complete_profile'
    id = Column(Integer, primary_key = True)
    users_id = Column(Integer,ForeignKey('users.id'), unique = True)
    sign_up_status = Column(Boolean, default = False)
    profile_completion_status = Column(Boolean, default = False)
    social_media_status = Column(Boolean, default = False)
    refer_friend_status = Column(Boolean, default = False)
    first_purchase_status = Column(Boolean, default = False)
    membership_and_prepaid_card_status = Column(Boolean, default = False)
    completed = Column(Boolean, default = False)