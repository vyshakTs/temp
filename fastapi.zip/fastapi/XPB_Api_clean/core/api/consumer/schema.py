from typing import Optional
from datetime import date, datetime
from pydantic import BaseModel, Field, EmailStr

from core.api.users.schema import UserOut

class ConsumerProfileBase(BaseModel):
    dob : date | None = Field(default=None, description="Date of Birth")
    gender : int | None = Field(default=None, description="Gender 1-FEMALE, 2-MALE, 3-OTHER, 4-NOTSPECIFIED")
    address1 : str | None = Field(default=None, description="Address line 1")
    address2 : str | None = Field(default=None, description="Address line 2")
    city : str | None = Field(default=None, description="City")
    district : str | None = Field(default=None, description="District")
    state : str | None = Field(default=None, description="State")
    country : str | None = Field(default=None, description="Country")
    postal_code : str  | None = Field(default=None, description="Postal Code")
    current_location : str | None = Field(default=None, description="Current location of User")
    device_platform : int  | None = Field(default=None, description="Device Platform 1-Android, 2-IOS, 3-NOTSPECIFIED")
    fcm_token : str | None = Field(default=None, description="FCM token")
    last_login : datetime | None = Field(default=None, description="Last Login datetime")
    email_verified : bool = Field(default=False, description="Flag to show whether email verified")
    profile_image : str | None = Field(default=None, description="Profile image url")
    phone_number_verified : bool = Field(default=False, description="Flag to show whether phone number verified")

    class Config:
        orm_mode=True
        schema_extra = {
            "example": {
                "dob": "1995-02-06",
                "gender": 1,
                "address1": "Abc xyz",
                "address2": "",
                "city": "Kochi",
                "district": "Ernakulam",
                "state": "Kerala",
                "country": "India",
                "postal_code": "682021",
                "current_location": "",
                "device_platform": 1,
                "fcm_token": "",
                "last_login": "2023-02-06T07:13:43.330Z",
                "email_verified": False,
                "profile_image": "",
                "phone_number_verified": False
            },
        }

class UpdateConsumerProfile(ConsumerProfileBase):
    full_name: str | None = Field(default=False, description="Full name")

    class Config:
        orm_mode=True
        schema_extra = {
            "example": {
                "full_name" : "test",
                "dob": "1995-02-06",
                "gender": 1,
                "address1": "Abc xyz",
                "address2": "",
                "city": "Kochi",
                "district": "Ernakulam",
                "state": "Kerala",
                "country": "India",
                "postal_code": "682021",
                "current_location": "",
                "device_platform": 1,
                "fcm_token": "",
                "last_login": "2023-02-06T07:13:43.330Z",
                "email_verified": False,
                "profile_image": "",
                "phone_number_verified": False
            },
        }

class ConsumerProfileUserOut(ConsumerProfileBase,UserOut):
    email_verified : bool = None
    phone_number_verified : bool = None

class FollowSocialMedia(BaseModel):
    id: int

class NotificationPost(BaseModel):
    message: str
    url: Optional[EmailStr]

class NotificationPatch(BaseModel):
    id: int

consumer_profile_response = {

    200 : {
        "description": "Success",
        "content": {
            "application/json": {
                "examples": {
                    "Success": {
                        "summary": "Consumer details.",
                        "value": {
                        	"detail" : { 
                        		"status" : "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "Consumer details.",
                                    "consumer_profile": {
                                        "full_name": "Test",
                                        "email": "test@gmail.com",
                                        "phone_number": "+911234567899",
                                        "users_id": 140,
                                        "dob": "1995-02-06",
                                        "gender": 1,
                                        "address1": "Abc xyz",
                                        "address2": "",
                                        "city": "Kochi",
                                        "district": "Ernakulam",
                                        "state": "Kerala",
                                        "country": "India",
                                        "postal_code": "682021",
                                        "current_location": "",
                                        "device_platform": 1,
                                        "fcm_token": "",
                                        "last_login": "2023-02-06T12:43:43.330000",
                                        "email_verified": False,
                                        "profile_image": "",
                                        "phone_number_verified": False
                                    }
                                },
                        		"error": None 
                        	}
                        }
                    }
                }
            }
        }
    }
}



create_consumer_profile_responses = {
    201 : {
        "description": "Success",
        "content": {
            "application/json": {
                "examples": {
                    "Success": {
                        "summary": "Profile creation success",
                        "value": {
                        	"detail" : { 
                        		"status" : "Success", 
                        		"status_code": 201, 
                        		"data": { 
                        			"status_code": 201, 
                        			"status": "Success", 
                        			"message": "Profile created Successfully" 
                        		}, 
                        		"error": None 
                        	}
                        }
                    }
                }
            }
        }
    },
    403 : {
        "description": "Error",
        "content": {
            "application/json": {
                "examples": {
                    "Profile already exists" : {
                        "summary" : "Profile already exists",
                        "value" : {
                            "detail":{
                                "status" : "Error", 
                                "status_code" : 403,
                                "data" : None, 
                                "error" : { 
                                    "status_code":403, 
                                    "status":'Error', 
                                    "message" : "Profile already exists." 
                                }
                            }
                        }
                    }
                }
            }
        }
    },
    404 : {
        "description": "Error",
        "content": {
            "application/json": {
                "examples": {
                    "User not found" : {
                        "summary" : "User not found",
                        "value" : {
                            "detail":{
                                "status" : "Error", 
                                "status_code" : 404, 
                                "data" : None, 
                                "error" : {
                                    "status_code":404, 
                                    "status":'Error', 
                                    "message" : "User not found." 
                                }
                            }
                        }
                    }
                }
            }
        }
    },
    500: {
        "description": "Error",
        "content": {
            "application/json": {
                "examples": {
                    "Server Error" : {
                        "summary" : "Profile creation failed",
                        "value" : {
                            "detail":{
                                "status" : "Error", 
                                "status_code" : 500, 
                                "data" : None, 
                                "error" : { 
                                    "status_code":500, 
                                    "status":'Error', 
                                    "message" : "Internal server error." 
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
    
update_consumer_profile_response = {

    404 : {
        "description": "Error",
        "content": {
            "application/json": {
                "examples": {
                    "User not found" : {
                        "summary" : "User not found",
                        "value" : {
                            "detail":{
                                "status" : "Error",
                                "status_code" : 404,
                                "data" : None,
                                "error" : {
                                    "status_code":404,
                                    "status":'Error', 
                                    "message" : "User not found."
                                }
                            }
                        }
                    },
                    "profile_not_exist" : {
                        "summary" : "Profile does not exist.",
                        "value" : {
                            "detail":{
                                "status" : "Error",
                                "status_code" : 404,
                                "data" : None,
                                "error" : {
                                    "status_code":404,
                                    "status":'Error', 
                                    "message" : "Profile does not exist."
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description": "Success",
        "content": {
            "application/json": {
                "examples": {
                    "with_data" : {
                        "summary" : "Profile updated Successfully",
                        "value" : {
                            "detail":{
                                "status" : "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "Profile updated Successfully"
                                },
                            "error": None
                            }
                        }
                    },
                    "without_data" : {
                        "summary" : "No profile to update",
                        "value" : {
                            "detail":{
                                "status" : "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "No profile to update",
                                },
                            "error": None
                            }
                        }
                    }
                }
            }
        }
    }
}

follow_social_media_responses = {

    404 : {
        "description": "Error",
        "content": {
            "application/json": {
                "examples": {
                    "User not found" : {
                        "summary" : "User not found",
                        "value" : {
                            "detail":{
                                "status" : "Error",
                                "status_code" : 404,
                                "data" : None,
                                "error" : {
                                    "status_code":404,
                                    "status":'Error', 
                                    "message" : "User does not exist."
                                }
                            }
                        }
                    },
                    "social_media_not_found" : {
                        "summary" : "requested social media id does not exist.",
                        "value" : {
                            "detail":{
                                "status" : "Error",
                                "status_code" : 404,
                                "data" : None,
                                "error" : {
                                    "status_code":404,
                                    "status":'Error', 
                                    "message" : "requested social media id does not exist."
                                }
                            }
                        }
                    }
                }
            }
        }
    },
    
    200 : {
        "description": "Success",
            "content": {
                "application/json": {
                    "examples": {
                        "already_following" : {
                            "summary" : "Already_following",
                            "value" : {
                                "detail":{
                                   "status": "Success",
                                    "status_code": 200,
                                    "data": {
                                        "status_code": 200,
                                        "status": "Success",
                                        "message": "Tester is already Following facebook",
                                    },
                                    "error": None
                                }
                            }
                        },
                        "started_following" : {
                            "summary" : "Started_following",
                            "value" : {
                                "detail":{
                                    "status" : "Success",
                                    "status_code": 200,
                                    "data": {
                                        "status_code": 200,
                                        "status": "Success",
                                        "message":  "Tester started Following facebook",
                                    },
                                "error": None
                                }
                            }
                        }
                    }
                }
            }
        },

    500 : {
        "description": "Error",
        "content": {
            "application/json": {
                "examples": {
                    "Server Error" : {
                        "summary" : "Internal server error." ,
                        "value" : {
                            "detail":{
                                "status" : "Error", 
                                "status_code" : 500, 
                                "data" : None, 
                                "error" : { 
                                    "status_code":500, 
                                    "status":'Error', 
                                    "message" : "Internal server error." 
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

followed_social_media_responses = {

    404 : {
        "description": "Error",
        "content": {
            "application/json": {
                "examples": {
                    "User not found" : {
                        "summary" : "User not found",
                        "value" : {
                            "detail":{
                                "status" : "Error",
                                "status_code" : 404,
                                "data" : None,
                                "error" : {
                                    "status_code":404,
                                    "status":'Error', 
                                    "message" : "User does not exist."
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    200 : {
        "description": "Success",
        "content": {
            "application/json": {
                "examples": {
                    "social_media_information" : {
                        "summary" : "successfully fetched social media information",
                        "value" : {
                            "detail":{
                                "status": "Success",
                                "status_code": 200,
                                "data": {
                                    "status_code": 200,
                                    "status": "Success",
                                    "message": "successfully fetched social media information for Tester",
                                    "social_media_details": {
                                        "facebook": False,
                                        "youtube": False,
                                        "twitter": False,
                                        "whatsapp": False,
                                        "linkedin": False,
                                        "telegram": False,
                                        "instagram": False,
                                        "discord": False
                                    }
                                },
                                "error": None
                            }
                        }
                    }
                }
            }
        }
    },

    500 : {
        "description": "Error",
        "content": {
            "application/json": {
                "examples": {
                    "Server Error" : {
                        "summary" : "Internal server error." ,
                        "value" : {
                            "detail":{
                                "status" : "Error", 
                                "status_code" : 500, 
                                "data" : None, 
                                "error" : { 
                                    "status_code":500, 
                                    "status":'Error', 
                                    "message" : "Internal server error." 
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

    