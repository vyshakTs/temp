from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from core.database.connection import get_db
from core.api.consumer import crud, schema
from core.jwt.auth_bearer import JWTBearer
from core.jwt import auth_handler
from core.models.mixin import MessageType


router = APIRouter()

@router.get('/consumer_profile', dependencies=[Depends(JWTBearer())], status_code=200, tags=["Consumer"], responses = schema.consumer_profile_response)
async def get_consumer_profile(token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    current_consumer_profile = crud.get_profile(db, payload['sub'])
    response_msg = {
                "detail" : {
                    "status" : "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message": "Consumer details.",
                        "consumer_profile": current_consumer_profile
                    },
                "error": None
                }
            }
    return response_msg

@router.post('/create_consumer_profile', dependencies=[Depends(JWTBearer())], tags=["Consumer"], responses=schema.create_consumer_profile_responses)
async def create_consumer_profile(profile_data : schema.ConsumerProfileBase, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db, payload['sub'])
    
    if not user:
        raise HTTPException(
            status_code=404,
            detail={
                "status" : "Error",
                "status_code" : 404,
                "data" : None,
                "error" : {
                    "status_code":404,
                    "status":'Error', 
                    "message" : "User not found."
                }
            }
        )
        
    profile = crud.check_if_profile_exists(db, user.__dict__['id'])
    
    if profile:
        raise HTTPException(
            status_code=403,
            detail={
                "status" : "Error",
                "status_code" : 403,
                "data" : None,
                "error" : {
                    "status_code":403,
                    "status":'Error', 
                    "message" : "Profile already exists."
                }
            }
        )
        
    consumer_profile = crud.create_profile(db, user.__dict__['id'], profile_data)
    complete_consumer = crud.complete_consumer_profile(db = db, users_id = user.id)
    
    if consumer_profile:
        response_msg = {
                "detail" : {
                    "status" : "Success",
                    "status_code": 201,
                    "data": {
                        "status_code": 201,
                        "status": "Success",
                        "message": "Profile created Successfully"
                    },
                "error": None
                }
            }
        return response_msg
    else:
        raise HTTPException(
            status_code=500,
            detail={
                "status" : "Error",
                "status_code" : 500,
                "data" : None,
                "error" : {
                    "status_code":500,
                    "status":'Error', 
                    "message" : "Internal server error."
                }
            }
        )
        

@router.put('/update_consumer_profile', dependencies=[Depends(JWTBearer())], status_code=200, tags=["Consumer"], responses = schema.update_consumer_profile_response)
async def update_consumer_profile(profile_data : schema.UpdateConsumerProfile, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db, payload['sub'])
    
    if not user:
        raise HTTPException(
            status_code=404,
            detail={              
                "status" : "Error",
                "status_code" : 404,
                "data" : None,
                "error" : {
                    "status_code":404,
                    "status":'Error', 
                    "message" : "User not found."
                }
            }
        )
                                   
    profile = crud.check_if_profile_exists(db, user.__dict__['id'])
    
    if not profile:
        raise HTTPException(
            status_code=404,
            detail={
                "status" : "Error",
                "status_code" : 404,
                "data" : None,
                "error" : {
                    "status_code":404,
                    "status":'Error', 
                    "message" : "Profile does not exist."
                }
            }
        )
    if profile_data.full_name:
        update_full_name = crud.update_users_full_name(db = db, full_name = profile_data.full_name, users_id = user.id)
        if update_full_name :
            del profile_data.full_name
    update_profile_data = profile_data.dict(exclude_unset=True)
    update_result = crud.update_profile(db, user.__dict__['id'], update_profile_data)
    complete_consumer = crud.complete_consumer_profile(db = db, users_id = user.id)
    
    if update_result:
        response_msg = {
                "detail" : {
                    "status" : "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message": "Profile updated Successfully"
                    },
                "error": None
                }
            }
    else:
        response_msg = {
                "detail" : {
                    "status" : "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message": "No profile to update",
                    },
                "error": None
                }
            }
    return response_msg


@router.patch('/follow-social-media', dependencies=[Depends(JWTBearer())], status_code=200, tags=["Consumer"], responses = schema.follow_social_media_responses)
def follow_social_media_api(social_media: schema.FollowSocialMedia, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db, payload['sub'])
    if not user:
        raise HTTPException(
            status_code=404,
            detail={
                "status" : "Error",
                "status_code" : 404,
                "data" : None,
                "error" : {
                    "status_code":404,
                    "status":'Error', 
                    "message" : "User does not exist."
                }
            }
        )
        
    social_media_details = crud.get_social_media(db, social_media.id)
    if social_media_details:
        social_media_name = social_media_details.__dict__['name']
        social_media_col_name = social_media_details.__dict__['column_name']
        get_followed_social_media = crud.followed_social_media(db, followed_social_media=social_media_col_name, user_id=user.id)
        if get_followed_social_media.__dict__[f'{social_media_col_name}']:
            response_msg = {
                "detail": {
                    "status": "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message": f"{user.full_name} is already Following {social_media_name}",
                    },
                    "error": None
                }
            }
            return response_msg
        update_social_media = crud.update_followed_social_media(db, followed_social_media=social_media_col_name, user_id=user.id)
        complete_social_media = crud.complete_followed_social_media(db = db, users_id = user.id)
        if update_social_media:
            response_msg = {
                "detail": {
                    "status": "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message": f"{user.full_name} started Following {social_media_name}",
                    },
                    "error": None
                }
            }
            return response_msg
        else:
            raise HTTPException(
                status_code=500,
                detail={
                    "status" : "Error",
                    "status_code" : 500,
                    "data" : None,
                    "error" : {
                        "status_code":500,
                        "status":'Error', 
                        "message" : "internal server error."
                    }
                }
            )   
    else:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "requested social media id does not exist."
                    }
                }
            )


@router.get("/followed-social-media", dependencies=[Depends(JWTBearer())], status_code=200, tags=["Consumer"], responses = schema.followed_social_media_responses)
def followed_social_media_api(token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db, payload['sub'])
    if not user:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "User not found."
                    }
                }
            )
    followed_social_media = crud.get_followed_social_media(db=db, user_id=user.id)
    if followed_social_media:
        response_msg = {
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": f"successfully fetched social media information for {user.full_name}.",
                    "social_media_details": followed_social_media
                },
                "error": None
            }
        }
        return response_msg
    else:
        raise HTTPException(
            status_code=500,
            detail={
                "status" : "Error",
                "status_code" : 500,
                "data" : None,
                "error" : {
                    "status_code":500,
                    "status":'Error', 
                    "message" : "internal server error."
                }
            }
        )


@router.get("/get-notifications", dependencies=[Depends(JWTBearer())], status_code=200, tags=["Consumer"])
def get_notification_api(token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db, payload['sub'])
    if not user:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "User not found."
                    }
                }
            )
    all_notifications = crud.get_all_notifications(db=db, user_id=user.id)
    response_msg = {
        "detail": {
            "status": "Success",
            "status_code": 200,
            "data": {
                "status_code": 200,
                "status": "Success",
                "message": f"successfully fetched unread notifications.",
                "notifications": all_notifications
            },
            "error": None
        }
    }
    return response_msg


@router.patch("/update-notifications", dependencies=[Depends(JWTBearer())], status_code=200, tags=["Consumer"])
def update_notification_api(notification: schema.NotificationPatch, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db, payload['sub'])
    if not user:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "User not found."
                    }
                }
            )
    update_notification = crud.update_notifications(db=db, notification_id=notification.id)
    
    if update_notification:
        response_msg = {
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": f"successfully updated notification as read.",
                },
                "error": None
            }
        }
        return response_msg
    else:
        raise HTTPException(
            status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "Notification with the given id does not exist"
                    }
                }
        )


@router.patch("/bulk-update-notifications", dependencies=[Depends(JWTBearer())], status_code=200, tags=["Consumer"])
def update_notification_api(token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db, payload['sub'])
    if not user:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "User not found."
                    }
                }
            )
    update_all_notification = crud.update_notifications(db=db, notification_id=None)
    if update_all_notification:
        response_msg = {
            "detail": {
                "status": "Success",
                "status_code": 200,
                "data": {
                    "status_code": 200,
                    "status": "Success",
                    "message": f"successfully updated all notifications as read.",
                },
                "error": None
            }
        }
        return response_msg
    else:
        raise HTTPException(
            status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "No notifications to update."
                    }
                }
        )

@router.post("/add-notification", dependencies=[Depends(JWTBearer())], status_code=201, tags=["Consumer"])
def insert_notification_api(notification: schema.NotificationPost, message_type: MessageType = MessageType.TEST, token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db, payload['sub'])
    if not user:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "User not found."
                    }
                }
            )
    insert_notification_data = crud.insert_notification(db=db, notification=notification, message_type=message_type, user_id=user.id)
    if insert_notification_data:
        response_msg = {
            "detail": {
                "status": "Success",
                "status_code": 201,
                "data": {
                    "status_code": 201,
                    "status": "Success",
                    "message": f"successfully inserted notification",
                },
                "error": None
            }
        }
        return response_msg
    else:
        raise HTTPException(
            status_code=500,
            detail={
                "status" : "Error",
                "status_code" : 500,
                "data" : None,
                "error" : {
                    "status_code":500,
                    "status":'Error', 
                    "message" : "internal server error."
                }
            }
        )
    
@router.get("/complete_profile",dependencies=[Depends(JWTBearer())], status_code=200, tags=["Consumer"])
def complete_profile(token = Depends(JWTBearer()), db : Session = Depends(get_db)):
    payload = auth_handler.decode_token(token=token)
    user = crud.check_if_user_exists(db, payload['sub'])
    if not user:
        raise HTTPException(
                status_code=404,
                detail={
                    "status" : "Error",
                    "status_code" : 404,
                    "data" : None,
                    "error" : {
                        "status_code":404,
                        "status":'Error', 
                        "message" : "User not found."
                    }
                }
            )
    sign_up_status = 'Incomplete'
    profile_completion_status = 'Incomplete'
    social_media_status = 'Incomplete'
    refer_friend_status = 'Incomplete'
    first_purchase_status = 'Incomplete'
    membership_and_prepaid_card_status = 'Incomplete'
    status = crud.get_profile_complete_status(db = db, users_id = user.id)
    if status.__dict__['completed']:
        response_msg = {
                "detail": {
                    "status": "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message": "Profile completed",
                        "completed_count" : 10,
                        "sign_up" : 'Complete',
                        "profile_completion" : 'Complete',
                        "social_media_follow" : 'Complete',
                        "refer_a_friend" : 'Complete',
                        "first_purchase" : 'Complete',
                        "buy_membership_and_prepaid_card" : 'Complete'
                    },
                    "error": None
                }
            }
        return response_msg
    complete_status = 0
    if status.__dict__['sign_up_status']:
        reward = crud.get_reward(db = db, column_name = 'sign_up_status')
        for i in reward:
            complete_status += i
            sign_up_status = 'Complete'
    if status.__dict__['profile_completion_status']:
        reward = crud.get_reward(db = db, column_name = 'profile_completion_status')
        for i in reward:
            complete_status += i
            profile_completion_status = 'Complete'
    if status.__dict__['social_media_status']:
        reward = crud.get_reward(db = db, column_name = 'social_media_status')
        for i in reward:
            complete_status += i
            social_media_status = 'Complete'
    if status.__dict__['refer_friend_status']:
        reward = crud.get_reward(db = db, column_name = 'refer_friend_status')
        for i in reward:
            complete_status += i
            refer_friend_status = 'Complete'
    if status.__dict__['first_purchase_status']:
        reward = crud.get_reward(db = db, column_name = 'first_purchase_status')
        for i in reward:
            complete_status += i
            first_purchase_status = 'Complete'
    if status.__dict__['membership_and_prepaid_card_status']:
        reward = crud.get_reward(db = db, column_name = 'membership_and_prepaid_card_status')
        for i in reward:
            complete_status += i
            membership_and_prepaid_card_status = 'Complete'
    response_msg = {
                "detail": {
                    "status": "Success",
                    "status_code": 200,
                    "data": {
                        "status_code": 200,
                        "status": "Success",
                        "message": "Profile completed",
                        "completed_count" : complete_status,
                        "sign_up" : sign_up_status,
                        "profile_completion" : profile_completion_status,
                        "social_media_follow" : social_media_status,
                        "refer_a_friend" : refer_friend_status,
                        "first_purchase" : first_purchase_status,
                        "buy_membership_and_prepaid_card" : membership_and_prepaid_card_status
                    },
                    "error": None
                }
            }
    return response_msg

