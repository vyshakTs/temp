from itertools import chain
from sqlalchemy.orm import Session, load_only
from sqlalchemy.dialects.postgresql import insert

from core.api.users.models import Users
from core.api.consumer.models import (
    ConsumerProfile,
    SocialMedia,
    FollowedSocialMedia,
    Notifications,
    ConsumerCompleteProfile,
    CompleteProfile,
    MembershipPlans,
    ConsumerMembershipDetails,
    ConsumerMembershipTransaction
    )
from core.api.users.crud import get_user_by_email
from core.api.consumer.schema import NotificationPost

def get_profile(db : Session, user_name : str):
    profile_data = db.query(Users.full_name,Users.email,Users.phone_number,ConsumerProfile.users_id,ConsumerProfile.dob,ConsumerProfile.gender,
                            ConsumerProfile.address1,ConsumerProfile.address2,ConsumerProfile.city,ConsumerProfile.district,ConsumerProfile.state,\
                            ConsumerProfile.country,ConsumerProfile.postal_code,ConsumerProfile.current_location,ConsumerProfile.device_platform,\
                            ConsumerProfile.fcm_token,ConsumerProfile.last_login,ConsumerProfile.email_verified,ConsumerProfile.profile_image,\
                            ConsumerProfile.phone_number_verified)\
                        .join(ConsumerProfile, Users.id==ConsumerProfile.users_id, isouter=True).filter(Users.email==user_name).first()
    return profile_data

def check_if_user_exists(db : Session, email : str):
    return get_user_by_email(db, email)
    
def check_if_profile_exists(db : Session, user_id : int):
    return db.query(ConsumerProfile).filter(ConsumerProfile.users_id == user_id).first()

def create_profile(db : Session, user_id : int, profile_data : dict):
    db_consumer_profile = ConsumerProfile(
        users_id = user_id,
        dob = profile_data.dob,
        gender = profile_data.gender,
        address1 = profile_data.address1,
        address2 = profile_data.address2,
        city = profile_data.city,
        district = profile_data.district,
        state = profile_data.state,
        country = profile_data.country,
        postal_code = profile_data.postal_code,
        current_location = profile_data.current_location,
        device_platform = profile_data.device_platform,
        fcm_token = profile_data.fcm_token,
        last_login = profile_data.last_login,
        email_verified = profile_data.email_verified,
        profile_image = profile_data.profile_image,
        phone_number_verified = profile_data.phone_number_verified,
    )
    db.add(db_consumer_profile)
    db.commit()
    db.refresh(db_consumer_profile)
    return db_consumer_profile
    
def create_consumer_profile_min(db : Session, user_id : int):
    db_consumer_profile = ConsumerProfile(
            users_id = user_id,
            gender = 4,
            device_platform = 3
        )
    db.add(db_consumer_profile)
    db.commit()
    db.refresh(db_consumer_profile)
    return db_consumer_profile

def update_profile(db : Session, user_id : int, update_data : dict):
    result = db.query(ConsumerProfile).filter(ConsumerProfile.users_id==user_id).update(update_data)
    db.commit()
    #db.refresh(result) 
    return result

def get_recent_referrals_profile(db : Session, referral_code : int, user_id : int):
    profile_data = db.query(
        Users.full_name, Users.id, ConsumerProfile.profile_image, Users.created_at
        ).select_from(Users).join(
            ConsumerProfile, Users.id==ConsumerProfile.users_id, isouter=True).filter(Users.referred_by==referral_code
            ).all()
    return profile_data

def get_social_media(db : Session, social_media_id : int):
    social_media = db.query(SocialMedia).filter(SocialMedia.id==social_media_id).first()
    return social_media

def followed_social_media(db : Session, followed_social_media: dict, user_id : int):
    followed_social_media_details = db.query(FollowedSocialMedia).filter(FollowedSocialMedia.users_id==user_id).first()
    return followed_social_media_details
    
def update_followed_social_media(db : Session, followed_social_media: dict, user_id : int):
    update_followed_media = db.query(FollowedSocialMedia).filter(FollowedSocialMedia.users_id==user_id).update({followed_social_media: True})
    db.commit()
    return update_followed_media

def get_followed_social_media(db : Session, user_id : int):
    social_media = db.query(SocialMedia).all()
    return_dict = {}
    for i in social_media:
        is_followed = db.query(FollowedSocialMedia).filter(FollowedSocialMedia.users_id==user_id).first()
        return_dict.update({i.name: is_followed.__dict__[f'{i.column_name}']})
    return return_dict

def get_all_notifications(db: Session, user_id: int):
    notifications = db.query(Notifications).filter(Notifications.users_id == user_id, Notifications.read==False).all()
    return notifications

def update_notifications(db: Session, notification_id: int):
    if notification_id:
        update_notification = db.query(Notifications).filter(Notifications.id == notification_id).update({"read":True})
    else:
        update_notification = db.query(Notifications).update({"read":True})
    db.commit()
    return update_notification

def insert_notification(db: Session, notification: NotificationPost, message_type: int, user_id: int):
    notification_data = Notifications(
        users_id=user_id,
        message=notification.message,
        message_type=message_type,
        url=notification.url
    )
    db.add(notification_data)
    db.commit()
    db.refresh(notification_data)
    return notification_data
    

def create_complete_profile(db : Session, users_id : int):
    db_complete_profile = ConsumerCompleteProfile(
        users_id = users_id,
        sign_up_status = True
    )
    db.add(db_complete_profile)
    db.commit()
    db.refresh(db_complete_profile)
    complete_referrence(db = db, users_id = users_id)
    return True

def complete_consumer_profile(db : Session, users_id : int):
    profile= db.query(ConsumerProfile).filter(ConsumerProfile.users_id == users_id).first()
    profile_not_completed = profile.__dict__ 
    del profile_not_completed['_sa_instance_state']
    del profile_not_completed['device_id']
    del profile_not_completed['fcm_token']
    uncomplete_profile = []
    for key,values in profile_not_completed.items():
        if not values:
            uncomplete_profile.append(key)
    if not uncomplete_profile :
        db.query(ConsumerCompleteProfile).filter(ConsumerCompleteProfile.users_id == users_id).update({"profile_completion_status" : True})
        db.commit()
        return True
    return False

def complete_followed_social_media(db :Session, users_id : int):
    social_media = db.query(FollowedSocialMedia).filter(FollowedSocialMedia.users_id == users_id).first()
    not_followed_social_media = social_media.__dict__
    del not_followed_social_media['_sa_instance_state']
    uncomplete_social_media = []
    for key,values in not_followed_social_media.items():
        if not values:
            uncomplete_social_media.append(key)
    if not uncomplete_social_media :
        db.query(ConsumerCompleteProfile).filter(ConsumerCompleteProfile.users_id == users_id).update({"social_media_status" : True})
        db.commit()
        return True
    return False

def complete_referrence(db : Session, users_id : int):
    user = db.query(Users).filter(Users.id == users_id).first()
    referral_code = user.__dict__['referred_by']
    check_refferal = db.query(Users).filter(Users.referral_code == referral_code).first()
    if check_refferal :
        db.query(ConsumerCompleteProfile).filter(ConsumerCompleteProfile.users_id == check_refferal.id).update({"refer_friend_status" : True})
        db.commit()
        return True
    return False

def get_profile_complete_status(db : Session, users_id : int):
    return db.query(ConsumerCompleteProfile).filter(ConsumerCompleteProfile.users_id == users_id).first()

def get_reward(db : Session, column_name : str):
    return db.query(CompleteProfile.reward).filter(CompleteProfile.column_name == column_name).first()

def update_users_full_name(db : Session,full_name : str, users_id : int):
    return db.query(Users).filter(Users.id == users_id).update({"full_name":full_name})

def get_consumer_profile(db : Session, user_id : int):
    consumer_profile = db.query(ConsumerProfile).filter(ConsumerProfile.users_id == user_id).first()
    return consumer_profile

def get_membership_plans_list(db: Session):
    membership_plans = db.query(MembershipPlans)\
                            .filter(MembershipPlans.enabled == True)\
                            .options(load_only("id","plan","description","validity","amount","benefits"))\
                            .all()
    return membership_plans

def get_membership_plan_by_id(db: Session, plan_id :int):
    membership_plan = db.query(MembershipPlans)\
                        .filter(MembershipPlans.enabled == True, MembershipPlans.id == plan_id)\
                        .options(load_only("id","plan","description","validity","amount"))\
                        .first()
    return membership_plan

def get_consumer_by_user_id(db : Session, user_id : int):
    profile_data = db.query(ConsumerProfile).filter(ConsumerProfile.users_id == user_id).first()
    return profile_data

def get_consumer_membership_plans_by_status(db : Session, consumer_id : int, plan_status : int):
    membership_plan = db.query(ConsumerMembershipDetails)\
                        .filter(ConsumerMembershipDetails.consumer_id == consumer_id, ConsumerMembershipDetails.status == plan_status)\
                        .order_by(ConsumerMembershipDetails.end_datetime.desc())\
                        .first()
    return membership_plan

def get_consumer_membership_plans_by_cons_id(db : Session, consumer_id : int):
    cons_memb_plans = db.query(ConsumerMembershipDetails)\
                        .filter(ConsumerMembershipDetails.consumer_id == consumer_id)\
                        .all()
    return cons_memb_plans

def create_consumer_membership_transaction(db : Session, plan_details : dict, consumer_id : int):
    db_consumer_membership_tran = ConsumerMembershipTransaction(
        consumer_id = consumer_id,
        membership_plan_id = plan_details.id,
        plan_name = plan_details.plan,
        plan_validity = plan_details.validity,
        plan_amount = plan_details.amount,
        status = 2 # Pending
    )
    db.add(db_consumer_membership_tran)
    db.commit()
    db.refresh(db_consumer_membership_tran)
    return db_consumer_membership_tran

def update_consumer_membership_transaction(db: Session, trans_id : int, update_details : dict):
    if not update_details:
        return None
    update_cons_mem_tran = db.query(ConsumerMembershipTransaction).filter(ConsumerMembershipTransaction.id == trans_id).update(update_details)
    db.commit()
    return update_cons_mem_tran

def get_consumer_membership_transaction(db: Session, transaction_id):
    transaction = db.query(ConsumerMembershipTransaction)\
                    .filter(ConsumerMembershipTransaction.id == transaction_id)\
                    .first()
    return transaction

def get_consumer_membership_transaction_min(db: Session, order_id):
    transaction = db.query(ConsumerMembershipTransaction)\
                    .filter(ConsumerMembershipTransaction.order_id == order_id)\
                    .options(load_only("id","order_id"))\
                    .first()
    return transaction

def create_consumer_membership_details(db : Session, plan_details : dict, consumer_id : int, schedule_details : dict):
    db_consumer_membership_details = ConsumerMembershipDetails(
        consumer_id = consumer_id,
        plan_id = plan_details.id,
        plan_name = plan_details.plan,
        plan_validity = plan_details.validity,
        plan_amount = plan_details.amount,
        start_datetime = schedule_details["start_datetime"],
        end_datetime = schedule_details["end_datetime"],
        status = schedule_details["plan_status"]
        )
    db.add(db_consumer_membership_details)
    db.commit()
    db.refresh(db_consumer_membership_details)
    return db_consumer_membership_details

def update_consumer_membership_details(db : Session, consumer_plan_details : dict, cons_memb_det_id : int):
    if not consumer_plan_details:
        return None
    update_cons_mem_det = db.query(ConsumerMembershipDetails).filter(ConsumerMembershipDetails.id == cons_memb_det_id).update(consumer_plan_details)
    db.commit()
    return update_cons_mem_det