import enum

from sqlalchemy import Column, DateTime, Enum
from sqlalchemy.orm import declarative_mixin

from core.utils.time import utc_time
from datetime import datetime

from sqlalchemy.sql import func, text


class TimeStamp:
    created_at = Column(DateTime(timezone=True), server_default=text("(now() at time zone 'utc')"))
    updated_at = Column(
        DateTime(timezone=True),
        nullable=True,
        server_default=text("(now() at time zone 'utc')"),
        onupdate=text("(now() at time zone 'utc')"),
    )


class GenderType(enum.IntEnum):

    FEMALE = 1
    MALE = 2
    OTHER = 3
    NOTSPECIFIED = 4


class DeviceType(enum.IntEnum):

    ANDROID = 1
    IOS = 2
    NOTSPECIFIED = 3

class MessageType(enum.IntEnum):
    TEST = 1
    


class MembershipPlanStatus(enum.IntEnum):

    EXPIRED = 0
    ACTIVE = 1
    UPCOMING = 2
    CANCELLED = 3

class FSPStatus(enum.IntEnum):

    FAILED = 0
    SUCCESS = 1
    PENDING = 2