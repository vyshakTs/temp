import json
import requests

from config.base import settings

def get_voucher(voucher_details: dict):
    payload = json.dumps(
        {
            "query": "plumProAPI.mutation.getVouchers",
            "tag": "plumProAPI",
            "variables": {
                "data":{
                    "limit": voucher_details.limit,
                    "page": voucher_details.page,
                    "includeProducts": "",
                    "excludeProducts": "",
                    "sort": {
                        "field":"",
                        "order":""
                    },
                    "filters":[
                        {
                            "key": "country",
                            "value": f"{voucher_details.country}" if voucher_details.country else ""
                        },
                        {
                            "key": "productName",
                            "value": f"{voucher_details.product_name}" if voucher_details.product_name else ""
                        },
                    ]
                }
            }
        }
    )
    headers = {
    'Authorization': f'Bearer {settings.XOXO_AUTH_TOKEN}',
    'Content-Type': 'application/json',
    }
    response = requests.request("POST", settings.XOXO_BASE_API, headers=headers, data=payload)
    
    return response
