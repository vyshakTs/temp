import requests
import json
import httpx
import asyncio

from config.base import settings


async def cashfree_create_order(order_details: dict):
    create_order_url = f"{settings.CASHFREE_BASE_API_URL}/orders"
    payload = json.dumps(
        {
            "order_id": order_details['order_id'],
            "order_amount": order_details['order_amount'],
            "order_currency": order_details['order_currency'],
            "customer_details": order_details['customer_details'],
            "order_meta": order_details['order_meta'],
            "order_expiry_time": order_details['order_expiry_time'],
            "order_note": order_details['order_note'],
            "order_tags": order_details['order_tags'],
        }
    )

    headers = {
        "Accept": "application/json",
        "x-api-version": settings.CASHFREE_API_VERSION,
        "Content-Type": "application/json",
        "x-client-id": settings.CASHFREE_CLIENT_ID,
        "x-client-secret": settings.CASHFREE_CLIENT_SECRET,
    }
    
    async with httpx.AsyncClient() as client:
        response = await client.post(create_order_url, headers=headers, data=payload)

    return response



