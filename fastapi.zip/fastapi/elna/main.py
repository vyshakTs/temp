import uvicorn

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from core.api.users import userapi

app = FastAPI()

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

# Enable GZip compression
app.add_middleware(GZipMiddleware, minimum_size=1000)

app.include_router(userapi.router)

@app.get("/")
def read_root():
    return {"message": "Hello, FastAPI!"}

# Additional routes and application logic can be defined here

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
