from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    DB_URL: str
    HOST: str
    PORT: int
    JWT_SECRET_KEY: str
    JWT_REFRESH_SECRET_KEY: str
    JWT_TOKEN_EXPIRY_DAYS: int
    ALGORITHM: str
    BASE_API_URL: str

    class Config:
        case_sensitive = True
        env_file = ".env"


settings = Settings()
