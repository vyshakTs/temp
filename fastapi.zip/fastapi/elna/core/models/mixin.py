import enum

from sqlalchemy import Column, DateTime

from sqlalchemy.sql import text


class TimeStamp:
    created_at = Column(
        DateTime,
        server_default=text("(now() at time zone 'utc')"),
        onupdate=text("(now() at time zone 'utc')"),
    )
    updated_at = Column(
        DateTime,
        server_default=text("(now() at time zone 'utc')"),
        onupdate=text("(now() at time zone 'utc')"),
    )

