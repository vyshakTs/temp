from typing import Optional, Text

from pydantic import BaseModel, EmailStr, Field


class UserBase(BaseModel):
    address: str = Field(..., max_length=1000, description="wallet address")
    
    class Config:
        orm_mode = True
        schema_extra = {
            "example": {
                "address": "Test Test"
            },
        }