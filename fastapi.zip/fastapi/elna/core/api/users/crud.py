from sqlalchemy.orm import Session

from core.api.users import models, schema




def add_user(db: Session, user: schema.UserBase):
    db_user = models.Users(
        address=user.address
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


def get_user(db: Session, address: str):
    return db.query(models.Users).filter(models.Users.address==address).first()

