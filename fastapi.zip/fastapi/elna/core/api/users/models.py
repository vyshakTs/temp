from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import relationship

from core.database.connection import Base
from core.models.mixin import TimeStamp


class Users(TimeStamp, Base):

    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    address = Column(Text, nullable=False)
    is_whitelisted = Column(Boolean, default=False)
