#import requests
from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session

from core.api.users import schema, crud
from core.database.connection import get_db


router = APIRouter()


@router.post("/user", status_code=200, tags=["User"])
async def create_user_api(user: schema.UserBase, db: Session = Depends(get_db)):
    create_user = crud.add_user(db=db, user=user)
    if create_user:
        response = {
            "status_code": 200,
            "data": {
                "message": "user created successfully"
            }
        }
        return response
    
@router.get("/user", status_code=200, tags=["User"])
async def create_user_api(address: str, db: Session = Depends(get_db)):
    user = crud.get_user(db=db, address=address)
    if user:
        response = {
            "status_code": 200,
            "data": {
                "user": user
            }
        }
        return response
    else:
        response = {
            "status_code": 404,
            "data": {
                "message": "user not found"
            }
        }

    
